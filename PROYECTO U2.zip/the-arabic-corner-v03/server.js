// Servidor de The Arabic Corner: API REST sobre MongoDB + archivos estáticos.
const path = require('node:path');
const crypto = require('node:crypto');
const { crearApp } = require('./lib/http');
const { conectar, siguienteId, hashPassword, verifyPassword, ocultarUri } = require('./db');
const cifrado = require('./lib/cifrado');
const seg = require('./lib/seguridad');
const totp = require('./lib/totp');
const motor = require('./recomendador');
const analisis = require('./analisis');

const PORT = process.env.PORT || 3000;
const HOST = process.env.HOST || '0.0.0.0'; // en producción: 127.0.0.1 (solo accesible a través de Caddy)
const app = crearApp({ limiteJson: 4 * 1024 * 1024 });
let db; // se asigna al conectar
// MFA_ADMIN=1 → los administradores deben activar la verificación en dos pasos antes de usar el panel.
const MFA_ADMIN = process.env.MFA_ADMIN === '1';

// ---------- controles globales: cabeceras de seguridad y límite de peticiones ----------
const limiteApi = seg.limitador({ ventanaMs: 60_000, max: 300 });      // 300 peticiones/min por IP
const limiteAuth = seg.limitador({ ventanaMs: 5 * 60_000, max: 20 });  // 20 intentos de acceso cada 5 min por IP
app.use((req, res) => {
  req.ip = seg.ipCliente(req);
  seg.cabeceras(req, res);
  if (!req.path.startsWith('/api/')) return;
  const esAuth = /^\/api\/auth\/(login|registro|recuperar)$/.test(req.path);
  const r = (esAuth ? limiteAuth : limiteApi)(`${esAuth ? 'auth' : 'api'}:${req.ip}`);
  if (!r.permitido) {
    res.setHeader('Retry-After', String(r.reintentarEn));
    res.status(429).json({ error: `Demasiadas solicitudes. Intenta de nuevo en ${r.reintentarEn} segundos.` });
  }
});

app.static(path.join(__dirname, 'public'));
app.get('/terminos.pdf', (req, res) =>
  res.sendFile(path.join(__dirname, 'docs', 'Terminos_y_Condiciones_The_Arabic_Corner.pdf')));

// ---------- utilidades ----------
const col = (nombre) => db.collection(nombre);
const fail = (res, status, error) => res.status(status).json({ error });
const idNum = (v) => { const n = Number(v); return Number.isInteger(n) && n > 0 ? n : null; };
const escRegex = (s) => String(s).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
const fechaTxt = (d) => new Date(d).toISOString().slice(0, 19).replace('T', ' ');

// Documento de MongoDB → objeto para la API (el frontend usa "id" en lugar de "_id").
const conId = (d) => { if (!d) return d; const { _id, ...rest } = d; return { id: _id, ...rest }; };

function perfumeResumen(p) {
  if (!p) return p;
  const o = conId(p);
  return { ...o, tieneImagen: !!o.imagen, imagen: o.imagen || null };
}

function usuarioPublico(u) {
  if (!u) return null;
  return { id: u._id, nombre: u.nombre, correo: u.correo, telefono: u.telefono, rol: u.rol, sucursal: u.sucursal, creado: u.creado };
}

// El detalle del historial puede contener datos personales: se guarda cifrado (AES-256-GCM).
async function registrarActividad(usuarioId, tipo, detalle, resultado = '—', autor = 'Sistema') {
  await col('actividad').insertOne({ usuario_id: usuarioId, fecha: new Date(), tipo, detalle: cifrado.cifrar(detalle), resultado, autor });
}

// Bitácora de seguridad (colección "auditoria", TTL de 180 días). Atlas M0 no ofrece auditoría nativa,
// así que la aplicación registra accesos y cambios administrativos.
async function auditar(req, accion, exito, extra = {}) {
  try {
    await col('auditoria').insertOne({
      fecha: new Date(), accion, exito: !!exito,
      usuario_id: extra.usuario?._id ?? req.user?._id ?? null,
      correo: extra.correo ?? extra.usuario?.correo ?? req.user?.correo ?? null,
      rol: extra.usuario?.rol ?? req.user?.rol ?? null,
      ip: req.ip || null, agente: String(req.headers['user-agent'] || '').slice(0, 160),
      detalle: extra.detalle ?? null,
    });
  } catch (e) { console.error('No se pudo escribir en la bitácora:', e.message); }
}
// Middleware: registra en la bitácora una acción administrativa cuando termina la petición.
const bitacora = (accion) => (req, res, next) => {
  res.on('finish', () => {
    const detalle = [req.params?.id && `id ${req.params.id}`, req.body?.nombre, req.body?.precio && `precio ${req.body.precio}`,
      req.body?.cantidad && `cantidad ${req.body.cantidad}`, req.body?.existencias != null && `existencias ${req.body.existencias}`]
      .filter(Boolean).join(' · ') || null;
    auditar(req, accion, res.statusCode < 400, { detalle });
  });
  return next();
};

async function registrarEvento(tipo, perfume, usuarioId, extra = {}) {
  await col('eventos').insertOne({
    tipo, perfume_id: perfume?._id ?? perfume?.id ?? null, familia: extra.familia ?? perfume?.familia ?? null,
    ocasion: extra.ocasion ?? null, temporada: extra.temporada ?? null, aceptada: !!extra.aceptada,
    usuario_id: usuarioId ?? null, fecha: new Date(),
  });
}

// La recomendación más reciente de ese perfume para ese cliente se marca como aceptada.
async function marcarRecomendacionAceptada(usuarioId, perfumeId) {
  await col('eventos').findOneAndUpdate(
    { tipo: 'recomendacion', usuario_id: usuarioId, perfume_id: perfumeId, aceptada: false },
    { $set: { aceptada: true } }, { sort: { fecha: -1 } });
}

const perfumesPublicados = async () => (await col('perfumes').find({ estado: 'Publicado' }).sort({ _id: 1 }).toArray()).map(conId);
const perfumePorId = async (id, soloPublicado = false) => {
  const n = idNum(id);
  if (!n) return null;
  return col('perfumes').findOne(soloPublicado ? { _id: n, estado: 'Publicado' } : { _id: n });
};
const preferenciasDe = async (id) => (id ? cifrado.descifrarPreferencias((await col('usuarios').findOne({ _id: id }, { projection: { preferencias: 1 } }))?.preferencias) || null : null);
const clientePorId = async (id) => { const n = idNum(id); return n ? cifrado.descifrarUsuario(await col('usuarios').findOne({ _id: n, rol: 'cliente' })) : null; };

// ---------- autenticación ----------
function auth(...roles) {
  return async (req, res, next) => {
    const token = (req.headers.authorization || '').replace(/^Bearer\s+/i, '');
    if (!token) return fail(res, 401, 'Inicia sesión para continuar.');
    const sesion = await col('sesiones').findOne({ _id: token, expira: { $gt: new Date() } });
    const u = sesion && await col('usuarios').findOne({ _id: sesion.usuario_id });
    if (!u) return fail(res, 401, 'Tu sesión expiró. Inicia sesión de nuevo.');
    if (roles.length && !roles.includes(u.rol)) return fail(res, 403, 'No tienes permiso para esta acción.');
    // El panel de administrador solo se puede usar desde la red VPN (si ADMIN_REDES está configurada).
    if (u.rol === 'admin' && !seg.ipPermitidaAdmin(req.ip)) {
      await auditar(req, 'Acceso de administrador fuera de las redes autorizadas', false, { usuario: u });
      return fail(res, 403, 'El panel de administración solo está disponible desde una red autorizada (VPN o IP de confianza).');
    }
    // Verificación en dos pasos obligatoria para administradores: hasta activarla solo puede configurarla.
    if (u.rol === 'admin' && MFA_ADMIN && !u.mfa?.activo && !/^\/api\/(mfa|auth)(\/|$)/.test(req.path)) {
      return res.status(403).json({ error: 'Activa la verificación en dos pasos para usar el panel de administrador.', mfa_pendiente: true });
    }
    req.user = cifrado.descifrarUsuario(u);
    req.token = token;
    await next();
  };
}

async function crearSesion(usuarioId, recordar) {
  const token = crypto.randomBytes(24).toString('hex');
  const dias = recordar ? 30 : 1;
  // El índice TTL sobre "expira" hace que MongoDB borre la sesión automáticamente al vencer.
  await col('sesiones').insertOne({ _id: token, usuario_id: usuarioId, expira: new Date(Date.now() + dias * 864e5) });
  return token;
}

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const normCorreo = (c) => String(c || '').trim().toLowerCase();

// Bloqueo por fuerza bruta: 5 intentos fallidos por correo → 15 minutos bloqueado.
// Se guarda en la colección "intentos_login" (índice TTL: los registros se borran solos tras 1 hora sin actividad).
const MAX_FALLOS = 5;
const BLOQUEO_MIN = 15;

app.post('/api/auth/login', async (req, res) => {
  const { correo, password, rol, recordar } = req.body || {};
  if (!correo || !password) return fail(res, 400, 'Escribe tu correo y contraseña.');
  const mail = normCorreo(correo);
  const intento = await col('intentos_login').findOne({ _id: mail });
  if (intento?.bloqueado_hasta > new Date()) {
    const min = Math.ceil((intento.bloqueado_hasta - Date.now()) / 60000);
    await auditar(req, 'Inicio de sesión bloqueado', false, { correo: mail });
    return fail(res, 429, `Cuenta bloqueada temporalmente por intentos fallidos. Intenta en ${min} minuto${min === 1 ? '' : 's'}.`);
  }
  // Cuenta un intento fallido (contraseña o código de verificación) y bloquea al llegar a MAX_FALLOS.
  const registrarFallo = async (accion, mensaje) => {
    const fallos = (intento?.fallos || 0) + 1;
    const bloquear = fallos >= MAX_FALLOS;
    await col('intentos_login').updateOne({ _id: mail }, {
      $set: { fallos: bloquear ? 0 : fallos, actualizado: new Date(), bloqueado_hasta: bloquear ? new Date(Date.now() + BLOQUEO_MIN * 60000) : null },
    }, { upsert: true });
    await auditar(req, bloquear ? 'Cuenta bloqueada por intentos fallidos' : accion, false, { correo: mail, detalle: `intento ${fallos}` });
    return fail(res, 401, bloquear
      ? `Demasiados intentos fallidos. La cuenta se bloqueó ${BLOQUEO_MIN} minutos.`
      : `${mensaje}${MAX_FALLOS - fallos <= 2 ? ` Te quedan ${MAX_FALLOS - fallos} intento(s).` : ''}`);
  };
  const u = await col('usuarios').findOne({ correo: mail });
  if (!u || !verifyPassword(String(password), u.password_hash)) return registrarFallo('Inicio de sesión fallido', 'Correo o contraseña incorrectos.');
  if (rol && u.rol !== rol) {
    const nombres = { cliente: 'cliente', asesor: 'asesor de ventas', admin: 'administrador' };
    return fail(res, 403, `Esta cuenta no tiene acceso como ${nombres[rol]}. Selecciona el tipo de usuario correcto.`);
  }
  if (u.rol === 'admin' && !seg.ipPermitidaAdmin(req.ip)) {
    await auditar(req, 'Acceso de administrador fuera de las redes autorizadas', false, { usuario: u });
    return fail(res, 403, 'El panel de administración solo está disponible desde una red autorizada (VPN o IP de confianza).');
  }
  // Segundo factor: si la cuenta tiene activada la verificación en dos pasos, se pide el código de 6 dígitos.
  let conMfa = false;
  if (u.mfa?.activo) {
    if (!String(req.body.codigo || '').trim()) return res.json({ mfa_requerido: true });
    const paso = totp.verificar(cifrado.descifrar(u.mfa.secreto), req.body.codigo, u.mfa.ultimo_paso ?? -1);
    if (!paso) return registrarFallo('Código de verificación incorrecto', 'Código de verificación incorrecto o vencido.');
    await col('usuarios').updateOne({ _id: u._id }, { $set: { 'mfa.ultimo_paso': paso } });
    conMfa = true;
  }
  await col('intentos_login').deleteOne({ _id: mail });
  await auditar(req, 'Inicio de sesión', true, { usuario: u, detalle: conMfa ? 'con verificación en dos pasos' : null });
  res.json({ token: await crearSesion(u._id, recordar), usuario: usuarioPublico(cifrado.descifrarUsuario(u)) });
});

app.post('/api/auth/registro', async (req, res) => {
  const { nombre, correo, telefono, password, acepta_terminos } = req.body || {};
  if (!nombre || String(nombre).trim().length < 3) return fail(res, 400, 'Escribe tu nombre completo.');
  if (!EMAIL_RE.test(normCorreo(correo))) return fail(res, 400, 'Escribe un correo electrónico válido.');
  const errPw = seg.validarPassword(password, { correo, nombre });
  if (errPw) return fail(res, 400, errPw);
  if (!acepta_terminos) return fail(res, 400, 'Debes aceptar los Términos y Condiciones y el Aviso de Privacidad.');
  if (await col('usuarios').findOne({ correo: normCorreo(correo) })) return fail(res, 409, 'Ya existe una cuenta con ese correo.');
  const ahora = new Date();
  const u = {
    _id: await siguienteId(db, 'usuarios'), nombre: String(nombre).trim(), correo: normCorreo(correo),
    telefono: telefono ? cifrado.cifrar(String(telefono).trim()) : null, telefono_hash: cifrado.hashTelefono(telefono),
    password_hash: hashPassword(String(password)), rol: 'cliente',
    sucursal: null, acepto_terminos: ahora, creado: ahora, preferencias: null, favoritos: [],
  };
  try { await col('usuarios').insertOne(u); } catch (e) {
    if (e.code === 11000) return fail(res, 409, 'Ya existe una cuenta con ese correo.');
    throw e;
  }
  await registrarActividad(u._id, 'Alta de cliente', 'Creó su cuenta y aceptó los Términos y Condiciones.', 'Perfil creado');
  await auditar(req, 'Registro de cliente', true, { usuario: u });
  res.status(201).json({ token: await crearSesion(u._id, false), usuario: usuarioPublico(cifrado.descifrarUsuario(u)) });
});

app.post('/api/auth/recuperar', (req, res) => {
  // No revela si el correo existe. En producción se enviaría un enlace de restablecimiento.
  res.json({ mensaje: 'Si el correo está registrado, recibirás instrucciones para restablecer tu contraseña. También puedes acudir a cualquier sucursal.' });
});

app.post('/api/auth/logout', auth(), async (req, res) => {
  await col('sesiones').deleteOne({ _id: req.token });
  await auditar(req, 'Cierre de sesión', true);
  res.json({ ok: true });
});

app.get('/api/auth/me', auth(), (req, res) => res.json({ usuario: usuarioPublico(req.user) }));

// Configuración pública: en producción se pueden ocultar las cuentas de demostración (OCULTAR_DEMO=1).
app.get('/api/config', (req, res) => res.json({ demo: process.env.OCULTAR_DEMO !== '1' }));

// ---------- verificación en dos pasos (TOTP) para administradores y asesores ----------
const mfaObligatoria = (u) => MFA_ADMIN && u.rol === 'admin';
app.get('/api/mfa', auth('admin', 'asesor'), (req, res) => res.json({ activo: !!req.user.mfa?.activo, obligatoria: mfaObligatoria(req.user), activado: req.user.mfa?.activado || null }));

app.post('/api/mfa/iniciar', auth('admin', 'asesor'), async (req, res) => {
  if (req.user.mfa?.activo) return fail(res, 409, 'La verificación en dos pasos ya está activa.');
  const secreto = totp.generarSecreto();
  // El secreto se guarda cifrado (AES-256-GCM) igual que los demás datos sensibles.
  await col('usuarios').updateOne({ _id: req.user._id }, { $set: { mfa: { activo: false, pendiente: cifrado.cifrar(secreto) } } });
  res.json({ secreto, uri: totp.uri(secreto, req.user.correo) });
});

app.post('/api/mfa/activar', auth('admin', 'asesor'), async (req, res) => {
  const u = await col('usuarios').findOne({ _id: req.user._id });
  if (!u.mfa?.pendiente) return fail(res, 400, 'Primero genera la clave de configuración.');
  const secreto = cifrado.descifrar(u.mfa.pendiente);
  const paso = totp.verificar(secreto, req.body?.codigo);
  if (!paso) { await auditar(req, 'Activación de verificación en dos pasos fallida', false); return fail(res, 400, 'El código no coincide. Revisa la hora de tu celular y escribe el código actual.'); }
  await col('usuarios').updateOne({ _id: u._id }, { $set: { mfa: { activo: true, secreto: u.mfa.pendiente, activado: new Date(), ultimo_paso: paso } } });
  // Cierra las demás sesiones: a partir de ahora todas deben entrar con el segundo factor.
  await col('sesiones').deleteMany({ usuario_id: u._id, _id: { $ne: req.token } });
  await auditar(req, 'Verificación en dos pasos activada', true);
  res.json({ ok: true });
});

app.post('/api/mfa/desactivar', auth('admin', 'asesor'), async (req, res) => {
  if (mfaObligatoria(req.user)) return fail(res, 403, 'La verificación en dos pasos es obligatoria para administradores.');
  const u = await col('usuarios').findOne({ _id: req.user._id });
  if (!u.mfa?.activo) return fail(res, 400, 'La verificación en dos pasos no está activa.');
  const okPw = verifyPassword(String(req.body?.password || ''), u.password_hash);
  const paso = totp.verificar(cifrado.descifrar(u.mfa.secreto), req.body?.codigo, u.mfa.ultimo_paso ?? -1);
  if (!okPw || !paso) { await auditar(req, 'Desactivación de verificación en dos pasos fallida', false); return fail(res, 400, 'Contraseña o código incorrectos.'); }
  await col('usuarios').updateOne({ _id: u._id }, { $unset: { mfa: '' } });
  await auditar(req, 'Verificación en dos pasos desactivada', true);
  res.json({ ok: true });
});

// ---------- catálogo ----------
app.get('/api/categorias', auth(), async (req, res) => {
  const cats = await col('categorias').find({}).sort({ tipo: 1, _id: 1 }).toArray();
  // En MongoDB, { ocasiones: 'Cita' } coincide con los documentos cuyo arreglo contiene 'Cita'.
  const campo = { familia: 'familia', ocasion: 'ocasiones', temporada: 'temporadas' };
  const rows = await Promise.all(cats.map(async (c) => ({ ...conId(c), perfumes: await col('perfumes').countDocuments({ [campo[c.tipo]]: c.nombre }) })));
  res.json({
    familia: rows.filter((r) => r.tipo === 'familia'),
    ocasion: rows.filter((r) => r.tipo === 'ocasion'),
    temporada: rows.filter((r) => r.tipo === 'temporada'),
  });
});

app.get('/api/perfumes', auth(), async (req, res) => {
  const { q: texto, familia, intensidad, min, max, orden, todos, estado } = req.query;
  const multi = (k) => motor.lista(req.query[k]);
  // Filtro construido como consulta de MongoDB.
  const filtro = todos && req.user.rol === 'admin' ? {} : { estado: 'Publicado' };
  if (estado) filtro.estado = estado;
  if (familia && familia !== 'Todas') filtro.familia = familia;
  if (min || max) {
    filtro.precio = {};
    if (min) filtro.precio.$gte = Number(min);
    if (max) filtro.precio.$lte = Number(max);
  }
  if (intensidad) filtro.intensidad = intensidad;
  if (multi('ocasion').length) filtro.ocasiones = { $in: multi('ocasion') };
  if (multi('temporada').length) filtro.temporadas = { $in: multi('temporada') };
  if (multi('publico').length) filtro.publico = { $in: multi('publico') };
  if (texto) {
    const re = { $regex: escRegex(String(texto).trim()), $options: 'i' };
    filtro.$or = ['nombre', 'marca', 'familia', 'notas_salida', 'notas_corazon', 'notas_fondo'].map((c) => ({ [c]: re }));
  }
  const rows = await col('perfumes').find(filtro).sort({ _id: 1 }).toArray();

  const pref = req.user.rol === 'cliente' ? req.user.preferencias : null;
  const favs = new Set((req.user.favoritos || []).map((f) => f.perfume_id));
  const out = rows.map((p) => ({ ...perfumeResumen(p), match: motor.coincidenciaPerfil(p, pref)?.porcentaje ?? null, favorito: favs.has(p._id) }));
  if (orden === 'precio_asc') out.sort((a, b) => a.precio - b.precio);
  else if (orden === 'precio_desc') out.sort((a, b) => b.precio - a.precio);
  else if (orden === 'nombre') out.sort((a, b) => a.nombre.localeCompare(b.nombre, 'es'));
  else if (pref) out.sort((a, b) => (b.match ?? 0) - (a.match ?? 0));
  res.json(out);
});

app.get('/api/perfumes/:id', auth(), async (req, res) => {
  const p = await perfumePorId(req.params.id);
  if (!p || (p.estado !== 'Publicado' && req.user.rol !== 'admin')) return fail(res, 404, 'Perfume no encontrado.');
  // El asesor puede ver la coincidencia con un cliente concreto.
  const clienteId = req.user.rol === 'cliente' ? req.user._id : idNum(req.query.cliente);
  const pref = await preferenciasDe(clienteId);
  const favorito = (req.user.favoritos || []).some((f) => f.perfume_id === p._id);
  if (req.user.rol === 'cliente') await registrarEvento('consulta', p, req.user._id);
  const publicados = await perfumesPublicados();
  res.json({
    perfume: perfumeResumen(p),
    favorito,
    match: motor.coincidenciaPerfil(p, pref),
    similares: motor.similares(conId(p), publicados).map((s) => ({ ...perfumeResumen({ _id: s.perfume.id, ...s.perfume }), porcentaje: s.porcentaje })),
  });
});

// ---------- buscador inteligente ----------
function etiquetaCriterios(c) {
  return [c.ocasion, c.temporada, c.familia, c.intensidad, c.presupuesto && motor.PRESUPUESTOS[c.presupuesto]?.etiqueta]
    .filter(Boolean).join(' · ');
}

app.post('/api/buscador', auth(), async (req, res) => {
  const c = req.body?.criterios || {};
  const clienteId = req.user.rol === 'cliente' ? req.user._id : idNum(req.body?.cliente_id);
  const pref = await preferenciasDe(clienteId);
  // Si no llegan pesos, se usan los que el cliente guardó (o los predeterminados).
  const pesos = motor.normalizarPesos(req.body?.pesos ?? pref?.pesos);
  const catalogo = await perfumesPublicados();
  // Posición con los pesos predeterminados, para mostrar cómo cambia el ranking al ajustar los pesos.
  const posBase = Object.fromEntries(motor.ranking(catalogo, c).map((r, i) => [r.perfume.id, i + 1]));
  const resultados = motor.ranking(catalogo, c, pesos).map((r, i) => ({
    perfume: r.perfume, porcentaje: r.porcentaje, coincide: r.coincide, noCoincide: r.noCoincide,
    perfil: motor.coincidenciaPerfil(r.perfume, pref)?.porcentaje ?? null,
    posicion: i + 1, posicionBase: posBase[r.perfume.id],
  }));
  const seleccionados = Object.values(c).filter((v) => v && (!Array.isArray(v) || v.length)).length;

  // Solo se registra cuando el usuario lo pide (al terminar de responder), no en cada clic.
  if (req.body?.registrar && seleccionados && clienteId) {
    const utiles = resultados.filter((r) => r.porcentaje > 0);
    const autor = req.user.rol === 'cliente' ? 'Sistema' : req.user.nombre;
    await registrarActividad(clienteId, 'Búsqueda', etiquetaCriterios(c), `${utiles.length} resultados`, autor);
    await registrarEvento('busqueda', null, clienteId, { familia: c.familia, ocasion: c.ocasion, temporada: c.temporada });
    if (utiles[0]) {
      await registrarActividad(clienteId, 'Recomendación', `${utiles[0].perfume.nombre} sugerido por el sistema`, `${utiles[0].porcentaje}% coincidencia`, autor);
      await registrarEvento('recomendacion', utiles[0].perfume, clienteId, { ocasion: c.ocasion, temporada: c.temporada });
    }
  }
  res.json({ seleccionados, resultados, pesos, pesosBase: motor.PESOS });
});

// ---------- preferencias / perfil del cliente ----------
// Las preferencias son un subdocumento embebido en el usuario.
async function guardarPreferencias(usuarioId, body) {
  const actual = (await preferenciasDe(usuarioId)) || {};
  const v = (k) => (body[k] !== undefined ? (body[k] || null) : actual[k] ?? null);
  // Pesos: objeto → se guardan validados; null → vuelven a los predeterminados; ausente → se conservan.
  const pesos = body.pesos === undefined ? actual.pesos ?? null
    : body.pesos === null ? null : motor.normalizarPesos(body.pesos);
  const preferencias = {
    familia: v('familia'),
    ocasiones: body.ocasiones !== undefined ? motor.lista(body.ocasiones) : actual.ocasiones || [],
    temporada: v('temporada'), intensidad: v('intensidad'), presupuesto: v('presupuesto'),
    notas_evita: v('notas_evita'), pesos,
  };
  await col('usuarios').updateOne({ _id: usuarioId }, { $set: { preferencias: cifrado.cifrarPreferencias(preferencias) } });
  return preferencias;
}

app.put('/api/preferencias', auth('cliente'), async (req, res) => {
  const pref = await guardarPreferencias(req.user._id, req.body || {});
  await registrarActividad(req.user._id, 'Preferencias', 'Actualizó sus preferencias', 'Perfil actualizado');
  res.json(pref);
});

async function favoritosDe(usuario) {
  const favs = [...(usuario.favoritos || [])].sort((a, b) => b.fecha - a.fecha);
  const perfumes = await col('perfumes').find({ _id: { $in: favs.map((f) => f.perfume_id) } }).toArray();
  return favs.map((f) => perfumes.find((p) => p._id === f.perfume_id)).filter(Boolean).map(perfumeResumen);
}

async function perfilOlfativo(usuario) {
  const puntos = {};
  const sumar = (f, n) => { if (f) puntos[f] = (puntos[f] || 0) + n; };
  sumar(usuario.preferencias?.familia, 4);
  for (const p of await favoritosDe(usuario)) sumar(p.familia, 2);
  const busquedas = await col('eventos').aggregate([
    { $match: { usuario_id: usuario._id, tipo: { $in: ['busqueda', 'consulta'] }, familia: { $ne: null } } },
    { $group: { _id: '$familia', n: { $sum: 1 } } },
  ]).toArray();
  for (const r of busquedas) sumar(r._id, 0.5 * r.n);
  // Porcentaje = participación de cada familia en la afinidad total del cliente.
  const total = Object.values(puntos).reduce((a, b) => a + b, 0) || 1;
  return Object.entries(puntos)
    .map(([familia, p]) => ({ familia, porcentaje: Math.round((p / total) * 100) }))
    .sort((a, b) => b.porcentaje - a.porcentaje)
    .slice(0, 5);
}

const actividadDe = async (usuarioId, limite) =>
  (await col('actividad').find({ usuario_id: usuarioId }).sort({ fecha: -1, _id: -1 }).limit(limite).toArray())
    .map((a) => conId({ ...a, detalle: cifrado.descifrar(a.detalle) }));

app.get('/api/perfil', auth('cliente'), async (req, res) => {
  res.json({
    usuario: usuarioPublico(req.user),
    preferencias: req.user.preferencias || null,
    perfilOlfativo: await perfilOlfativo(req.user),
    favoritos: await favoritosDe(req.user),
    actividad: await actividadDe(req.user._id, 100),
  });
});

app.put('/api/perfil', auth(), async (req, res) => {
  const { nombre, telefono, correo, password_actual, password_nueva } = req.body || {};
  if (!nombre || String(nombre).trim().length < 3) return fail(res, 400, 'Escribe tu nombre completo.');
  if (!EMAIL_RE.test(normCorreo(correo))) return fail(res, 400, 'Escribe un correo electrónico válido.');
  const otro = await col('usuarios').findOne({ correo: normCorreo(correo), _id: { $ne: req.user._id } });
  if (otro) return fail(res, 409, 'Ese correo ya está en uso.');
  const tel = telefono ? String(telefono).trim() : null;
  const cambios = { nombre: String(nombre).trim(), telefono: cifrado.cifrar(tel), telefono_hash: cifrado.hashTelefono(tel), correo: normCorreo(correo) };
  if (password_nueva) {
    if (!verifyPassword(String(password_actual || ''), req.user.password_hash)) {
      await auditar(req, 'Cambio de contraseña rechazado', false);
      return fail(res, 400, 'La contraseña actual no es correcta.');
    }
    const errPw = seg.validarPassword(password_nueva, { correo, nombre });
    if (errPw) return fail(res, 400, errPw);
    cambios.password_hash = hashPassword(String(password_nueva));
  }
  await col('usuarios').updateOne({ _id: req.user._id }, { $set: cambios });
  if (password_nueva) {
    // Al cambiar la contraseña se cierran las demás sesiones abiertas.
    await col('sesiones').deleteMany({ usuario_id: req.user._id, _id: { $ne: req.token } });
    await auditar(req, 'Cambio de contraseña', true);
  }
  res.json({ usuario: usuarioPublico(cifrado.descifrarUsuario(await col('usuarios').findOne({ _id: req.user._id }))) });
});

// Derecho de cancelación (ARCO): el cliente puede eliminar su cuenta.
// Preferencias y favoritos se borran con el documento; el uso agregado queda anónimo.
app.delete('/api/perfil', auth('cliente'), async (req, res) => {
  const id = req.user._id;
  await col('eventos').updateMany({ usuario_id: id }, { $set: { usuario_id: null } });
  await col('ventas').updateMany({ cliente_id: id }, { $set: { cliente_id: null } });
  await col('actividad').deleteMany({ usuario_id: id });
  await col('sesiones').deleteMany({ usuario_id: id });
  await col('usuarios').deleteOne({ _id: id });
  await auditar(req, 'Cuenta eliminada por el cliente (derecho ARCO)', true);
  res.json({ ok: true });
});

// ---------- favoritos y comparador ----------
app.post('/api/favoritos/:id', auth('cliente'), async (req, res) => {
  const p = await perfumePorId(req.params.id, true);
  if (!p) return fail(res, 404, 'Perfume no encontrado.');
  // $push condicionado: solo se agrega si el perfume aún no está en el arreglo de favoritos.
  const r = await col('usuarios').updateOne(
    { _id: req.user._id, 'favoritos.perfume_id': { $ne: p._id } },
    { $push: { favoritos: { perfume_id: p._id, fecha: new Date(), precio_guardado: p.precio } } });
  if (r.modifiedCount) {
    await registrarActividad(req.user._id, 'Favorito', `Agregó ${p.nombre} a favoritos`);
    await registrarEvento('favorito', p, req.user._id);
    await marcarRecomendacionAceptada(req.user._id, p._id);
  }
  res.json({ favorito: true });
});

app.delete('/api/favoritos/:id', auth('cliente'), async (req, res) => {
  await col('usuarios').updateOne({ _id: req.user._id }, { $pull: { favoritos: { perfume_id: idNum(req.params.id) } } });
  res.json({ favorito: false });
});

app.get('/api/comparar', auth(), async (req, res) => {
  const ids = motor.lista(req.query.ids).map(Number).filter(Boolean).slice(0, 3);
  const clienteId = req.user.rol === 'cliente' ? req.user._id : idNum(req.query.cliente);
  const pref = await preferenciasDe(clienteId);
  const docs = await col('perfumes').find({ _id: { $in: ids }, estado: 'Publicado' }).toArray();
  const items = ids.map((id) => docs.find((p) => p._id === id)).filter(Boolean)
    .map((p) => ({ ...perfumeResumen(p), match: motor.coincidenciaPerfil(p, pref)?.porcentaje ?? null }));
  res.json(items);
});

app.post('/api/comparar/elegir', auth(), async (req, res) => {
  const { ids = [], elegido, cliente_id } = req.body || {};
  const usuarioId = req.user.rol === 'cliente' ? req.user._id : idNum(cliente_id);
  const docs = await col('perfumes').find({ _id: { $in: ids.map(Number) } }, { projection: { nombre: 1 } }).toArray();
  const nombres = ids.map((id) => docs.find((d) => d._id === Number(id))?.nombre).filter(Boolean);
  const eleg = await perfumePorId(elegido);
  if (usuarioId && eleg && nombres.length >= 2) {
    await registrarActividad(usuarioId, 'Comparación', nombres.join(' vs '), `Eligió ${eleg.nombre}`,
      req.user.rol === 'cliente' ? 'Sistema' : req.user.nombre);
    await marcarRecomendacionAceptada(usuarioId, eleg._id);
  }
  res.json({ ok: true });
});

// ---------- asesor de ventas ----------
const TIPOS_VISITA = ['Atención en tienda', 'Visita en tienda', 'Recomendación del asesor', 'Búsqueda'];

async function resumenCliente(u, ultima) {
  if (ultima === undefined) ultima = (await col('actividad').find({ usuario_id: u._id }).sort({ fecha: -1 }).limit(1).toArray())[0]?.fecha ?? null;
  return {
    ...usuarioPublico(u),
    preferencias: u.preferencias || null,
    visitas: await col('actividad').countDocuments({ usuario_id: u._id, tipo: { $in: TIPOS_VISITA } }),
    favoritos: (u.favoritos || []).length,
    ultima,
  };
}

app.get('/api/clientes', auth('asesor', 'admin'), async (req, res) => {
  const t = String(req.query.q || '').trim();
  const filtro = { rol: 'cliente' };
  if (t) {
    const re = { $regex: escRegex(t), $options: 'i' };
    const digitos = t.replace(/\D/g, '');
    filtro.$or = [{ nombre: re }, { correo: re }];
    // El teléfono está cifrado: se busca por coincidencia exacta con su índice ciego (HMAC).
    if (digitos.length >= 7) filtro.$or.push({ telefono_hash: cifrado.hashTelefono(digitos) });
  }
  const clientes = (await col('usuarios').find(filtro).toArray()).map(cifrado.descifrarUsuario);
  // Última actividad de cada cliente con una agregación ($group + $max).
  const ultimas = await col('actividad').aggregate([
    { $match: { usuario_id: { $in: clientes.map((c) => c._id) } } },
    { $group: { _id: '$usuario_id', ultima: { $max: '$fecha' } } },
  ]).toArray();
  const ult = Object.fromEntries(ultimas.map((r) => [r._id, r.ultima]));
  const orden = clientes.sort((a, b) => (ult[b._id] || 0) - (ult[a._id] || 0)).slice(0, 50);
  res.json(await Promise.all(orden.map((u) => resumenCliente(u, ult[u._id] ?? null))));
});

app.get('/api/clientes/:id', auth('asesor', 'admin'), async (req, res) => {
  const u = await clientePorId(req.params.id);
  if (!u) return fail(res, 404, 'Cliente no encontrado.');
  const pref = u.preferencias;
  const recomendaciones = pref
    ? (await perfumesPublicados()).map((p) => ({ perfume: p, ...motor.coincidenciaPerfil(p, pref) }))
      .sort((a, b) => b.porcentaje - a.porcentaje).slice(0, 3)
    : [];
  res.json({
    cliente: await resumenCliente(u),
    recomendaciones,
    favoritos: await favoritosDe(u),
    historial: await actividadDe(u._id, 50),
  });
});

app.post('/api/clientes/:id/preferencias', auth('asesor'), async (req, res) => {
  const u = await clientePorId(req.params.id);
  if (!u) return fail(res, 404, 'Cliente no encontrado.');
  const { familia, ocasion, temporada, presupuesto, notas_evita, notas } = req.body || {};
  const actual = u.preferencias || {};
  const ocasiones = [...new Set([ocasion, ...motor.lista(actual.ocasiones)].filter(Boolean))].slice(0, 3);
  await guardarPreferencias(u._id, {
    familia: familia || actual.familia, ocasiones, temporada: temporada || actual.temporada,
    presupuesto: presupuesto || actual.presupuesto, notas_evita: notas_evita ?? actual.notas_evita,
  });
  const detalle = [`Registró preferencia: ${[familia, ocasion, temporada, presupuesto && motor.PRESUPUESTOS[presupuesto]?.etiqueta].filter(Boolean).join(' · ')}`,
    notas_evita ? `Evita: ${notas_evita}` : '', notas ? String(notas).slice(0, 300) : ''].filter(Boolean).join('. ');
  await registrarActividad(u._id, 'Atención en tienda', detalle, 'Perfil actualizado', req.user.nombre);
  res.json({ ok: true });
});

app.post('/api/clientes/:id/recomendar', auth('asesor'), async (req, res) => {
  const u = await clientePorId(req.params.id);
  const p = await perfumePorId(req.body?.perfume_id, true);
  if (!u || !p) return fail(res, 404, 'Cliente o perfume no encontrado.');
  const m = motor.coincidenciaPerfil(p, u.preferencias);
  await registrarActividad(u._id, 'Recomendación del asesor', `Se recomendó ${p.nombre}${req.body?.nota ? '. ' + req.body.nota : ''}`,
    m ? `${m.porcentaje}% coincidencia` : 'Registrada', req.user.nombre);
  await registrarEvento('recomendacion', p, u._id);
  res.json({ ok: true });
});

// ---------- administración ----------
const CONCENTRACIONES = ['Eau de Cologne', 'Eau de Toilette', 'Eau de Parfum', 'Extrait de Parfum'];

function validarPerfume(b) {
  const errores = [];
  if (!b.nombre?.trim()) errores.push('nombre');
  if (!b.marca?.trim()) errores.push('marca');
  if (!b.familia) errores.push('familia olfativa');
  if (!CONCENTRACIONES.includes(b.concentracion)) errores.push('concentración');
  if (!(Number(b.precio) > 0)) errores.push('precio');
  if (!(Number(b.ml) > 0)) errores.push('mililitros');
  if (b.anio && !(Number(b.anio) >= 1700 && Number(b.anio) <= new Date().getFullYear() + 1)) errores.push('año de lanzamiento');
  if (!['Suave', 'Moderada', 'Intensa'].includes(b.intensidad)) errores.push('intensidad');
  const img = b.imagen || '';
  const imgValida = /^data:image\/(png|jpe?g|webp);base64,/.test(img) ? img.length <= 2.8e6
    : /^https:\/\/[^\s"'<>]+$/.test(img) || /^\/img\/perfumes\/[\w.-]+\.(jpe?g|png|webp)$/.test(img);
  if (img && !imgValida) errores.push('imagen (PNG, JPG o WEBP de máximo 2 MB, o un enlace https)');
  return errores;
}

function datosPerfume(b) {
  return {
    nombre: b.nombre.trim(), marca: b.marca.trim(), familia: b.familia, subfamilia: b.subfamilia || null,
    concentracion: b.concentracion, ml: Math.round(Number(b.ml)), precio: Number(b.precio), intensidad: b.intensidad,
    publico: b.publico || 'Unisex', ocasiones: motor.lista(b.ocasiones), temporadas: motor.lista(b.temporadas),
    notas_salida: b.notas_salida || null, notas_corazon: b.notas_corazon || null, notas_fondo: b.notas_fondo || null,
    descripcion: b.descripcion || null, duracion: b.duracion || null, proyeccion: b.proyeccion || null,
    color: b.color || '#8B4A2B', imagen: b.imagen || null, estado: b.estado === 'Borrador' ? 'Borrador' : 'Publicado',
    anio: b.anio ? Math.round(Number(b.anio)) : null, perfumista: b.perfumista?.trim() || null,
  };
}

app.post('/api/admin/perfumes', auth('admin'), bitacora('Perfume creado'), async (req, res) => {
  const errores = validarPerfume(req.body || {});
  if (errores.length) return fail(res, 400, `Revisa: ${errores.join(', ')}.`);
  const doc = { _id: await siguienteId(db, 'perfumes'), ...datosPerfume(req.body), existencias: 10, tiempo_entrega: 7, creado: new Date() };
  await col('perfumes').insertOne(doc);
  res.status(201).json(perfumeResumen(doc));
});

app.put('/api/admin/perfumes/:id', auth('admin'), bitacora('Perfume editado'), async (req, res) => {
  const p = await perfumePorId(req.params.id);
  if (!p) return fail(res, 404, 'Perfume no encontrado.');
  const errores = validarPerfume(req.body || {});
  if (errores.length) return fail(res, 400, `Revisa: ${errores.join(', ')}.`);
  await col('perfumes').updateOne({ _id: p._id }, { $set: datosPerfume(req.body) });
  res.json(perfumeResumen(await col('perfumes').findOne({ _id: p._id })));
});

app.delete('/api/admin/perfumes/:id', auth('admin'), bitacora('Perfume eliminado'), async (req, res) => {
  const id = idNum(req.params.id);
  const r = await col('perfumes').deleteOne({ _id: id });
  if (!r.deletedCount) return fail(res, 404, 'Perfume no encontrado.');
  // Sin claves foráneas: se limpian las referencias a mano.
  await col('usuarios').updateMany({ 'favoritos.perfume_id': id }, { $pull: { favoritos: { perfume_id: id } } });
  await col('eventos').updateMany({ perfume_id: id }, { $set: { perfume_id: null } });
  await col('ventas').updateMany({ perfume_id: id }, { $set: { perfume_id: null } });
  res.json({ ok: true });
});

const CAMPO_CATEGORIA = { familia: 'familia', ocasion: 'ocasiones', temporada: 'temporadas' };

app.post('/api/admin/categorias', auth('admin'), bitacora('Categoría creada'), async (req, res) => {
  const { tipo, nombre, descripcion, color } = req.body || {};
  if (!CAMPO_CATEGORIA[tipo]) return fail(res, 400, 'Tipo de categoría no válido.');
  if (!nombre?.trim()) return fail(res, 400, 'Escribe el nombre de la categoría.');
  if (await col('categorias').findOne({ tipo, nombre: nombre.trim() })) return fail(res, 409, 'Ya existe una categoría con ese nombre.');
  try {
    await col('categorias').insertOne({ _id: await siguienteId(db, 'categorias'), tipo, nombre: nombre.trim(), descripcion: descripcion || null, color: color || '#16130F' });
  } catch (e) { if (e.code === 11000) return fail(res, 409, 'Ya existe una categoría con ese nombre.'); throw e; }
  res.status(201).json({ ok: true });
});

app.put('/api/admin/categorias/:id', auth('admin'), bitacora('Categoría editada'), async (req, res) => {
  const c = await col('categorias').findOne({ _id: idNum(req.params.id) });
  if (!c) return fail(res, 404, 'Categoría no encontrada.');
  const { nombre, descripcion, color } = req.body || {};
  if (!nombre?.trim()) return fail(res, 400, 'Escribe el nombre de la categoría.');
  const nuevo = nombre.trim();
  if (nuevo !== c.nombre && await col('categorias').findOne({ tipo: c.tipo, nombre: nuevo })) return fail(res, 409, 'Ya existe una categoría con ese nombre.');
  await col('categorias').updateOne({ _id: c._id }, { $set: { nombre: nuevo, descripcion: descripcion || null, color: color || c.color } });
  // Mantiene coherentes los documentos que usan la categoría si se renombra.
  if (nuevo !== c.nombre) {
    const campo = CAMPO_CATEGORIA[c.tipo];
    if (c.tipo === 'familia') {
      await col('perfumes').updateMany({ familia: c.nombre }, { $set: { familia: nuevo } });
      await col('eventos').updateMany({ familia: c.nombre }, { $set: { familia: nuevo } });
      await col('usuarios').updateMany({ 'preferencias.familia': c.nombre }, { $set: { 'preferencias.familia': nuevo } });
    } else {
      for (const p of await col('perfumes').find({ [campo]: c.nombre }).toArray()) {
        await col('perfumes').updateOne({ _id: p._id }, { $set: { [campo]: p[campo].map((x) => (x === c.nombre ? nuevo : x)) } });
      }
      const campoEv = c.tipo === 'ocasion' ? 'ocasion' : 'temporada';
      await col('eventos').updateMany({ [campoEv]: c.nombre }, { $set: { [campoEv]: nuevo } });
    }
  }
  res.json({ ok: true });
});

app.delete('/api/admin/categorias/:id', auth('admin'), bitacora('Categoría eliminada'), async (req, res) => {
  const c = await col('categorias').findOne({ _id: idNum(req.params.id) });
  if (!c) return fail(res, 404, 'Categoría no encontrada.');
  const usados = await col('perfumes').countDocuments({ [CAMPO_CATEGORIA[c.tipo]]: c.nombre });
  if (usados) return fail(res, 409, `No se puede eliminar: ${usados} perfume(s) usan esta categoría.`);
  await col('categorias').deleteOne({ _id: c._id });
  res.json({ ok: true });
});

// Rango del periodo seleccionado y del periodo anterior equivalente.
function periodo(dias) {
  const d = Math.min(Math.max(Number(dias) || 30, 7), 365);
  const fin = new Date();
  const ini = new Date(fin.getTime() - d * 864e5);
  const iniPrev = new Date(ini.getTime() - d * 864e5);
  return { d, ini, fin, iniPrev };
}

function ultimos12Meses() {
  const hoy = new Date();
  const meses = [];
  for (let i = 11; i >= 0; i--) meses.push(new Date(Date.UTC(hoy.getUTCFullYear(), hoy.getUTCMonth() - i, 1)).toISOString().slice(0, 7));
  return meses;
}

const MES = { $dateToString: { format: '%Y-%m', date: '$fecha' } };

async function dashboard(dias) {
  const p = periodo(dias);
  const ev = col('eventos');
  const contar = (tipo, a, b) => ev.countDocuments({ tipo, fecha: { $gte: a, $lt: b } });
  const aceptacion = async (a, b) => {
    const [r] = await ev.aggregate([
      { $match: { tipo: 'recomendacion', fecha: { $gte: a, $lt: b } } },
      { $group: { _id: null, t: { $sum: 1 }, a: { $sum: { $cond: ['$aceptada', 1, 0] } } } },
    ]).toArray();
    return r?.t ? Math.round((r.a / r.t) * 100) : 0;
  };
  const delta = (act, prev) => (prev ? Math.round(((act - prev) / prev) * 1000) / 10 : null);

  const [consultas, consultasPrev, recs, recsPrev, acep, acepPrev] = await Promise.all([
    contar('consulta', p.ini, p.fin), contar('consulta', p.iniPrev, p.ini),
    contar('recomendacion', p.ini, p.fin), contar('recomendacion', p.iniPrev, p.ini),
    aceptacion(p.ini, p.fin), aceptacion(p.iniPrev, p.ini),
  ]);
  const conPerfil = { rol: 'cliente', preferencias: { $ne: null } };
  const clientes = await col('usuarios').countDocuments(conPerfil);
  const clientesPrev = await col('usuarios').countDocuments({ ...conPerfil, creado: { $lt: p.ini } });

  const familias = (await ev.aggregate([
    { $match: { tipo: { $in: ['consulta', 'busqueda'] }, familia: { $ne: null }, fecha: { $gte: p.ini, $lt: p.fin } } },
    { $group: { _id: '$familia', n: { $sum: 1 } } },
    { $sort: { n: -1 } },
  ]).toArray()).map((r) => ({ familia: r._id, n: r.n }));

  const ocasionesRows = await ev.aggregate([
    { $match: { ocasion: { $ne: null }, fecha: { $gte: p.ini, $lt: p.fin } } },
    { $group: { _id: '$ocasion', n: { $sum: 1 } } },
    { $sort: { n: -1 } },
  ]).toArray();
  const totalOc = ocasionesRows.reduce((a, r) => a + r.n, 0) || 1;

  // Tendencia de búsquedas por temporada: últimos 12 meses.
  const meses = ultimos12Meses();
  const tRows = await ev.aggregate([
    { $match: { fecha: { $gte: new Date(`${meses[0]}-01T00:00:00Z`) } } },
    { $group: {
      _id: MES,
      frio: { $sum: { $cond: [{ $in: ['$temporada', ['Otoño', 'Invierno']] }, 1, 0] } },
      calido: { $sum: { $cond: [{ $in: ['$temporada', ['Primavera', 'Verano']] }, 1, 0] } },
    } },
  ]).toArray();
  const tMap = Object.fromEntries(tRows.map((r) => [r._id, r]));
  const tendencia = meses.map((m) => ({ mes: m, frio: tMap[m]?.frio || 0, calido: tMap[m]?.calido || 0 }));

  // Perfumes más recomendados: periodo actual vs anterior y favoritos (embebidos en usuarios).
  const enRango = (a, b) => ({ $and: [{ $gte: ['$fecha', a] }, { $lt: ['$fecha', b] }] });
  const porPerfume = await ev.aggregate([
    { $match: { perfume_id: { $ne: null }, fecha: { $gte: p.iniPrev, $lt: p.fin } } },
    { $group: {
      _id: '$perfume_id',
      recomendaciones: { $sum: { $cond: [{ $and: [{ $eq: ['$tipo', 'recomendacion'] }, enRango(p.ini, p.fin)] }, 1, 0] } },
      prev: { $sum: { $cond: [{ $and: [{ $eq: ['$tipo', 'recomendacion'] }, enRango(p.iniPrev, p.ini)] }, 1, 0] } },
      favEventos: { $sum: { $cond: [{ $and: [{ $eq: ['$tipo', 'favorito'] }, enRango(p.ini, p.fin)] }, 1, 0] } },
    } },
  ]).toArray();
  const favGuardados = await col('usuarios').aggregate([
    { $unwind: '$favoritos' },
    { $group: { _id: '$favoritos.perfume_id', n: { $sum: 1 } } },
  ]).toArray();
  const pp = Object.fromEntries(porPerfume.map((r) => [r._id, r]));
  const fg = Object.fromEntries(favGuardados.map((r) => [r._id, r.n]));
  const top = (await perfumesPublicados()).map((x) => ({
    id: x.id, nombre: x.nombre, familia: x.familia, color: x.color,
    recomendaciones: pp[x.id]?.recomendaciones || 0, prev: pp[x.id]?.prev || 0,
    favoritos: (fg[x.id] || 0) + (pp[x.id]?.favEventos || 0),
  })).map((r) => ({ ...r, tendencia: delta(r.recomendaciones, r.prev) }))
    .sort((a, b) => b.recomendaciones - a.recomendaciones);

  return {
    periodo: { d: p.d, ini: fechaTxt(p.ini), fin: fechaTxt(p.fin), iniPrev: fechaTxt(p.iniPrev) },
    kpis: {
      consultas: { valor: consultas, delta: delta(consultas, consultasPrev) },
      recomendaciones: { valor: recs, delta: delta(recs, recsPrev) },
      clientes: { valor: clientes, delta: delta(clientes, clientesPrev) },
      aceptacion: { valor: acep, puntos: acep - acepPrev },
    },
    familias,
    ocasiones: ocasionesRows.map((r) => ({ ocasion: r._id, n: r.n, porcentaje: Math.round((r.n / totalOc) * 100) })),
    tendencia,
    top,
  };
}

app.get('/api/admin/dashboard', auth('admin'), async (req, res) => res.json(await dashboard(req.query.dias)));

app.get('/api/admin/familia/:familia', auth('admin'), async (req, res) => {
  const p = periodo(req.query.dias);
  const f = req.params.familia;
  const consultas = await col('eventos').aggregate([
    { $match: { tipo: 'consulta', familia: f, perfume_id: { $ne: null }, fecha: { $gte: p.ini, $lt: p.fin } } },
    { $group: { _id: '$perfume_id', n: { $sum: 1 } } },
  ]).toArray();
  const perfumes = (await col('perfumes').find({ familia: f }).toArray())
    .map((x) => ({ nombre: x.nombre, color: x.color, consultas: consultas.find((c) => c._id === x._id)?.n || 0 }))
    .sort((a, b) => b.consultas - a.consultas);
  const ocasiones = (await col('eventos').aggregate([
    { $match: { familia: f, ocasion: { $ne: null }, fecha: { $gte: p.ini, $lt: p.fin } } },
    { $group: { _id: '$ocasion', n: { $sum: 1 } } },
    { $sort: { n: -1 } },
  ]).toArray()).map((r) => ({ ocasion: r._id, n: r.n }));
  res.json({ familia: f, perfumes, ocasiones });
});

app.get('/api/admin/tendencias', auth('admin'), async (req, res) => {
  const meses = ultimos12Meses();
  const rows = await col('eventos').aggregate([
    { $match: { familia: { $ne: null }, fecha: { $gte: new Date(`${meses[0]}-01T00:00:00Z`) } } },
    { $group: { _id: { mes: MES, familia: '$familia' }, n: { $sum: 1 } } },
  ]).toArray();
  const colores = Object.fromEntries((await col('categorias').find({ tipo: 'familia' }).toArray()).map((c) => [c.nombre, c.color]));
  const familias = [...new Set(rows.map((r) => r._id.familia))];
  const series = familias.map((f) => ({
    familia: f,
    color: colores[f] || '#888',
    valores: meses.map((m) => rows.find((r) => r._id.mes === m && r._id.familia === f)?.n || 0),
  }));
  // Crecimiento: últimos 3 meses completos vs 3 anteriores.
  const crecimiento = series.map((s) => {
    const a = s.valores.slice(8, 11).reduce((x, y) => x + y, 0);
    const b = s.valores.slice(5, 8).reduce((x, y) => x + y, 0);
    return { familia: s.familia, color: s.color, reciente: a, anterior: b, cambio: b ? Math.round(((a - b) / b) * 100) : null };
  }).sort((x, y) => (y.cambio ?? 0) - (x.cambio ?? 0));
  // Intensidad y rango de precio preferidos (últimos 3 meses): agregación por perfume y cruce con el catálogo.
  const porPerfume = await col('eventos').aggregate([
    { $match: { perfume_id: { $ne: null }, fecha: { $gte: new Date(`${meses[9]}-01T00:00:00Z`) } } },
    { $group: { _id: '$perfume_id', n: { $sum: 1 } } },
  ]).toArray();
  const perfumes = Object.fromEntries((await col('perfumes').find({}).toArray()).map((x) => [x._id, x]));
  const acumular = (fn) => {
    const m = {};
    for (const r of porPerfume) { const x = perfumes[r._id]; if (x) m[fn(x)] = (m[fn(x)] || 0) + r.n; }
    return m;
  };
  const intensidad = Object.entries(acumular((x) => x.intensidad)).map(([k, n]) => ({ intensidad: k, n }));
  const presupuesto = Object.entries(acumular((x) => motor.PRESUPUESTOS[motor.presupuestoDePrecio(x.precio)].etiqueta)).map(([k, n]) => ({ rango: k, n }));
  res.json({ meses, series, crecimiento, intensidad, presupuesto, rangos: Object.values(motor.PRESUPUESTOS).map((r) => r.etiqueta) });
});

app.get('/api/admin/reporte.csv', auth('admin'), async (req, res) => {
  const d = await dashboard(req.query.dias);
  const esc = (v) => `"${String(v ?? '').replace(/"/g, '""')}"`;
  const lineas = [
    ['Reporte The Arabic Corner', `Últimos ${d.periodo.d} días`, `Generado ${fechaTxt(new Date())}`],
    [],
    ['Indicador', 'Valor', 'Cambio vs periodo anterior'],
    ['Consultas al catálogo', d.kpis.consultas.valor, d.kpis.consultas.delta != null ? `${d.kpis.consultas.delta}%` : ''],
    ['Recomendaciones generadas', d.kpis.recomendaciones.valor, d.kpis.recomendaciones.delta != null ? `${d.kpis.recomendaciones.delta}%` : ''],
    ['Clientes con perfil', d.kpis.clientes.valor, d.kpis.clientes.delta != null ? `${d.kpis.clientes.delta}%` : ''],
    ['Aceptación de recomendaciones', `${d.kpis.aceptacion.valor}%`, `${d.kpis.aceptacion.puntos} pts`],
    [],
    ['Familia olfativa', 'Consultas'], ...d.familias.map((f) => [f.familia, f.n]),
    [],
    ['Ocasión', 'Búsquedas', '%'], ...d.ocasiones.map((o) => [o.ocasion, o.n, `${o.porcentaje}%`]),
    [],
    ['Mes', 'Otoño / Invierno', 'Primavera / Verano'], ...d.tendencia.map((t) => [t.mes, t.frio, t.calido]),
    [],
    ['#', 'Perfume', 'Familia', 'Recomendaciones', 'Favoritos', 'Tendencia'],
    ...d.top.map((t, i) => [i + 1, t.nombre, t.familia, t.recomendaciones, t.favoritos, t.tendencia != null ? `${t.tendencia}%` : '']),
  ];
  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', `attachment; filename="reporte_the_arabic_corner_${fechaTxt(new Date()).slice(0, 10)}.csv"`);
  res.send('﻿' + lineas.map((l) => l.map(esc).join(',')).join('\r\n'));
});

// ---------- alertas por excepción ----------
app.get('/api/alertas', auth('cliente', 'admin'), async (req, res) => {
  res.json(req.user.rol === 'admin' ? await analisis.alertasAdmin(db) : await analisis.alertasCliente(db, req.user._id));
});

// El cliente descarta el aviso de baja de precio: el precio actual pasa a ser su nueva referencia.
app.post('/api/alertas/precio/:id/visto', auth('cliente'), async (req, res) => {
  const p = await perfumePorId(req.params.id);
  if (p) {
    const favoritos = (req.user.favoritos || []).map((f) => (f.perfume_id === p._id ? { ...f, precio_guardado: p.precio } : f));
    await col('usuarios').updateOne({ _id: req.user._id }, { $set: { favoritos } });
  }
  res.json({ ok: true });
});

// ---------- ventas en tienda (asesor) ----------
app.post('/api/ventas', auth('asesor'), bitacora('Venta registrada'), async (req, res) => {
  const { perfume_id, cliente_id } = req.body || {};
  const cantidad = Math.floor(Number(req.body?.cantidad) || 0);
  const p = await perfumePorId(perfume_id, true);
  if (!p) return fail(res, 404, 'Perfume no encontrado.');
  if (cantidad < 1) return fail(res, 400, 'La cantidad debe ser al menos 1.');
  // Descuento atómico: solo se aplica si hay existencias suficientes en ese momento.
  const r = await col('perfumes').updateOne({ _id: p._id, existencias: { $gte: cantidad } }, { $inc: { existencias: -cantidad } });
  if (!r.modifiedCount) {
    const actual = await col('perfumes').findOne({ _id: p._id });
    return fail(res, 409, `Solo hay ${actual?.existencias ?? 0} unidad(es) en existencia.`);
  }
  const cliente = cliente_id ? await clientePorId(cliente_id) : null;
  await col('ventas').insertOne({ perfume_id: p._id, cantidad, precio_unitario: p.precio, cliente_id: cliente?._id ?? null, asesor_id: req.user._id, fecha: new Date() });
  if (cliente) {
    await registrarActividad(cliente._id, 'Compra', `Compró ${cantidad} × ${p.nombre}`, `$${(cantidad * p.precio).toLocaleString('es-MX')}`, req.user.nombre);
    await marcarRecomendacionAceptada(cliente._id, p._id);
  }
  res.status(201).json({ existencias: p.existencias - cantidad });
});

// ---------- análisis para el administrador ----------
app.get('/api/admin/pronostico', auth('admin'), async (req, res) => res.json(await analisis.pronostico(db)));

app.get('/api/admin/inventario', auth('admin'), async (req, res) => {
  const pron = await analisis.pronostico(db);
  res.json({ inventario: await analisis.inventario(db, pron), abc: await analisis.abc(db) });
});

app.put('/api/admin/inventario/:id', auth('admin'), bitacora('Inventario ajustado'), async (req, res) => {
  const existencias = Math.floor(Number(req.body?.existencias));
  const entrega = Math.floor(Number(req.body?.tiempo_entrega));
  if (!(existencias >= 0) || !(entrega >= 1 && entrega <= 120)) return fail(res, 400, 'Revisa existencias (≥ 0) y tiempo de entrega (1 a 120 días).');
  const r = await col('perfumes').updateOne({ _id: idNum(req.params.id) }, { $set: { existencias, tiempo_entrega: entrega } });
  if (!r.matchedCount) return fail(res, 404, 'Perfume no encontrado.');
  res.json({ ok: true });
});

app.post('/api/admin/inventario/:id/entrada', auth('admin'), bitacora('Entrada de inventario'), async (req, res) => {
  const cantidad = Math.floor(Number(req.body?.cantidad));
  if (!(cantidad >= 1 && cantidad <= 10000)) return fail(res, 400, 'La cantidad debe ser entre 1 y 10,000.');
  const r = await col('perfumes').updateOne({ _id: idNum(req.params.id) }, { $inc: { existencias: cantidad } });
  if (!r.matchedCount) return fail(res, 404, 'Perfume no encontrado.');
  res.json({ ok: true });
});

app.post('/api/admin/simular', auth('admin'), async (req, res) => {
  const precio = Number(req.body?.precio);
  if (!(precio > 0 && precio < 1e6)) return fail(res, 400, 'Escribe un precio válido.');
  const r = await analisis.simularPrecio(db, idNum(req.body?.perfume_id), precio);
  if (!r) return fail(res, 404, 'Perfume no encontrado.');
  res.json(r);
});

// Aplica el precio simulado. Los clientes que lo tienen en favoritos verán la alerta si bajó.
app.post('/api/admin/perfumes/:id/precio', auth('admin'), bitacora('Precio modificado'), async (req, res) => {
  const precio = Math.round(Number(req.body?.precio) * 100) / 100;
  if (!(precio > 0 && precio < 1e6)) return fail(res, 400, 'Escribe un precio válido.');
  const r = await col('perfumes').updateOne({ _id: idNum(req.params.id) }, { $set: { precio } });
  if (!r.matchedCount) return fail(res, 404, 'Perfume no encontrado.');
  res.json({ ok: true, precio });
});

// ---------- seguridad: bitácora y estado ----------
app.get('/api/admin/auditoria', auth('admin'), async (req, res) => {
  const filtro = {};
  if (req.query.tipo === 'fallidos') filtro.exito = false;
  if (req.query.tipo === 'accesos') filtro.accion = { $regex: 'sesión|VPN|redes autorizadas|bloquead|verificación', $options: 'i' };
  if (req.query.tipo === 'cambios') filtro.accion = { $not: { $regex: 'sesión|VPN|redes autorizadas|bloquead|Registro|verificación', $options: 'i' } };
  const registros = await col('auditoria').find(filtro).sort({ fecha: -1 }).limit(300).toArray();
  const desde = new Date(Date.now() - 864e5);
  const [ok24, fallidos24, bloqueos24, bloqueadas] = await Promise.all([
    col('auditoria').countDocuments({ fecha: { $gte: desde }, accion: 'Inicio de sesión', exito: true }),
    col('auditoria').countDocuments({ fecha: { $gte: desde }, exito: false }),
    col('auditoria').countDocuments({ fecha: { $gte: desde }, accion: 'Cuenta bloqueada por intentos fallidos' }),
    col('intentos_login').countDocuments({ bloqueado_hasta: { $gt: new Date() } }),
  ]);
  const muestra = await col('usuarios').findOne({ rol: 'cliente', telefono: { $ne: null } }, { projection: { telefono: 1, telefono_hash: 1 } });
  res.json({
    registros: registros.map(conId),
    resumen: { ok24, fallidos24, bloqueos24, bloqueadas },
    estado: {
      cifradoCampos: cifrado.activo(),
      ejemploTelefonoEnBD: muestra?.telefono ? String(muestra.telefono).slice(0, 60) + (String(muestra.telefono).length > 60 ? '…' : '') : null,
      adminSoloVpn: seg.adminRestringido(), redesAdmin: seg.ADMIN_REDES,
      tlsBaseDatos: /^mongodb\+srv:/.test(process.env.MONGODB_URI || '') || /tls=true|ssl=true/.test(process.env.MONGODB_URI || ''),
      conexion: ocultarUri(process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017'),
      httpsActivo: req.headers['x-forwarded-proto'] === 'https',
      ipCliente: req.ip,
      mfaObligatoria: MFA_ADMIN, mfaActiva: !!req.user.mfa?.activo,
      administradoresConMfa: await col('usuarios').countDocuments({ rol: 'admin', 'mfa.activo': true }),
      administradores: await col('usuarios').countDocuments({ rol: 'admin' }),
      diagnosticoIp: seg.diagnosticoIp(req),
    },
  });
});

app.onError((err, req, res) => {
  console.error(err);
  if (err.code === 121) return fail(res, 400, 'El documento no cumple la validación de esquema de la base de datos.');
  fail(res, 500, 'Ocurrió un error inesperado.');
});

// ---------- arranque ----------
async function iniciar() {
  const conexion = await conectar({ reset: process.argv.includes('--reset') });
  db = conexion.db;
  await col('sesiones').deleteMany({ expira: { $lte: new Date() } }); // el índice TTL también las borra solo
  const server = app.listen(PORT, HOST, () => {
    console.log(`The Arabic Corner listo en http://${HOST === '0.0.0.0' ? 'localhost' : HOST}:${PORT}`);
    console.log(`  Cifrado de campos: ${cifrado.activo() ? 'activo (AES-256-GCM)' : 'INACTIVO (define DATA_KEY)'} · ` +
      `Panel admin: ${seg.adminRestringido() ? `solo desde ${seg.ADMIN_REDES.join(', ')}` : 'sin restricción de red'} · ` +
      `2FA de administradores: ${MFA_ADMIN ? 'obligatoria' : 'opcional'}`);
  });
  const cerrar = async () => { server.close(); await conexion.client.close(); process.exit(0); };
  process.on('SIGINT', cerrar);
  process.on('SIGTERM', cerrar);
}

if (require.main === module) {
  iniciar().catch((e) => { console.error(e.message); process.exit(1); });
}

module.exports = { app, iniciar };
