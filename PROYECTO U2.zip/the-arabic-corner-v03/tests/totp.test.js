// Pruebas de la verificación en dos pasos (vectores oficiales del RFC 6238, SHA-1).
const test = require('node:test');
const assert = require('node:assert');
const totp = require('../lib/totp');

const SECRETO_RFC = totp.base32(Buffer.from('12345678901234567890'));

test('genera los códigos del RFC 6238', () => {
  assert.strictEqual(totp.codigo(SECRETO_RFC, Math.floor(59 / 30)), '287082');
  assert.strictEqual(totp.codigo(SECRETO_RFC, Math.floor(1111111109 / 30)), '081804');
  assert.strictEqual(totp.codigo(SECRETO_RFC, Math.floor(2000000000 / 30)), '279037');
});

test('acepta el código actual y rechaza reutilizarlo', () => {
  const s = totp.generarSecreto();
  const paso = totp.pasoActual();
  assert.strictEqual(totp.verificar(s, totp.codigo(s, paso)), paso);
  assert.strictEqual(totp.verificar(s, totp.codigo(s, paso), paso), null);
});

test('rechaza códigos inválidos o vencidos', () => {
  const s = totp.generarSecreto();
  assert.strictEqual(totp.verificar(s, 'abc123'), null);
  assert.strictEqual(totp.verificar(s, totp.codigo(s, totp.pasoActual() - 5)), null);
});
