// Pruebas unitarias (node:test, sin dependencias). Ejecutar: npm test
const test = require('node:test');
const assert = require('node:assert/strict');

process.env.DATA_KEY = Buffer.alloc(32, 7).toString('base64');
process.env.INDEX_KEY = Buffer.alloc(32, 9).toString('base64');
const cifrado = require('../lib/cifrado');
const seg = require('../lib/seguridad');
const motor = require('../recomendador');
cifrado.iniciar();

test('AES-256-GCM: cifra, descifra y usa un IV distinto cada vez', () => {
  const a = cifrado.cifrar('229 000 0000');
  const b = cifrado.cifrar('229 000 0000');
  assert.match(a, /^enc:v1:/);
  assert.notEqual(a, b);
  assert.equal(cifrado.descifrar(a), '229 000 0000');
});

test('AES-256-GCM: detecta valores alterados', () => {
  const c = cifrado.cifrar('dato');
  const alterado = c.slice(0, -4) + (c.endsWith('AAAA') ? 'BBBB' : 'AAAA');
  assert.equal(cifrado.descifrar(alterado), '[no se pudo descifrar]');
});

test('Índice ciego del teléfono ignora espacios y no revela el número', () => {
  assert.equal(cifrado.hashTelefono('229 000 0000'), cifrado.hashTelefono('2290000000'));
  assert.ok(!cifrado.hashTelefono('2290000000').includes('229'));
});

test('Política de contraseñas', () => {
  assert.ok(seg.validarPassword('corta1'));
  assert.ok(seg.validarPassword('soloLetras'));
  assert.ok(seg.validarPassword('12345678'));
  assert.ok(seg.validarPassword('mariana2026', { correo: 'mariana@correo.com' }));
  assert.equal(seg.validarPassword('Oud-Ambar-2026'), null);
});

test('Redes CIDR para el panel de administrador', () => {
  assert.ok(seg.enRed('10.8.0.2', '10.8.0.0/24'));
  assert.ok(!seg.enRed('201.141.20.5', '10.8.0.0/24'));
});

test('Motor de recomendación: suma de pesos de los criterios cumplidos', () => {
  const p = { familia: 'Oud', ocasiones: ['Cita'], temporadas: ['Otoño'], intensidad: 'Intensa', precio: 900 };
  assert.equal(motor.evaluar(p, { familia: 'Oud', ocasion: 'Cita' }).porcentaje, 100);
  assert.equal(motor.evaluar(p, { familia: 'Floral', ocasion: 'Cita' }).porcentaje, Math.round(25 / 55 * 100));
});
