// Verifica los controles de seguridad de la base de datos y muestra un reporte (útil como evidencia en capturas).
// Uso: npm run verificar
// Usa las cadenas del .env: MONGODB_URI (aplicación), MONGODB_URI_ADMIN (mantenimiento) y MONGODB_URI_LECTURA (reportes).
const { MongoClient } = require('mongodb');
const { ocultarUri } = require('../db');
const cifrado = require('../lib/cifrado');

const DB = process.env.MONGODB_DB || 'the_arabic_corner';
const filas = [];
const ok = (prueba, resultado, detalle = '') => filas.push({ prueba, resultado, detalle });
const noAutorizado = (e) => !!e && (e.code === 13 || e.code === 8000 || /not authorized|unauthorized|not allowed to do action/i.test(e.message || ''));

async function intentar(fn) { try { await fn(); return null; } catch (e) { return e; } }

async function probarUsuario(nombre, uri, esperado) {
  if (!uri) { ok(`[${nombre}] conexión`, '— omitida', 'variable no definida en .env'); return; }
  const client = new MongoClient(uri, { serverSelectionTimeoutMS: 8000 });
  try { await client.connect(); } catch (e) { ok(`[${nombre}] conexión`, '✗ falló', e.message.slice(0, 80)); return; }
  const db = client.db(DB);
  const tls = client.options?.tls === true || /^mongodb\+srv:/.test(uri);
  ok(`[${nombre}] conexión con TLS`, tls ? '✓' : '✗', ocultarUri(uri));

  const lectura = await intentar(() => db.collection('perfumes').findOne({}));
  ok(`[${nombre}] leer perfumes`, lectura ? (esperado.leer ? '✗ denegado' : '✓ denegado') : (esperado.leer ? '✓ permitido' : '✗ permitido'));

  const escritura = await intentar(async () => {
    const r = await db.collection('auditoria').insertOne({ fecha: new Date(), accion: 'Prueba de permisos (verificar_seguridad)', exito: true });
    await db.collection('auditoria').deleteOne({ _id: r.insertedId }).catch(() => {});
  });
  ok(`[${nombre}] escribir documentos`, escritura ? (esperado.escribir ? '✗ denegado' : (noAutorizado(escritura) ? '✓ denegado' : '? ' + escritura.message.slice(0, 50)))
    : (esperado.escribir ? '✓ permitido' : '✗ permitido'));

  const crear = await intentar(async () => { await db.createCollection('prueba_permisos_tac'); await db.collection('prueba_permisos_tac').drop(); });
  ok(`[${nombre}] crear/borrar colecciones`, crear ? (esperado.ddl ? '✗ denegado' : '✓ denegado') : (esperado.ddl ? '✓ permitido' : '✗ permitido (demasiados privilegios)'));

  const otraBase = await intentar(() => client.db('admin').collection('system.users').findOne({}));
  ok(`[${nombre}] leer otras bases (admin)`, otraBase ? '✓ denegado' : '✗ permitido');
  await client.close();
}

async function main() {
  cifrado.iniciar();
  await probarUsuario('app', process.env.MONGODB_URI, { leer: true, escribir: true, ddl: false });
  await probarUsuario('mantenimiento', process.env.MONGODB_URI_ADMIN, { leer: true, escribir: true, ddl: true });
  await probarUsuario('lectura', process.env.MONGODB_URI_LECTURA, { leer: true, escribir: false, ddl: false });

  // Cifrado de campos: revisa cómo quedó guardado un cliente.
  const client = new MongoClient(process.env.MONGODB_URI_ADMIN || process.env.MONGODB_URI, { serverSelectionTimeoutMS: 8000 });
  try {
    await client.connect();
    const db = client.db(DB);
    const u = await db.collection('usuarios').findOne({ rol: 'cliente', telefono: { $ne: null } });
    ok('Teléfono cifrado en la base', cifrado.estaCifrado(u?.telefono) ? '✓' : '✗', String(u?.telefono || '').slice(0, 48));
    const sinCifrar = await db.collection('actividad').countDocuments({ detalle: { $not: /^enc:v1:/ } });
    ok('Historial (actividad.detalle) cifrado', sinCifrar === 0 ? '✓' : '✗', `${sinCifrar} registros sin cifrar`);
    const idx = await db.collection('sesiones').indexes();
    ok('Sesiones con expiración automática (TTL)', idx.some((i) => i.expireAfterSeconds != null) ? '✓' : '✗');
    const idxA = await db.collection('auditoria').indexes().catch(() => []);
    ok('Bitácora de auditoría con TTL de 180 días', idxA.some((i) => i.expireAfterSeconds === 180 * 86400) ? '✓' : '✗');
    const info = await db.listCollections({ name: 'usuarios' }).toArray();
    ok('Validación $jsonSchema en usuarios', info[0]?.options?.validator ? '✓' : '✗');
    await client.close();
  } catch (e) { ok('Revisión de datos', '✗', e.message.slice(0, 80)); }

  // Tabla en texto simple (sin símbolos especiales) para que se lea bien en PowerShell/CMD de Windows.
  const marca = (r) => String(r).replace('✓', '[OK]').replace('✗', '[FALLA]').replace('—', '[--]');
  const datos = filas.map((f, i) => [String(i + 1), f.prueba, marca(f.resultado), f.detalle || '']);
  const enc = ['#', 'Prueba', 'Resultado', 'Detalle'];
  const ancho = enc.map((h, c) => Math.max(h.length, ...datos.map((d) => d[c].length)));
  const linea = (cols) => cols.map((v, c) => v.padEnd(ancho[c])).join('  ');
  console.log('\nVerificación de seguridad de la base de datos - The Arabic Corner');
  console.log(`Fecha: ${new Date().toLocaleString('es-MX')}\n`);
  console.log(linea(enc));
  console.log(ancho.map((a) => '-'.repeat(a)).join('  '));
  datos.forEach((d) => console.log(linea(d)));
  const correctas = filas.filter((f) => String(f.resultado).startsWith('✓')).length;
  console.log(`\nResultado: ${correctas} de ${filas.length} pruebas correctas.`);
  if (correctas < filas.length) process.exitCode = 1;
}
main().catch((e) => { console.error(e); process.exit(1); });
