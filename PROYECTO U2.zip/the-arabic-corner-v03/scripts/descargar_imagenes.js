// Descarga las fotografías de producto a public/img/perfumes para que el sistema no dependa de enlaces externos.
//
// Uso:  npm run imagenes
//   1. Descarga cada imagen del catálogo (seed/perfumes.js) y la guarda como public/img/perfumes/<nombre>.<ext>.
//   2. Escribe seed/imagenes_locales.json (lo usa db.js al crear la base de datos).
//   3. Si MongoDB está disponible, actualiza el campo "imagen" de los perfumes ya registrados.
// Es seguro ejecutarlo varias veces: las imágenes ya descargadas se omiten.
const fs = require('node:fs');
const path = require('node:path');

const RAIZ = path.join(__dirname, '..');
const DESTINO = path.join(RAIZ, 'public', 'img', 'perfumes');
const MAPA = path.join(RAIZ, 'seed', 'imagenes_locales.json');
const PERFUMES = require('../seed/perfumes');

const slug = (s) => s.toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
const EXT = { 'image/jpeg': 'jpg', 'image/png': 'png', 'image/webp': 'webp' };

async function descargar(url, archivoBase) {
  const existente = ['jpg', 'png', 'webp'].map((e) => `${archivoBase}.${e}`).find((f) => fs.existsSync(path.join(DESTINO, f)));
  if (existente) return { archivo: existente, nuevo: false };
  const res = await fetch(url, { headers: { 'User-Agent': 'Mozilla/5.0 (TheArabicCorner/1.0; proyecto academico)' } });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const tipo = (res.headers.get('content-type') || '').split(';')[0];
  const ext = EXT[tipo] || (url.match(/\.(jpe?g|png|webp)/i)?.[1] || 'jpg').toLowerCase().replace('jpeg', 'jpg');
  const buf = Buffer.from(await res.arrayBuffer());
  if (buf.length < 1000) throw new Error('archivo vacío');
  const archivo = `${archivoBase}.${ext}`;
  fs.writeFileSync(path.join(DESTINO, archivo), buf);
  return { archivo, nuevo: true };
}

async function main() {
  fs.mkdirSync(DESTINO, { recursive: true });
  const mapa = fs.existsSync(MAPA) ? JSON.parse(fs.readFileSync(MAPA, 'utf8')) : {};
  let ok = 0, nuevas = 0;
  const fallos = [];
  const pendientes = PERFUMES.filter((p) => p.imagen && /^https?:/.test(p.imagen));
  // Descargas en grupos de 6 para no saturar la conexión.
  for (let i = 0; i < pendientes.length; i += 6) {
    await Promise.all(pendientes.slice(i, i + 6).map(async (p) => {
      try {
        const r = await descargar(p.imagen, slug(`${p.marca}-${p.nombre}`));
        mapa[p.nombre] = `img/perfumes/${r.archivo}`;
        ok++; if (r.nuevo) nuevas++;
      } catch (e) { fallos.push(`${p.nombre} (${e.message})`); }
    }));
    process.stdout.write(`\rImágenes: ${ok + fallos.length}/${pendientes.length}`);
  }
  fs.writeFileSync(MAPA, JSON.stringify(mapa, null, 2));
  console.log(`\n${ok} imágenes listas (${nuevas} nuevas) en public/img/perfumes.`);
  if (fallos.length) console.log(`No se pudieron descargar ${fallos.length}; seguirán usando el enlace original o el frasco ilustrado:\n  - ${fallos.join('\n  - ')}`);

  // Actualiza los perfumes que ya están en MongoDB.
  try {
    const { conectar } = require('../db');
    const { client, db } = await conectar();
    let n = 0;
    for (const [nombre, local] of Object.entries(mapa)) {
      const r = await db.collection('perfumes').updateOne({ nombre, imagen: { $regex: '^https?:' } }, { $set: { imagen: '/' + local } });
      n += r.modifiedCount;
    }
    await client.close();
    console.log(`MongoDB: ${n} perfumes ahora usan la imagen local.`);
  } catch {
    console.log('MongoDB no está disponible ahora; las imágenes locales se usarán la próxima vez que se cree la base (npm run reset-db).');
  }
}

main().catch((e) => { console.error(e); process.exit(1); });
