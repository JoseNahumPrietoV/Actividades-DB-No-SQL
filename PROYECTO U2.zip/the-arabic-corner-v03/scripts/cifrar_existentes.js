// Cifra los campos sensibles de una base que ya tenía datos sin cifrar (por ejemplo, la creada con la versión v02).
// Uso: npm run cifrar-datos   (requiere DATA_KEY e INDEX_KEY en el .env)
// Es seguro ejecutarlo varias veces: los valores que ya están cifrados se omiten.
const { MongoClient } = require('mongodb');
require('../db'); // carga el .env
const cifrado = require('../lib/cifrado');

async function main() {
  if (!cifrado.activo()) { console.error('Define DATA_KEY e INDEX_KEY en el .env (npm run llaves).'); process.exit(1); }
  const uri = process.env.MONGODB_URI_ADMIN || process.env.MONGODB_URI;
  const client = await new MongoClient(uri).connect();
  const db = client.db(process.env.MONGODB_DB || 'the_arabic_corner');
  let u = 0, a = 0;
  for await (const doc of db.collection('usuarios').find({})) {
    const cambios = {};
    if (doc.telefono && !cifrado.estaCifrado(doc.telefono)) {
      cambios.telefono = cifrado.cifrar(doc.telefono);
      cambios.telefono_hash = cifrado.hashTelefono(doc.telefono);
    }
    if (doc.preferencias?.notas_evita && !cifrado.estaCifrado(doc.preferencias.notas_evita)) {
      cambios['preferencias.notas_evita'] = cifrado.cifrar(doc.preferencias.notas_evita);
    }
    if (Object.keys(cambios).length) { await db.collection('usuarios').updateOne({ _id: doc._id }, { $set: cambios }); u++; }
  }
  for await (const doc of db.collection('actividad').find({ detalle: { $not: /^enc:v1:/ } })) {
    if (!doc.detalle) continue;
    await db.collection('actividad').updateOne({ _id: doc._id }, { $set: { detalle: cifrado.cifrar(doc.detalle) } });
    a++;
  }
  console.log(`Listo: ${u} usuarios y ${a} registros de actividad cifrados.`);
  await client.close();
}
main().catch((e) => { console.error(e.message); process.exit(1); });
