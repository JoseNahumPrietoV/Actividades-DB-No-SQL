// Genera las llaves de cifrado de campos (AES-256) y del índice ciego (HMAC) para el archivo .env.
// Uso: npm run llaves   → copia las dos líneas al .env (local y del servidor). ¡No las subas a GitHub!
// IMPORTANTE: si pierdes DATA_KEY, los datos cifrados ya no se pueden leer. Guárdala en un lugar seguro.
const { generarLlave } = require('../lib/cifrado');
console.log('# Llaves de cifrado de The Arabic Corner (generadas ' + new Date().toISOString().slice(0, 10) + ')');
console.log(`DATA_KEY=${generarLlave()}`);
console.log(`INDEX_KEY=${generarLlave()}`);
