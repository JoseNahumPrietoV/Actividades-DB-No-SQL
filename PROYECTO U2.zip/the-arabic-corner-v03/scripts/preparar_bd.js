// Prepara la base de datos sin encender el servidor web: crea colecciones, validación e índices y, si está vacía,
// carga los datos de ejemplo. Con --reset la borra y la vuelve a crear.
// Uso:  npm run preparar-bd            (o dentro del servidor: docker compose run --rm app node scripts/preparar_bd.js)
//       npm run preparar-bd -- --reset
// Usa MONGODB_URI_ADMIN (usuario de mantenimiento) si está definida; si no, MONGODB_URI.
const { conectar } = require('../db');

(async () => {
  const reset = process.argv.includes('--reset');
  const { client } = await conectar({ reset });
  console.log(reset ? 'Base reiniciada y lista.' : 'Base verificada y lista.');
  await client.close();
})().catch((e) => { console.error(e.message); process.exit(1); });
