// Capa de datos de The Arabic Corner: conexión a MongoDB, colecciones, validación, índices y datos iniciales.
//
// Modelo documental (NoSQL):
//   usuarios    { _id, nombre, correo, telefono, password_hash, rol, sucursal, acepto_terminos, creado,
//                 preferencias: { familia, ocasiones[], temporada, intensidad, presupuesto, notas_evita, pesos{} },
//                 favoritos: [ { perfume_id, fecha, precio_guardado } ] }        ← preferencias y favoritos embebidos
//   perfumes    { _id, nombre, marca, familia, ..., ocasiones[], temporadas[], existencias, tiempo_entrega }
//   categorias  { _id, tipo, nombre, descripcion, color }
//   sesiones    { _id: token, usuario_id, expira }                              ← índice TTL: expiran solas
//   actividad   { usuario_id, fecha, tipo, detalle, resultado, autor }         ← historial visible
//   eventos     { tipo, perfume_id, familia, ocasion, temporada, aceptada, usuario_id, fecha }
//   ventas      { perfume_id, cantidad, precio_unitario, cliente_id, asesor_id, fecha }
//   contadores  { _id: nombre_coleccion, seq }                                  ← ids numéricos legibles
//   auditoria   { fecha, accion, exito, usuario_id, correo, rol, ip, detalle }   ← bitácora de seguridad (TTL 180 días)
//   intentos_login { _id: correo, fallos, bloqueado_hasta, actualizado }        ← bloqueo por fuerza bruta (TTL 1 h)
//
// Seguridad de datos: teléfono, notas que evita el cliente y detalle del historial se guardan cifrados con
// AES-256-GCM (ver lib/cifrado.js). Atlas además cifra el almacenamiento en disco (encryption at rest) y obliga TLS.
//
// Conexiones con mínimo privilegio (ver docs/GUIA_SEGURIDAD_Y_DESPLIEGUE.md):
//   MONGODB_URI        → usuario de la aplicación (solo leer/insertar/actualizar/borrar documentos)
//   MONGODB_URI_ADMIN  → usuario de mantenimiento (crear colecciones, índices, reiniciar la base). Opcional.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { MongoClient } = require('mongodb');
const cifrado = require('./lib/cifrado');

// Carga variables de un archivo .env (si existe) sin dependencias externas: así `npm start` funciona con Atlas.
(function cargarEnv() {
  const archivo = path.join(__dirname, '.env');
  if (!fs.existsSync(archivo)) return;
  for (const linea of fs.readFileSync(archivo, 'utf8').split(/\r?\n/)) {
    const m = linea.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*?)\s*$/i);
    if (m && !m[1].startsWith('#') && process.env[m[1]] === undefined) process.env[m[1]] = m[2].replace(/^(['"])(.*)\1$/, '$2');
  }
})();

const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017';
const MONGODB_URI_ADMIN = process.env.MONGODB_URI_ADMIN || '';
const MONGODB_DB = process.env.MONGODB_DB || 'the_arabic_corner';
cifrado.iniciar();

// Oculta usuario y contraseña de una cadena de conexión para poder mostrarla en mensajes y bitácoras.
const ocultarUri = (u) => String(u).replace(/\/\/([^@/]+)@/, '//***:***@');

// ¿El error es por falta de permisos? MongoDB devuelve el código 13 (Unauthorized); Atlas, el 8000 (AtlasError)
// con el mensaje "user is not allowed to do action [...]".
const esNoAutorizado = (e) => !!e && (e.code === 13 || e.code === 8000 || /not authorized|unauthorized|not allowed to do action/i.test(e.message || ''));

function hashPassword(password, salt = crypto.randomBytes(16).toString('hex')) {
  const hash = crypto.scryptSync(password, salt, 64).toString('hex');
  return `${salt}:${hash}`;
}

function verifyPassword(password, stored) {
  const [salt, hash] = String(stored).split(':');
  if (!salt || !hash) return false;
  const test = crypto.scryptSync(password, salt, 64);
  return crypto.timingSafeEqual(test, Buffer.from(hash, 'hex'));
}

// ---------------------------------------------------------------------------
// Validación de esquema ($jsonSchema): MongoDB rechaza documentos que no la cumplan.
// ---------------------------------------------------------------------------
const VALIDADORES = {
  usuarios: {
    bsonType: 'object',
    required: ['_id', 'nombre', 'correo', 'password_hash', 'rol', 'creado'],
    properties: {
      _id: { bsonType: 'int' },
      nombre: { bsonType: 'string', minLength: 1 },
      correo: { bsonType: 'string', pattern: '^[^\\s@]+@[^\\s@]+\\.[^\\s@]{2,}$' },
      rol: { enum: ['cliente', 'asesor', 'admin'] },
      favoritos: { bsonType: 'array' },
      preferencias: { bsonType: ['object', 'null'] },
    },
  },
  perfumes: {
    bsonType: 'object',
    required: ['_id', 'nombre', 'marca', 'familia', 'concentracion', 'ml', 'precio', 'intensidad', 'estado'],
    properties: {
      _id: { bsonType: 'int' },
      precio: { bsonType: ['double', 'int', 'long', 'decimal'], minimum: 0 },
      ml: { bsonType: ['int', 'double', 'long'], minimum: 1 },
      intensidad: { enum: ['Suave', 'Moderada', 'Intensa'] },
      estado: { enum: ['Publicado', 'Borrador'] },
      ocasiones: { bsonType: 'array', items: { bsonType: 'string' } },
      temporadas: { bsonType: 'array', items: { bsonType: 'string' } },
      existencias: { bsonType: ['int', 'double', 'long'], minimum: 0 },
    },
  },
  categorias: {
    bsonType: 'object',
    required: ['_id', 'tipo', 'nombre'],
    properties: { tipo: { enum: ['familia', 'ocasion', 'temporada'] } },
  },
  ventas: {
    bsonType: 'object',
    required: ['perfume_id', 'cantidad', 'precio_unitario', 'fecha'],
    properties: { cantidad: { bsonType: ['int', 'double', 'long'], minimum: 1 }, fecha: { bsonType: 'date' } },
  },
  auditoria: {
    bsonType: 'object',
    required: ['fecha', 'accion', 'exito'],
    properties: { fecha: { bsonType: 'date' }, accion: { bsonType: 'string' }, exito: { bsonType: 'bool' } },
  },
  eventos: {
    bsonType: 'object',
    required: ['tipo', 'fecha'],
    properties: { tipo: { enum: ['consulta', 'busqueda', 'recomendacion', 'favorito'] }, fecha: { bsonType: 'date' } },
  },
};

async function crearColecciones(db) {
  const existentes = new Set((await db.listCollections({}, { nameOnly: true }).toArray()).map((c) => c.name));
  for (const nombre of COLECCIONES) {
    if (existentes.has(nombre)) continue;
    const opciones = VALIDADORES[nombre] ? { validator: { $jsonSchema: VALIDADORES[nombre] } } : {};
    await db.createCollection(nombre, opciones);
  }
  const indices = [
    db.collection('usuarios').createIndex({ correo: 1 }, { unique: true }),
    db.collection('usuarios').createIndex({ telefono_hash: 1 }, { sparse: true }), // índice ciego para buscar por teléfono
    db.collection('usuarios').createIndex({ rol: 1 }),
    db.collection('perfumes').createIndex({ estado: 1, familia: 1 }),
    db.collection('categorias').createIndex({ tipo: 1, nombre: 1 }, { unique: true }),
    db.collection('sesiones').createIndex({ expira: 1 }, { expireAfterSeconds: 0 }), // TTL
    db.collection('actividad').createIndex({ usuario_id: 1, fecha: -1 }),
    db.collection('eventos').createIndex({ fecha: 1, tipo: 1 }),
    db.collection('eventos').createIndex({ usuario_id: 1 }),
    db.collection('ventas').createIndex({ fecha: 1 }),
    db.collection('ventas').createIndex({ perfume_id: 1, fecha: 1 }),
    db.collection('auditoria').createIndex({ fecha: -1 }),
    db.collection('auditoria').createIndex({ fecha: 1 }, { expireAfterSeconds: 180 * 86400, name: 'ttl_180_dias' }), // TTL
    db.collection('auditoria').createIndex({ accion: 1, fecha: -1 }),
    db.collection('intentos_login').createIndex({ actualizado: 1 }, { expireAfterSeconds: 3600 }), // TTL
  ];
  try {
    await Promise.all(indices);
  } catch (e) {
    // El usuario de la aplicación (mínimo privilegio) no puede crear índices: es lo esperado si ya existen.
    if (esNoAutorizado(e)) {
      console.log('ℹ  El usuario de la aplicación no tiene permiso para crear índices (mínimo privilegio). Se asume que ya existen.');
    } else throw e;
  }
}
const COLECCIONES = ['usuarios', 'perfumes', 'categorias', 'sesiones', 'actividad', 'eventos', 'ventas', 'contadores', 'auditoria', 'intentos_login'];

// Identificadores numéricos consecutivos (patrón "counter collection" de MongoDB).
async function siguienteId(db, coleccion) {
  const r = await db.collection('contadores').findOneAndUpdate(
    { _id: coleccion }, { $inc: { seq: 1 } }, { upsert: true, returnDocument: 'after' });
  return r.seq;
}

// ---------------------------------------------------------------------------
// Datos iniciales
// ---------------------------------------------------------------------------
const CATEGORIAS = [
  ['familia', 'Oud', 'Agar, resinas y maderas preciosas', '#3B2A22'],
  ['familia', 'Oriental', 'Ámbar, especias, tabaco', '#8B4A2B'],
  ['familia', 'Gourmand', 'Vainilla, dátil, café, praliné', '#B07A45'],
  ['familia', 'Amaderado', 'Cedro, vetiver, abedul', '#5C4A38'],
  ['familia', 'Floral', 'Rosa, jazmín, iris', '#9E5A63'],
  ['familia', 'Cítrico', 'Bergamota, limón, pomelo', '#C9A24A'],
  ['familia', 'Acuático', 'Notas marinas y frescas', '#4A7A8C'],
  ['ocasion', 'Día a día', 'Uso cotidiano', '#9C7B3C'],
  ['ocasion', 'Cita', 'Encuentros y cenas', '#9C7B3C'],
  ['ocasion', 'Oficina', 'Ambientes de trabajo', '#9C7B3C'],
  ['ocasion', 'Evento formal', 'Bodas, galas, ceremonias', '#9C7B3C'],
  ['ocasion', 'Deporte', 'Actividad al aire libre', '#9C7B3C'],
  ['temporada', 'Primavera', 'Florales y verdes', '#6B7A4F'],
  ['temporada', 'Verano', 'Frescos y ligeros', '#C9A24A'],
  ['temporada', 'Otoño', 'Cálidos y especiados', '#9C5A2B'],
  ['temporada', 'Invierno', 'Intensos y envolventes', '#16130F'],
];

const PERFUMES = require('./seed/perfumes');

// Si se ejecutó `npm run imagenes`, se usan las fotos descargadas en public/img/perfumes; si no, el enlace original.
function imagenLocal(nombre, url) {
  try {
    const mapa = require('./seed/imagenes_locales.json');
    const local = mapa[nombre];
    if (local && fs.existsSync(path.join(__dirname, 'public', local))) return '/' + local.replace(/^\/+/, '');
  } catch { /* sin descargas locales */ }
  return url;
}

// Generador pseudoaleatorio determinista para que los datos de ejemplo sean reproducibles.
function rng(seed) {
  let s = seed >>> 0;
  return () => {
    s = (s + 0x6D2B79F5) >>> 0;
    let t = s;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function pickWeighted(rand, items) {
  const total = items.reduce((a, [, w]) => a + w, 0);
  let r = rand() * total;
  for (const [v, w] of items) { if ((r -= w) <= 0) return v; }
  return items[items.length - 1][0];
}

const F = (s) => new Date(`${s.replace(' ', 'T')}${s.length <= 10 ? 'T00:00:00' : ''}Z`);

async function insertarEnLotes(col, docs, lote = 5000) {
  for (let i = 0; i < docs.length; i += lote) await col.insertMany(docs.slice(i, i + lote), { ordered: false });
}

async function seed(db) {
  const rand = rng(2026);

  // Categorías
  await db.collection('categorias').insertMany(CATEGORIAS.map(([tipo, nombre, descripcion, color], i) =>
    ({ _id: i + 1, tipo, nombre, descripcion, color })));

  // Perfumes (existencias y tiempo de entrega se ajustan al final)
  const perfumes = PERFUMES.map((p, i) => ({
    _id: i + 1, nombre: p.nombre, marca: p.marca, familia: p.familia, subfamilia: p.subfamilia ?? null,
    concentracion: p.concentracion, ml: p.ml, precio: p.precio, intensidad: p.intensidad, publico: p.publico,
    ocasiones: p.ocasiones, temporadas: p.temporadas, notas_salida: p.notas_salida, notas_corazon: p.notas_corazon,
    notas_fondo: p.notas_fondo, descripcion: p.descripcion, duracion: p.duracion, proyeccion: p.proyeccion,
    color: p.color, imagen: p.imagen ? imagenLocal(p.nombre, p.imagen) : null, anio: p.anio, perfumista: p.perfumista, estado: p.estado,
    existencias: 10, tiempo_entrega: 7, creado: F('2026-01-10'),
  }));
  const byName = Object.fromEntries(perfumes.map((p) => [p.nombre, p]));
  const precioDe = (n) => byName[n].precio;

  // Personal y cliente de demostración
  let uid = 0;
  const usuarios = [];
  const nuevoUsuario = (o) => { const u = { _id: ++uid, telefono: null, sucursal: null, preferencias: null, favoritos: [], ...o }; usuarios.push(u); return u; };
  nuevoUsuario({ nombre: 'Administración', correo: 'admin@thearabiccorner.mx', password_hash: hashPassword('admin123'), rol: 'admin', sucursal: 'Dirección general', acepto_terminos: F('2026-01-10'), creado: F('2026-01-10') });
  const jorge = nuevoUsuario({ nombre: 'Jorge Ramírez', correo: 'jorge.ramirez@thearabiccorner.mx', telefono: '229 111 2233', password_hash: hashPassword('asesor123'), rol: 'asesor', sucursal: 'Sucursal Centro', acepto_terminos: F('2026-01-15'), creado: F('2026-01-15') });
  const ana = nuevoUsuario({ nombre: 'Ana Torres', correo: 'ana.torres@thearabiccorner.mx', telefono: '229 444 5566', password_hash: hashPassword('asesor123'), rol: 'asesor', sucursal: 'Sucursal Norte', acepto_terminos: F('2026-02-01'), creado: F('2026-02-01') });
  const mariana = nuevoUsuario({
    nombre: 'Mariana López', correo: 'mariana.lopez@correo.com', telefono: '229 000 0000', password_hash: hashPassword('cliente123'),
    rol: 'cliente', acepto_terminos: F('2026-03-15'), creado: F('2026-03-15'),
    preferencias: { familia: 'Oud', ocasiones: ['Cita', 'Oficina'], temporada: 'Otoño', intensidad: 'Intensa', presupuesto: 'medio', notas_evita: 'Acuáticas, menta', pesos: null },
    favoritos: [
      { perfume_id: byName['Khamrah']._id, fecha: F('2026-09-18 12:10:00'), precio_guardado: precioDe('Khamrah') },
      // Amber Oud Gold costaba $1,290 cuando lo guardó: genera la alerta "bajó de precio".
      { perfume_id: byName['Amber Oud Gold Edition']._id, fecha: F('2026-09-12 18:30:00'), precio_guardado: 1290 },
      { perfume_id: byName["Bade'e Al Oud Oud for Glory"]._id, fecha: F('2026-08-30 10:00:00'), precio_guardado: precioDe("Bade'e Al Oud Oud for Glory") },
      { perfume_id: byName['Pharaoh Ramesses II']._id, fecha: F('2026-08-21 17:45:00'), precio_guardado: precioDe('Pharaoh Ramesses II') },
    ],
  });

  const actividad = [];
  const act = (usuario_id, fecha, tipo, detalle, resultado, autor = 'Sistema') =>
    actividad.push({ usuario_id, fecha: F(fecha), tipo, detalle, resultado, autor });
  act(mariana._id, '2026-03-15 11:00:00', 'Alta de cliente', 'Creó su cuenta y completó el perfil olfativo.', 'Perfil creado');
  act(mariana._id, '2026-08-21 17:40:00', 'Recomendación del asesor', 'Se recomendó Pharaoh Ramesses II para evento formal.', 'Aceptada', ana.nombre);
  act(mariana._id, '2026-08-28 13:20:00', 'Búsqueda', 'Oficina · Primavera · Floral', '4 resultados');
  act(mariana._id, '2026-09-05 16:00:00', 'Atención en tienda', 'Asesor registró preferencia: evita notas acuáticas. Probó Amber Oud Gold Edition.', 'Perfil actualizado', jorge.nombre);
  act(mariana._id, '2026-09-12 18:30:00', 'Favorito', 'Agregó Amber Oud Gold Edition a favoritos', '—');
  act(mariana._id, '2026-09-18 12:00:00', 'Búsqueda', 'Cita · Otoño · Oud · Intensa · $800 – $1,600', '5 resultados');
  act(mariana._id, '2026-09-18 12:05:00', 'Recomendación', 'Emeer sugerido por el sistema', '100% coincidencia');
  act(mariana._id, '2026-09-18 12:15:00', 'Comparación', 'Khamrah vs Emeer vs Amber Oud Gold Edition', 'Eligió Khamrah');

  // Clientes de ejemplo para que el dashboard tenga volumen.
  const nombres = ['Sofía', 'Valeria', 'Camila', 'Daniela', 'Lucía', 'Regina', 'Fernanda', 'Andrea', 'Paula', 'Renata',
    'Diego', 'Santiago', 'Emiliano', 'Mateo', 'Luis', 'Carlos', 'Andrés', 'Rodrigo', 'Javier', 'Héctor'];
  const apellidos = ['García', 'Hernández', 'Martínez', 'González', 'Pérez', 'Sánchez', 'Ramírez', 'Cruz', 'Flores', 'Morales',
    'Reyes', 'Jiménez', 'Ruiz', 'Vargas', 'Castillo', 'Ortiz', 'Mendoza', 'Silva', 'Rojas', 'Navarro'];
  const familias = CATEGORIAS.filter((c) => c[0] === 'familia').map((c) => c[1]);
  const ocasiones = ['Día a día', 'Cita', 'Oficina', 'Evento formal', 'Deporte'];
  const temporadas = ['Primavera', 'Verano', 'Otoño', 'Invierno'];
  const intensidades = ['Suave', 'Moderada', 'Intensa'];
  const presupuestos = ['bajo', 'medio', 'alto'];
  const demoPass = hashPassword('cliente123');
  const clientes = [];
  for (let i = 0; i < 80; i++) {
    const n = nombres[Math.floor(rand() * nombres.length)];
    const a = apellidos[Math.floor(rand() * apellidos.length)];
    const mes = 1 + Math.floor(rand() * 9);
    const dia = 1 + Math.floor(rand() * 27);
    const fecha = `2026-${String(mes).padStart(2, '0')}-${String(dia).padStart(2, '0')}`;
    const correo = `${n}.${a}.${i}`.toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '') + '@correo.com';
    const tel = `229 ${100 + Math.floor(rand() * 900)} ${1000 + Math.floor(rand() * 9000)}`;
    const preferencias = rand() < 0.8 ? {
      familia: familias[Math.floor(rand() * familias.length)], ocasiones: [ocasiones[Math.floor(rand() * 5)]],
      temporada: temporadas[Math.floor(rand() * 4)], intensidad: intensidades[Math.floor(rand() * 3)],
      presupuesto: presupuestos[Math.floor(rand() * 3)], notas_evita: null, pesos: null,
    } : null;
    const u = nuevoUsuario({ nombre: `${n} ${a}`, correo, telefono: tel, password_hash: demoPass, rol: 'cliente', acepto_terminos: F(fecha), creado: F(fecha), preferencias });
    clientes.push(u._id);
    act(u._id, `${fecha} 10:00:00`, 'Alta de cliente', 'Creó su cuenta.', 'Perfil creado');
  }

  // Eventos de uso y ventas: 24 meses completos + mes en curso, con estacionalidad y crecimiento.
  const eventos = [];
  const ventas = [];
  const asesores = [jorge._id, ana._id];
  const publicados = perfumes.filter((p) => p.estado === 'Publicado');
  const famBase = { Oud: 30, Oriental: 27, Gourmand: 26, Amaderado: 17, Floral: 15, 'Cítrico': 16, 'Acuático': 9 };
  const famFria = new Set(['Oud', 'Oriental', 'Gourmand', 'Amaderado']); // suben en otoño/invierno
  const ocW = [['Día a día', 28], ['Cita', 27], ['Evento formal', 19], ['Oficina', 18], ['Deporte', 8]];
  // Popularidad relativa dentro de su familia (los superventas reales pesan más); el resto, 0.5–1.
  const popularidad = {
    Khamrah: 3.4, Asad: 2.8, Yara: 2.8, "Bade'e Al Oud Oud for Glory": 2.6, 'Club de Nuit Intense Man': 2.6,
    '9pm': 2.4, 'Hawas for Him': 2.2, 'Hawas Ice': 2.0, 'Odyssey Mandarin Sky': 2.2, 'Amber Oud Gold Edition': 1.8, 'Liquid Brun': 1.6,
    'Spectre Ghost': 1.6, 'King': 1.6, 'Rey de Reyes': 1.5, 'Club de Nuit Untold': 1.6, 'Salvo': 1.5, 'Eclaire': 1.8, 'Yara Moi': 1.5,
  };
  for (const p of publicados) if (!(p.nombre in popularidad)) popularidad[p.nombre] = 0.5 + rand() * 0.5;
  const hoy = new Date();
  const start = new Date(Date.UTC(hoy.getUTCFullYear(), hoy.getUTCMonth() - 24, 1));
  const end = new Date(Date.UTC(hoy.getUTCFullYear(), hoy.getUTCMonth(), hoy.getUTCDate() - 1));
  for (let d = new Date(start); d <= end; d.setUTCDate(d.getUTCDate() + 1)) {
    const m = d.getUTCMonth(); // 0 = enero
    // Otoño/Invierno pico en dic-ene, Primavera/Verano pico en jun-jul.
    const cold = 0.5 + 0.5 * Math.cos((m / 12) * 2 * Math.PI);
    const anios = (d - start) / (365 * 864e5);
    // Acuático pierde interés año con año (≈ −25 %): tendencia real que detectan las alertas.
    const famW = Object.entries(famBase).map(([f, w]) => [f,
      w * (1 + (famFria.has(f) ? 1 : -1) * (cold - 0.5)) * (f === 'Acuático' ? 1 - 0.25 * anios : 1)]);
    const crecimiento = 1 + 0.12 * anios; // +12 % anual en el total
    const perDay = Math.round((55 + Math.floor(rand() * 25)) * crecimiento);
    for (let k = 0; k < perDay; k++) {
      const temporada = rand() < cold
        ? (rand() < 0.5 ? 'Otoño' : 'Invierno')
        : (rand() < 0.5 ? 'Primavera' : 'Verano');
      const familia = pickWeighted(rand, famW);
      const ocasion = pickWeighted(rand, ocW);
      const cand = publicados.filter((p) => p.familia === familia).map((p) => [p, popularidad[p.nombre] ?? 1]);
      const perf = cand.length ? pickWeighted(rand, cand) : publicados[Math.floor(rand() * publicados.length)];
      const usuario_id = clientes[Math.floor(rand() * clientes.length)];
      const fecha = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate(), 9 + Math.floor(rand() * 12), Math.floor(rand() * 60)));
      const tipo = pickWeighted(rand, [['consulta', 55], ['busqueda', 20], ['recomendacion', 18], ['favorito', 7]]);
      const aceptada = tipo === 'recomendacion' && rand() < 0.64;
      eventos.push({ tipo, perfume_id: perf._id, familia, ocasion, temporada, aceptada, usuario_id, fecha });
      // Una parte de las consultas termina en compra en tienda.
      if (tipo === 'consulta' && rand() < 0.15) {
        ventas.push({ perfume_id: perf._id, cantidad: rand() < 0.06 ? 2 : 1, precio_unitario: perf.precio,
          cliente_id: usuario_id, asesor_id: asesores[Math.floor(rand() * asesores.length)], fecha });
      }
    }
  }

  // Inventario inicial; algunos casos fijos para mostrar alertas de reorden y agotado.
  const fijos = { Khamrah: 0, Asad: 2, Yara: 3, '9pm': 4 };
  for (const p of perfumes) {
    p.existencias = p.nombre in fijos ? fijos[p.nombre] : 8 + Math.floor(rand() * 22);
    p.tiempo_entrega = /Bharara|French Avenue|Riiffs|Rasasi/.test(p.marca) ? 14 : 7; // importación directa tarda más
  }

  await db.collection('perfumes').insertMany(perfumes);
  // Campos sensibles cifrados antes de enviarlos a la base (ver lib/cifrado.js).
  await db.collection('usuarios').insertMany(usuarios.map((u) => ({
    ...u, telefono: cifrado.cifrar(u.telefono), telefono_hash: cifrado.hashTelefono(u.telefono),
    preferencias: cifrado.cifrarPreferencias(u.preferencias),
  })));
  await insertarEnLotes(db.collection('actividad'), actividad.map((a) => ({ ...a, detalle: cifrado.cifrar(a.detalle) })));
  await insertarEnLotes(db.collection('eventos'), eventos);
  await insertarEnLotes(db.collection('ventas'), ventas);
  await db.collection('contadores').insertMany([
    { _id: 'usuarios', seq: uid }, { _id: 'perfumes', seq: perfumes.length }, { _id: 'categorias', seq: CATEGORIAS.length },
  ]);
  return { perfumes: perfumes.length, usuarios: usuarios.length, eventos: eventos.length, ventas: ventas.length };
}

async function abrir(uri) {
  const client = new MongoClient(uri, { serverSelectionTimeoutMS: 8000, appName: 'the-arabic-corner' });
  try {
    await client.connect();
  } catch (e) {
    console.error(`\nNo se pudo conectar a MongoDB en ${ocultarUri(uri)}.\n` +
      '• Atlas: revisa usuario y contraseña de la cadena y que tu IP esté en Network Access.\n' +
      '• Local: verifica que el servicio de MongoDB esté iniciado.\n');
    throw e;
  }
  return client;
}

// Prepara la base: (opcional) la reinicia, crea colecciones con validación e índices y carga datos de ejemplo.
async function preparar(db, { reset }) {
  if (reset) await db.dropDatabase();
  await crearColecciones(db);
  if ((await db.collection('perfumes').countDocuments()) === 0) {
    const t = Date.now();
    const r = await seed(db);
    console.log(`Base "${db.databaseName}" creada con datos de ejemplo: ${r.perfumes} perfumes, ${r.usuarios} usuarios, ` +
      `${r.eventos.toLocaleString('es-MX')} eventos y ${r.ventas.toLocaleString('es-MX')} ventas (${((Date.now() - t) / 1000).toFixed(1)} s).`);
  }
}

// Conecta a MongoDB. Si existe MONGODB_URI_ADMIN, la preparación (reiniciar, crear colecciones e índices, datos de
// ejemplo) se hace con el usuario de mantenimiento y después la aplicación trabaja con el usuario de mínimo privilegio.
async function conectar({ reset = false, uri = MONGODB_URI, uriAdmin = MONGODB_URI_ADMIN, dbName = MONGODB_DB } = {}) {
  if (uriAdmin && uriAdmin !== uri) {
    const admin = await abrir(uriAdmin);
    try { await preparar(admin.db(dbName), { reset }); } finally { await admin.close(); }
    const client = await abrir(uri);
    const db = client.db(dbName);
    // El usuario de la aplicación no puede crear colecciones ni índices (mínimo privilegio): solo se comprueba que existan.
    const existentes = new Set((await db.listCollections({}, { nameOnly: true }).toArray()).map((c) => c.name));
    const faltan = COLECCIONES.filter((n) => !existentes.has(n));
    if (faltan.length) throw new Error(`Faltan colecciones (${faltan.join(', ')}). Ejecuta: npm run preparar-bd`);
    return { client, db };
  }
  if (reset && !uriAdmin) console.log('ℹ  Reiniciando la base con el usuario de MONGODB_URI (en producción usa MONGODB_URI_ADMIN).');
  const client = await abrir(uri);
  const db = client.db(dbName);
  await preparar(db, { reset });
  return { client, db };
}

module.exports = { conectar, siguienteId, hashPassword, verifyPassword, ocultarUri, esNoAutorizado, COLECCIONES };
