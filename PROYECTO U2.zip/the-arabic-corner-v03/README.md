# The Arabic Corner — Sistema de soporte a la decisión

Plataforma web para elegir **perfumes árabes** según preferencias, ocasión, temporada y presupuesto. Tiene tres perfiles de usuario: **Cliente**, **Asesor de ventas** y **Administrador**. Está basada en la estructura del proyecto AromaMatch, con la capa de datos migrada a **MongoDB (NoSQL)**, una nueva identidad visual (ónix, arena y dorado neutro) y un catálogo de casas árabes.

> **Versión 3 (Proyecto U2):** seguridad reforzada y despliegue en Render (con dominio de Namecheap del Student Pack). La guía completa, paso a paso, está en
> [`docs/GUIA_SEGURIDAD_Y_DESPLIEGUE.md`](docs/GUIA_SEGURIDAD_Y_DESPLIEGUE.md).

## Seguridad (resumen)

| Control | Implementación |
|---|---|
| Autenticación | **Verificación en dos pasos (TOTP)**, obligatoria para administradores (`MFA_ADMIN=1`); contraseñas con `scrypt` + sal; política (≥ 8 caracteres, letras y números, no comunes); sesiones con token aleatorio y **TTL** en MongoDB |
| Fuerza bruta | 5 intentos fallidos → cuenta bloqueada 15 min (colección `intentos_login` con TTL) + límite de peticiones por IP |
| Autorización | Roles cliente / asesor / admin en cada ruta; opcional: panel admin solo desde redes de confianza (`ADMIN_REDES`) |
| Mínimo privilegio en la BD | 3 usuarios de Atlas: `tac_app` (rol personalizado: solo CRUD de documentos), `tac_mantenimiento`, `tac_lectura` |
| Cifrado en tránsito | HTTPS (Let's Encrypt en Render, TLS 1.2/1.3, HSTS), TLS obligatorio hacia Atlas |
| Cifrado en la BD | Atlas *encryption at rest* + **AES-256-GCM a nivel de campo** (teléfono con índice ciego, notas que evita, historial y secreto 2FA) |
| Auditoría | Colección `auditoria` (TTL 180 días): accesos, fallos, bloqueos y cambios administrativos; vista **Admin → Seguridad** |
| Cabeceras web | CSP sin JavaScript en línea, X-Frame-Options, nosniff, Referrer-Policy, Permissions-Policy |
| Red | Atlas solo acepta las IP de salida de Render (sin `0.0.0.0/0`); límite de peticiones por IP. Alternativa con servidor propio (ufw + VPN WireGuard) en `deploy/` y en el Anexo A de la guía |

## Requisitos

- **Node.js 18.17 o superior**
- **MongoDB 6 o 7** (Community Server local) o un clúster gratuito de **MongoDB Atlas**
- Python 3 + `reportlab`, solo si quieres regenerar el PDF de términos

## Cómo ejecutarlo

1. **Base de datos**: usa MongoDB Atlas (recomendado) o un MongoDB local.
   - **Atlas:** copia `.env.example` como `.env` y pega tu cadena de conexión en `MONGODB_URI`. En Atlas → *Network Access* permite tu IP.
   - **Local:** instala MongoDB Community Server; queda en `mongodb://127.0.0.1:27017` y no necesitas `.env`.
2. En la carpeta del proyecto (en PowerShell de Windows 10, si `npm` da error de "ejecución de scripts deshabilitada", ejecuta una vez `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned`):

```bash
npm install        # instala el driver oficial de MongoDB
npm run imagenes   # (recomendado, una vez) descarga las fotos de los perfumes a public/img/perfumes
npm start          # http://localhost:3000
```

Al primer arranque se crea la base `the_arabic_corner` con colecciones, validación de esquema, índices y datos de ejemplo (157 fragancias, ≈55,000 eventos de uso y ≈4,600 ventas de 24 meses). Para empezar de cero: `npm run reset-db`.

### Comandos

| Comando | Qué hace |
|---|---|
| `npm start` | Enciende el servidor (crea la base con datos de ejemplo si está vacía) |
| `npm run reset-db` | Borra y recrea la base con datos de ejemplo, y deja el servidor encendido |
| `npm run preparar-bd` | Prepara la base sin encender el servidor (`npm run preparar-bd -- --reset` la reinicia) |
| `npm run imagenes` | Descarga las fotos de los perfumes y actualiza la base |
| `npm run llaves` | Genera `DATA_KEY` e `INDEX_KEY` para el cifrado de campos |
| `npm run cifrar-datos` | Cifra los campos sensibles de una base creada con la v02 |
| `npm run verificar` | Reporte de seguridad de la base (privilegios, TLS, cifrado, TTL) |
| `npm test` | Pruebas unitarias |

### Fotografías de producto

Cada perfume tiene una foto real tomada de la ficha pública de su tienda oficial o distribuidor (ver `seed/perfumes.js`). Sin descargarlas, el sistema las muestra desde el enlace original; con `npm run imagenes` se guardan en `public/img/perfumes` y la base pasa a usar las copias locales, así el catálogo no depende de enlaces externos. Si una foto no carga, se muestra un frasco ilustrado. Todas las fotos se presentan en el mismo marco en arco (proporción 4:5, misma escala y fondo), por lo que ningún perfume se ve más grande que otro.

### Variables de entorno (opcionales, en `.env`)

| Variable | Predeterminado | Uso |
|---|---|---|
| `MONGODB_URI` | `mongodb://127.0.0.1:27017` | Cadena de conexión (local o Atlas) |
| `MONGODB_DB` | `the_arabic_corner` | Nombre de la base de datos |
| `PORT` | `3000` | Puerto del servidor web |

### Cuentas de demostración

| Perfil | Correo | Contraseña |
|---|---|---|
| Cliente | mariana.lopez@correo.com | cliente123 |
| Asesor de ventas | jorge.ramirez@thearabiccorner.mx | asesor123 |
| Administrador | admin@thearabiccorner.mx | admin123 |

## Base de datos MongoDB

### Colecciones

| Colección | Documento | Diseño NoSQL |
|---|---|---|
| `usuarios` | Cliente, asesor o administrador | **Preferencias y favoritos embebidos** (`preferencias: {…}`, `favoritos: [{perfume_id, fecha, precio_guardado}]`). Se leen siempre junto con el usuario, así que una sola consulta trae todo el perfil y eliminar la cuenta es un solo `deleteOne`. |
| `perfumes` | Ficha del perfume | `ocasiones` y `temporadas` son **arreglos**: `{ ocasiones: "Cita" }` encuentra los perfumes cuyo arreglo contiene "Cita". Incluye existencias y días de entrega. |
| `categorias` | Familia olfativa, ocasión o temporada | Alimentan los filtros y el motor de recomendación. |
| `sesiones` | `{ _id: token, usuario_id, expira }` | **Índice TTL**: MongoDB borra la sesión sola al vencer. |
| `actividad` | Historial visible (búsquedas, recomendaciones, compras…) | Colección aparte porque crece sin límite (no conviene embeberla). |
| `eventos` | Uso agregado: consultas, búsquedas, recomendaciones, favoritos | Base del dashboard, tendencias y pronóstico. |
| `ventas` | Ventas en tienda | Base del inventario, punto de reorden y ABC. |
| `contadores` | `{ _id: "perfumes", seq }` | Genera ids numéricos legibles (patrón *counter collection*). |

### Validación e índices

- **`$jsonSchema`** en `usuarios`, `perfumes`, `categorias`, `ventas` y `eventos`: MongoDB rechaza documentos con rol, intensidad, estado o tipo de evento no válidos, precios negativos, etc.
- **Índices únicos:** `usuarios.correo`, `categorias.{tipo, nombre}`.
- **Índices de consulta:** `perfumes.{estado, familia}`, `actividad.{usuario_id, fecha}`, `eventos.{fecha, tipo}`, `ventas.{perfume_id, fecha}`.
- **Operaciones atómicas:** la venta descuenta existencias con `updateOne({ _id, existencias: { $gte: cantidad } }, { $inc: … })`, así nunca quedan existencias negativas aunque dos asesores vendan al mismo tiempo. Agregar a favoritos usa un `$push` condicionado para no duplicar.
- **Framework de agregación:** el dashboard, las tendencias, el pronóstico, el inventario y el ABC usan `aggregate` con `$match`, `$group`, `$dateToString`, `$cond`, `$unwind` y `$sort`. En `docs/consultas_mongodb.js` hay ejemplos para ejecutar en `mongosh` o MongoDB Compass.

## Módulos

| Perfil | Vistas |
|---|---|
| Público | Iniciar sesión (con selección de tipo de usuario), Crear cuenta con aceptación de Términos |
| Cliente | Catálogo con filtros, Detalle del perfume (pirámide olfativa, coincidencia, similares), Buscador inteligente, Comparador (hasta 3), Mi perfil (favoritos, perfil olfativo, preferencias, historial, avisos, eliminar cuenta) |
| Asesor | Atención a cliente (buscar cliente, registrar preferencia, recomendar, historial), Consultar catálogo, Recomendar productos, Comparador, Historial de clientes, Registrar venta |
| Administrador | Dashboard, Gestión de perfumes, Categorías, Tendencias, Pronóstico, Inventario + ABC, Simulador de precios |

## Motor de recomendación (`recomendador.js`)

Coincidencia = suma de pesos de los criterios que el perfume cumple ÷ suma de pesos de los criterios elegidos.

| Criterio | Peso |
|---|---|
| Familia olfativa | 30 % |
| Ocasión | 25 % |
| Temporada | 20 % |
| Intensidad | 15 % |
| Presupuesto | 10 % |

Rangos de presupuesto (ajustados a precios de perfumería árabe): **Hasta $800 · $800 – $1,600 · Más de $1,600**. En la coincidencia con el perfil guardado se restan 20 puntos por cada nota que el cliente evita.

Familias olfativas: **Oud, Oriental, Gourmand, Amaderado, Floral, Cítrico y Acuático**.

## Funciones de análisis del DSS (`analisis.js`)

| Función | Dónde | Qué hace |
|---|---|---|
| ¿Qué pasaría si…? (pesos) | Buscador inteligente | Deslizadores por criterio; el ranking se recalcula y las flechas ▲▼ muestran cuántos lugares se movió cada perfume. |
| ¿Qué pasaría si…? (precio) | Simulador de precios | Clientes que tendrían el perfume en su presupuesto, con coincidencia ≥ 70 % y en su top 3; ingresos estimados a 90 días. |
| Pronóstico de demanda | Pronóstico | Por familia, 3 meses adelante. Compara *estacional con tendencia* vs *media móvil (3)* con MAPE y usa el de menor error. |
| Punto de reorden | Inventario | Demanda diaria ajustada por pronóstico, stock de seguridad (z = 1.65), punto de reorden y pedido sugerido. |
| Análisis ABC | Inventario | Pareto por ingresos de 12 meses: A = 80 %, B = 15 %, C = 5 %. |
| Alertas por excepción | Campana, dashboard y Mi perfil | Agotados, reorden, caídas interanuales, alzas pronosticadas, huecos de surtido; para el cliente, bajas de precio y agotados en favoritos. |

## Catálogo

`seed/perfumes.js` contiene **157 fragancias** (156 publicadas y una en borrador) de **Lattafa, Lattafa Pride, Armaf, Maison Alhambra, Bharara, French Avenue, Fragrance World, Afnan, Al Haramain, Rasasi y Riiffs**, entre ellas Khamrah, Asad, Yara, Odyssey Mandarin Sky, Club de Nuit Intense Man, Rey de Reyes, la línea Spectre (Ghost y Wraith), Hawas Ice y Hawas for Him.

- **Notas, presentaciones y fotos:** fichas públicas de Lattafa USA, Rasasi Store, Intense Oud y Arabic Parfums (octubre de 2026). Las marcas y fotografías pertenecen a sus titulares; se usan con fines académicos para identificar el producto.
- **Precios:** conversión aproximada del precio de referencia del distribuidor a MXN.
- **Duración y proyección:** estimaciones según la intensidad.

Si modificas el archivo, ejecuta `npm run reset-db`.

Los datos de clientes, uso y ventas son simulados de forma reproducible (24 meses, 81 clientes) con estacionalidad por familia (oud, oriental y gourmand suben en otoño/invierno), crecimiento anual del 12 % y una caída real del interés por los acuáticos.

## Diseño

- **Paleta:** ónix `#16130F`, arena `#F6F1E8` y dorado neutro `#C9A961`.
- **Tipografía:** Cinzel (logotipo y rótulos), Cormorant Garamond (títulos) y Jost (texto).
- **Estructura:** cabecera con el logotipo al centro y el menú repartido a los lados; catálogo con pestañas de familias y filtros desplegables; productos en marcos con forma de arco; pirámide olfativa escalonada; panel lateral oscuro para asesor y administrador.
- **Logotipo:** emblema SVG (arco, frasco con tapa en bulbo y voluta de humo) con la firma "THE ARABIC CORNER"; el inicio de sesión muestra el logotipo completo (`public/img/logo-the-arabic-corner.jpg`).

## Estructura

```
server.js            API REST y servidor de archivos
lib/http.js          Mini servidor HTTP con enrutador (sin dependencias)
db.js                Conexión a MongoDB, $jsonSchema, índices y datos iniciales
recomendador.js      Motor de coincidencia ponderada
analisis.js          Pronóstico, inventario/ABC, simulador de precios y alertas (agregaciones)
seed/perfumes.js     Catálogo de 157 perfumes árabes con fotos y notas
public/              Frontend (HTML, CSS y JavaScript sin frameworks)
docs/                Términos y Condiciones (PDF, también en /terminos.pdf) y consultas de ejemplo
lib/cifrado.js       Cifrado de campos AES-256-GCM e índice ciego (HMAC)
lib/seguridad.js     Cabeceras, IP real, límite de peticiones, política de contraseñas, red VPN
scripts/             imágenes, llaves, preparar/cifrar/verificar la base, PDF de términos
tests/               Pruebas unitarias (node:test)
deploy/              Caddyfile y scripts del servidor (hardening, VPN, despliegue, respaldo)
Dockerfile, docker-compose.yml, .github/workflows/ci.yml   Contenedores e integración continua
```

## Documentación

| Archivo | Cómo se genera |
|---|---|
| `docs/Terminos_y_Condiciones_The_Arabic_Corner.pdf` | `python scripts/generar_terminos.py` |
| `docs/consultas_mongodb.js` | Consultas y agregaciones de ejemplo para `mongosh` |
