// Autenticación y enrutador principal.
'use strict';

const ROLES = [
  ['cliente', 'Cliente', 'Busca y guarda perfumes'],
  ['asesor', 'Asesor de ventas', 'Atiende y recomienda'],
  ['admin', 'Administrador', 'Gestiona y analiza'],
];
const INICIO = { cliente: '#/catalogo', asesor: '#/atencion', admin: '#/dashboard' };

function authSide() {
  return `<aside class="auth-side">
    <img class="auth-logo" src="img/logo-the-arabic-corner.jpg" alt="The Arabic Corner · Perfumería">
    <p class="lead">Perfumería árabe con un sistema de soporte a la decisión: encuentra tu fragancia entre Lattafa, Armaf, French Avenue, Maison Alhambra, Bharara, Rasasi y más.</p>
    <div class="feats"><span>${icon('grid')}Catálogo</span><span>${icon('spark')}Recomendaciones</span><span>${icon('chart')}Tendencias</span></div>
  </aside>`;
}

function viewLogin() {
  let rol = store.get('tac_last_role', 'cliente');
  $('#app').innerHTML = `<div class="auth">${authSide()}
    <div class="auth-main"><div class="auth-card">
      <div class="eyebrow">Bienvenido</div>
      <h2>Iniciar sesión</h2><p class="muted" style="margin:0 0 24px">Elige tu tipo de acceso para continuar.</p>
      <div class="roles">${ROLES.map(([k, t, s]) => `<button type="button" class="role-opt ${k === rol ? 'active' : ''}" data-rol="${k}"><b>${t}</b><span>${s}</span></button>`).join('')}</div>
      <form id="login" novalidate>
        <div id="l-err"></div>
        <div class="field"><label for="l-mail">Correo electrónico</label><input class="input" id="l-mail" name="correo" type="email" placeholder="nombre@correo.com" autocomplete="username" required></div>
        <div class="field"><label for="l-pass">Contraseña</label><input class="input" id="l-pass" name="password" type="password" placeholder="••••••••" autocomplete="current-password" required></div>
        <div class="field hidden" id="l-mfa"><label for="l-cod">Código de verificación</label>
          <input class="input" id="l-cod" name="codigo" inputmode="numeric" autocomplete="one-time-code" maxlength="7" placeholder="123 456">
          <span class="muted small">Abre tu app autenticadora (Google o Microsoft Authenticator) y escribe el código de 6 dígitos.</span></div>
        <div class="row between" style="margin:-2px 0 18px"><label class="check"><input type="checkbox" name="recordar">Recordarme</label><a href="#" id="l-forgot" class="small">¿Olvidaste tu contraseña?</a></div>
        <button class="btn btn-primary btn-block" id="l-btn" style="padding:13px">Ingresar como cliente</button>
      </form>
      <p class="small muted" style="text-align:center;margin-top:16px" id="l-reg">¿Eres nuevo? <a href="#/registro">Crear cuenta de cliente</a></p>
      <div class="demo-box"><span class="eyebrow">Cuentas de demostración</span><br>
        Cliente: <code>mariana.lopez@correo.com</code> / <code>cliente123</code><br>
        Asesor: <code>jorge.ramirez@thearabiccorner.mx</code> / <code>asesor123</code><br>
        Admin: <code>admin@thearabiccorner.mx</code> / <code>admin123</code></div>
    </div></div></div>`;

  const setRol = (k) => {
    rol = k;
    $$('[data-rol]').forEach((b) => b.classList.toggle('active', b.dataset.rol === k));
    $('#l-btn').textContent = `Ingresar como ${ROLES.find((r) => r[0] === k)[1].toLowerCase()}`;
    $('#l-reg').classList.toggle('hidden', k !== 'cliente');
  };
  setRol(rol);
  api('/config').then((c) => { if (!c.demo) $('.demo-box')?.remove(); }).catch(() => {});
  $$('[data-rol]').forEach((b) => (b.onclick = () => setRol(b.dataset.rol)));
  $('#l-forgot').onclick = (e) => { e.preventDefault(); modalRecuperar(); };
  $('#login').onsubmit = async (e) => {
    e.preventDefault();
    const body = formData(e.target);
    body.recordar = !!body.recordar;
    body.rol = rol;
    if (!body.correo || !body.password) { $('#l-err').innerHTML = '<div class="form-error">Escribe tu correo y contraseña.</div>'; return; }
    $('#l-err').innerHTML = '';
    const btn = $('#l-btn');
    btn.disabled = true;
    try {
      const r = await api('/auth/login', { method: 'POST', body });
      if (r.mfa_requerido) {
        // La contraseña es correcta, pero la cuenta tiene verificación en dos pasos: se pide el código.
        $('#l-mfa').classList.remove('hidden');
        $('#l-btn').textContent = 'Verificar código';
        $('#l-cod').focus();
        if (body.codigo) $('#l-err').innerHTML = '<div class="form-error">Escribe el código de 6 dígitos.</div>';
        return;
      }
      setSession(r.token, r.usuario);
      store.set('tac_last_role', rol);
      location.hash = INICIO[r.usuario.rol];
    } catch (err) {
      $('#l-err').innerHTML = `<div class="form-error">${esc(err.message)}</div>`;
    } finally { btn.disabled = false; }
  };
}

function modalRecuperar() {
  modal(`<div class="modal-head"><h2>Recuperar contraseña</h2><button class="icon-btn plain" data-close>${icon('x')}</button></div>
    <form id="rc"><p class="muted" style="margin-bottom:14px">Escribe el correo de tu cuenta y te enviaremos instrucciones.</p>
      <div class="field"><label>Correo electrónico</label><input class="input" name="correo" type="email" required></div>
      <div class="modal-foot"><button type="button" class="btn btn-outline" data-close>Cancelar</button><button class="btn btn-primary">Enviar</button></div></form>`, {
    onMount: (m, close) => {
      $('#rc', m).onsubmit = async (e) => {
        e.preventDefault();
        const r = await api('/auth/recuperar', { method: 'POST', body: formData(e.target) }).catch((err) => ({ mensaje: err.message }));
        close(); toast(r.mensaje);
      };
    },
  });
}

function viewRegistro() {
  $('#app').innerHTML = `<div class="auth">${authSide()}
    <div class="auth-main"><div class="auth-card">
      <div class="eyebrow">Nuevo cliente</div>
      <h2>Crear cuenta</h2><p class="muted" style="margin:0 0 22px">Regístrate como cliente para guardar favoritos y recibir recomendaciones.</p>
      <form id="reg" novalidate>
        <div id="r-err"></div>
        <div class="field"><label>Nombre completo</label><input class="input" name="nombre" autocomplete="name" required></div>
        <div class="field"><label>Correo electrónico</label><input class="input" name="correo" type="email" placeholder="nombre@correo.com" autocomplete="email" required></div>
        <div class="field"><label>Teléfono <span class="muted" style="font-weight:400">(opcional)</span></label><input class="input" name="telefono" autocomplete="tel"></div>
        <div class="grid2">
          <div class="field"><label>Contraseña</label><input class="input" name="password" type="password" minlength="8" autocomplete="new-password" required><span class="muted small">Mínimo 8 caracteres, con letras y números.</span></div>
          <div class="field"><label>Confirmar</label><input class="input" name="password2" type="password" autocomplete="new-password" required></div>
        </div>
        <label class="check" style="align-items:flex-start;margin-bottom:16px;line-height:1.45"><input type="checkbox" name="acepta_terminos" style="margin-top:3px">
          <span>He leído y acepto los <a href="#" id="r-terms">Términos y Condiciones</a> y el Aviso de Privacidad de The Arabic Corner.</span></label>
        <button class="btn btn-primary btn-block" style="padding:13px">Crear cuenta</button>
      </form>
      <p class="small muted" style="text-align:center;margin-top:16px">¿Ya tienes cuenta? <a href="#/login">Iniciar sesión</a></p>
    </div></div></div>`;
  $('#r-terms').onclick = (e) => {
    e.preventDefault();
    modal(`<div class="modal-head"><h2>Términos y Condiciones</h2><button class="icon-btn plain" data-close>${icon('x')}</button></div>${terminosResumen()}
      <div class="modal-foot"><button class="btn btn-outline" data-close>Cerrar</button><button class="btn btn-primary" id="t-ok">Acepto</button></div>`, {
      wide: true,
      onMount: (m, close) => { $('#t-ok', m).onclick = () => { $('[name=acepta_terminos]').checked = true; close(); }; },
    });
  };
  $('#reg').onsubmit = async (e) => {
    e.preventDefault();
    const b = formData(e.target);
    const err = (m) => { $('#r-err').innerHTML = `<div class="form-error">${esc(m)}</div>`; };
    if (b.password !== b.password2) return err('Las contraseñas no coinciden.');
    b.acepta_terminos = !!b.acepta_terminos;
    try {
      const r = await api('/auth/registro', { method: 'POST', body: b });
      setSession(r.token, r.usuario);
      toast('¡Ahlan wa sahlan! Bienvenido a The Arabic Corner. Responde el buscador para crear tu perfil.');
      location.hash = '#/buscador';
    } catch (ex) { err(ex.message); }
  };
}

// ---------- verificación en dos pasos (administradores y asesores) ----------
async function viewMfa() {
  const view = renderLayout(`
    <div class="page-head"><div><h1>Seguridad de la cuenta</h1>
      <p>Además de tu contraseña, al iniciar sesión se pedirá un código de 6 dígitos que genera una app en tu celular
      (Google Authenticator, Microsoft Authenticator o 1Password). Así, aunque alguien conozca tu contraseña, no puede entrar sin tu celular.</p></div></div>
    <div id="mfa-body">${loading()}</div>
    <div class="card card-pad" style="max-width:620px;margin-top:20px">
      <div class="rule-title" style="margin-bottom:12px">Cambiar contraseña</div>
      <form id="pw-form"><div id="pw-err"></div>
        <div class="field"><label>Contraseña actual</label><input class="input" name="password_actual" type="password" autocomplete="current-password" required></div>
        <div class="grid2"><div class="field"><label>Nueva contraseña</label><input class="input" name="password_nueva" type="password" autocomplete="new-password" required>
          <span class="muted small">Mínimo 8 caracteres, con letras y números.</span></div>
        <div class="field"><label>Confirmar</label><input class="input" name="password2" type="password" autocomplete="new-password" required></div></div>
        <button class="btn btn-outline">Guardar contraseña</button></form></div>`);
  $('#pw-form', view).onsubmit = async (e) => {
    e.preventDefault();
    const b = formData(e.target);
    const err = (m) => { $('#pw-err', view).innerHTML = `<div class="form-error">${esc(m)}</div>`; };
    if (b.password_nueva !== b.password2) return err('Las contraseñas no coinciden.');
    const u = state.user;
    try {
      const r = await api('/perfil', { method: 'PUT', body: { nombre: u.nombre, correo: u.correo, telefono: u.telefono, password_actual: b.password_actual, password_nueva: b.password_nueva } });
      setSession(state.token, r.usuario); e.target.reset(); $('#pw-err', view).innerHTML = '';
      toast('Contraseña actualizada. Se cerraron tus otras sesiones.');
    } catch (ex) { err(ex.message); }
  };
  const d = await api('/mfa');
  const body = $('#mfa-body', view);
  if (d.activo) {
    body.innerHTML = `<div class="card card-pad" style="max-width:620px">
      <div class="rule-title" style="margin-bottom:12px">Verificación en dos pasos</div>
      <p><span class="chip green">Activa</span> desde ${esc(fecha(d.activado))}.</p>
      ${d.obligatoria ? '<p class="muted small" style="margin-top:10px">Es obligatoria para administradores, por lo que no se puede desactivar.</p>' : `
      <form id="mfa-off" style="margin-top:18px"><div id="mfa-err"></div>
        <div class="grid2"><div class="field"><label>Contraseña</label><input class="input" name="password" type="password" autocomplete="current-password" required></div>
        <div class="field"><label>Código actual</label><input class="input" name="codigo" inputmode="numeric" maxlength="7" required></div></div>
        <button class="btn btn-outline">Desactivar</button></form>`}</div>`;
    const f = $('#mfa-off', body);
    if (f) f.onsubmit = async (e) => {
      e.preventDefault();
      try { await api('/mfa/desactivar', { method: 'POST', body: formData(e.target) }); toast('Verificación en dos pasos desactivada.'); viewMfa(); } catch (ex) { $('#mfa-err', body).innerHTML = `<div class="form-error">${esc(ex.message)}</div>`; }
    };
    return;
  }
  body.innerHTML = `<div class="card card-pad" style="max-width:620px">
    <div class="rule-title" style="margin-bottom:12px">Verificación en dos pasos</div>
    ${d.obligatoria ? '<div class="form-error" style="margin-bottom:16px">Para usar el panel de administrador primero debes activar la verificación en dos pasos.</div>' : ''}
    <ol class="steps-list" style="padding-left:20px;line-height:1.7">
      <li>Instala <b>Google Authenticator</b> o <b>Microsoft Authenticator</b> en tu celular.</li>
      <li>Presiona <b>Generar clave</b>. En la app elige <i>Agregar cuenta → Ingresar clave de configuración</i> (tipo: basada en tiempo) y escribe la clave.</li>
      <li>Escribe aquí el código de 6 dígitos que muestra la app.</li>
    </ol>
    <div id="mfa-clave" style="margin:16px 0"><button class="btn btn-primary" id="mfa-gen">Generar clave</button></div>
    <form id="mfa-on" class="hidden"><div id="mfa-err"></div>
      <div class="field" style="max-width:240px"><label>Código de la app</label><input class="input" name="codigo" inputmode="numeric" autocomplete="one-time-code" maxlength="7" placeholder="123 456" required></div>
      <button class="btn btn-primary">Activar</button></form></div>`;
  $('#mfa-gen', body).onclick = async () => {
    const r = await api('/mfa/iniciar', { method: 'POST', body: {} });
    $('#mfa-clave', body).innerHTML = `<div class="muted small">Clave de configuración (cuenta: <b>The Arabic Corner</b>)</div>
      <code style="font-size:18px;letter-spacing:2px;word-break:break-all">${esc(r.secreto.match(/.{1,4}/g).join(' '))}</code>
      <div class="muted small" style="margin-top:8px">No compartas esta clave: quien la tenga puede generar tus códigos.</div>`;
    $('#mfa-on', body).classList.remove('hidden');
    $('#mfa-on [name=codigo]', body).focus();
  };
  $('#mfa-on', body).onsubmit = async (e) => {
    e.preventDefault();
    try {
      await api('/mfa/activar', { method: 'POST', body: formData(e.target) });
      toast('Verificación en dos pasos activada. Desde ahora se pedirá el código al iniciar sesión.');
      if (state.user.rol === 'admin') location.hash = '#/seguridad'; else viewMfa();
    } catch (ex) { $('#mfa-err', body).innerHTML = `<div class="form-error">${esc(ex.message)}</div>`; }
  };
}

// ---------- enrutador ----------
const RUTAS = {
  cliente: {
    catalogo: viewCatalogo, perfume: viewPerfume, buscador: () => viewBuscador(), comparador: viewComparador, perfil: viewPerfil,
  },
  asesor: {
    atencion: viewAtencion, catalogo: viewCatalogo, perfume: viewPerfume, recomendar: () => viewBuscador({ asesor: true }),
    comparador: viewComparador, clientes: viewClientes, mfa: viewMfa,
  },
  admin: {
    dashboard: viewDashboard, perfumes: viewAdminPerfumes, categorias: viewCategorias, tendencias: viewTendencias, perfume: viewPerfume,
    pronostico: viewPronostico, inventario: viewInventario, simulador: viewSimulador, seguridad: viewSeguridad, mfa: viewMfa,
  },
};

async function route() {
  const [, seccion = '', param] = location.hash.replace(/^#/, '').split('/');
  $('#modal-root').innerHTML = '';
  window.scrollTo(0, 0);
  if (!state.token) {
    if (seccion === 'registro') return viewRegistro();
    return viewLogin();
  }
  if (seccion === 'login' || seccion === 'registro') { location.hash = INICIO[state.user.rol]; return; }
  const fn = RUTAS[state.user.rol][seccion];
  if (!fn) { location.hash = INICIO[state.user.rol]; return; }
  try { await fn(param); } catch (e) {
    console.error(e);
    toast(e.message || 'Ocurrió un error', true);
  }
}

window.addEventListener('hashchange', route);
(async () => {
  // Valida la sesión guardada antes de mostrar la app.
  if (state.token) {
    try { const r = await api('/auth/me'); setSession(state.token, r.usuario); } catch { setSession(null, null); }
  }
  route();
})();
