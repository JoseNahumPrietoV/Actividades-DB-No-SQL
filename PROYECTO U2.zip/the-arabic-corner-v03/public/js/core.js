// Núcleo del frontend: estado, API, utilidades y componentes compartidos.
'use strict';

const store = {
  get(k, def = null) { try { const v = localStorage.getItem(k); return v == null ? def : JSON.parse(v); } catch { return def; } },
  set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch { /* sin almacenamiento */ } },
  del(k) { try { localStorage.removeItem(k); } catch { /* sin almacenamiento */ } },
};

const state = {
  token: store.get('tac_token'),
  user: store.get('tac_user'),
  categorias: null,
};

// ---------- API ----------
async function api(path, { method = 'GET', body, raw } = {}) {
  const res = await fetch(`/api${path}`, {
    method,
    headers: {
      ...(body ? { 'Content-Type': 'application/json' } : {}),
      ...(state.token ? { Authorization: `Bearer ${state.token}` } : {}),
    },
    body: body ? JSON.stringify(body) : undefined,
  });
  if (raw) {
    if (!res.ok) throw new Error('No se pudo descargar el archivo.');
    return res;
  }
  const data = await res.json().catch(() => ({}));
  if (res.status === 401 && state.token) {
    setSession(null, null);
    location.hash = '#/login';
  }
  // Administrador sin verificación en dos pasos (cuando es obligatoria): se le lleva a configurarla.
  if (res.status === 403 && data.mfa_pendiente && location.hash !== '#/mfa') location.hash = '#/mfa';
  if (!res.ok) throw new Error(data.error || 'Ocurrió un error.');
  return data;
}

function setSession(token, user) {
  state.token = token; state.user = user;
  if (token) { store.set('tac_token', token); store.set('tac_user', user); } else { store.del('tac_token'); store.del('tac_user'); }
}

async function categorias(force = false) {
  if (!state.categorias || force) state.categorias = await api('/categorias');
  return state.categorias;
}

// ---------- utilidades ----------
const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const money = (n) => '$' + Number(n || 0).toLocaleString('es-MX', { maximumFractionDigits: 0 });
const money2 = (n) => '$' + Number(n || 0).toLocaleString('es-MX', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const lista = (v) => (Array.isArray(v) ? v : String(v || '').split(',')).map((s) => s.trim()).filter(Boolean);
const iniciales = (n) => String(n || '?').split(/\s+/).filter(Boolean).slice(0, 2).map((w) => w[0]).join('').toUpperCase();
const MESES = ['ene', 'feb', 'mar', 'abr', 'may', 'jun', 'jul', 'ago', 'sep', 'oct', 'nov', 'dic'];
const MESES_L = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'];
function fecha(s) {
  if (!s) return '—';
  const [y, m, d] = s.slice(0, 10).split('-').map(Number);
  return `${String(d).padStart(2, '0')} ${MESES[m - 1]} ${y}`;
}
function mesAnio(s) {
  if (!s) return '';
  const [y, m] = s.slice(0, 7).split('-').map(Number);
  return `${MESES_L[m - 1]} ${y}`;
}
const PRESUPUESTOS = { bajo: 'Hasta $800', medio: '$800 – $1,600', alto: 'Más de $1,600' };
const INTENSIDADES = ['Suave', 'Moderada', 'Intensa'];
const PUBLICOS = ['Femenino', 'Masculino', 'Unisex'];
const CONCENTRACIONES = ['Eau de Cologne', 'Eau de Toilette', 'Eau de Parfum', 'Extrait de Parfum'];
const ABREV = { 'Eau de Cologne': 'EDC', 'Eau de Toilette': 'EDT', 'Eau de Parfum': 'EDP', 'Extrait de Parfum': 'Extrait' };

// Niveles para las barras (0–100).
const nivelIntensidad = (i) => ({ Suave: 35, Moderada: 60, Intensa: 88 }[i] || 50);
const nivelProyeccion = (p) => {
  const t = String(p || '').toLowerCase();
  if (t.includes('alta') && t.includes('moderada')) return 72;
  if (t.includes('alta')) return 92;
  if (t.includes('moderada')) return 58;
  return 35;
};
const nivelDuracion = (d) => {
  const nums = String(d || '').match(/\d+/g)?.map(Number) || [];
  const max = nums.length ? Math.max(...nums) : 4;
  return Math.min(100, Math.round((max / 12) * 90) + (String(d).includes('+') ? 8 : 0));
};

// Fondo de los marcos de producto: un mismo tono arena para todas las fotos y frascos (aspecto uniforme).
function tint() { return 'var(--panel)'; }

// ---------- iconos ----------
const ICONS = {
  heart: '<path d="M12 20s-7-4.4-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 10c0 5.6-7 10-7 10z"/>',
  scale: '<path d="M12 3v18M5 7h14M7 7l-3 7a3 3 0 0 0 6 0L7 7zm10 0-3 7a3 3 0 0 0 6 0l-3-7zM8 21h8"/>',
  search: '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>',
  grid: '<rect x="4" y="4" width="7" height="7" rx="1.5"/><rect x="13" y="4" width="7" height="7" rx="1.5"/><rect x="4" y="13" width="7" height="7" rx="1.5"/><rect x="13" y="13" width="7" height="7" rx="1.5"/>',
  spark: '<path d="M12 3v4M12 17v4M3 12h4M17 12h4M6 6l2.5 2.5M15.5 15.5 18 18M6 18l2.5-2.5M15.5 8.5 18 6"/>',
  chart: '<path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/>',
  bottle: '<rect x="9" y="2" width="6" height="4" rx="1"/><rect x="5" y="6" width="14" height="16" rx="4"/>',
  tag: '<path d="M3 12V4a1 1 0 0 1 1-1h8l9 9-9 9-9-9z"/><circle cx="8" cy="8" r="1.5"/>',
  trend: '<path d="m3 17 6-6 4 4 8-8M15 7h6v6"/>',
  chat: '<path d="M4 5h16v11H8l-4 4V5z"/>',
  clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  edit: '<path d="M4 20h4L19 9l-4-4L4 16v4zM14 6l4 4"/>',
  trash: '<path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  x: '<path d="M6 6l12 12M18 6 6 18"/>',
  check: '<path d="m5 12 5 5 9-10"/>',
  menu: '<path d="M4 7h16M4 12h16M4 17h16"/>',
  arrow: '<path d="M5 12h14M13 6l6 6-6 6"/>',
  download: '<path d="M12 4v11M7 10l5 5 5-5M5 20h14"/>',
  user: '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',
  upload: '<path d="M12 20V9M7 14l5-5 5 5M5 4h14"/>',
  bell: '<path d="M6 9a6 6 0 0 1 12 0c0 5 2 7 2 7H4s2-2 2-7zM10 20a2 2 0 0 0 4 0"/>',
  box: '<path d="M3 7l9-4 9 4v10l-9 4-9-4V7zM3 7l9 4 9-4M12 11v10"/>',
  sliders: '<path d="M4 6h10M18 6h2M4 12h4M12 12h8M4 18h12M20 18h0"/><circle cx="16" cy="6" r="2"/><circle cx="10" cy="12" r="2"/><circle cx="18" cy="18" r="2"/>',
  shield: '<path d="M12 3l8 3v6c0 4.5-3.4 8.3-8 9-4.6-.7-8-4.5-8-9V6l8-3z"/><path d="m9 12 2 2 4-4"/>',
  forecast: '<path d="M3 17l5-5 4 3 4-6"/><path d="M16 9l5-4" stroke-dasharray="2 2"/><path d="M3 21h18"/>',
};
const icon = (n, cls = '') => `<svg class="i ${cls}" viewBox="0 0 24 24" aria-hidden="true">${ICONS[n] || ''}</svg>`;

// Frasco ilustrado de inspiración árabe (se usa cuando el perfume no tiene foto):
// tapa en cúpula dorada, cuello con collar y cuerpo octagonal facetado.
function bottleSvg(color = '#8B4A2B', w = 60) {
  const h = Math.round(w * 1.5);
  return `<svg width="${w}" height="${h}" viewBox="0 0 60 90" aria-hidden="true">
    <path d="M30 1.5l2.4 4h-4.8z" fill="#B8913F"/>
    <path d="M20.5 17c0-7 4.2-11.5 9.5-11.5S39.5 10 39.5 17z" fill="#C9A961"/>
    <path d="M24 16.5c0-5 2.4-8.5 5-9.6" fill="none" stroke="#fff" stroke-opacity=".45" stroke-width="1.3" stroke-linecap="round"/>
    <rect x="19" y="16.5" width="22" height="3.6" rx="1.2" fill="#9C7B3C"/>
    <rect x="25" y="20" width="10" height="4.5" fill="#B89A62"/>
    <path d="M17 24.5h26l10 10v40l-10 13H17l-10-13v-40z" fill="${esc(color)}"/>
    <path d="M17 24.5l-10 10v40l10 13z" fill="#fff" opacity=".14"/>
    <path d="M43 24.5l10 10v40l-10 13z" fill="#000" opacity=".14"/>
    <path d="M11 37v34" stroke="#fff" stroke-opacity=".25" stroke-width="2" stroke-linecap="round"/>
    <rect x="18" y="46" width="24" height="17" rx="1.5" fill="#F4ECDD" stroke="#C9A961" stroke-width="1.2"/>
    <path d="M30 49.5l1.1 2.4 2.4 1.1-2.4 1.1-1.1 2.4-1.1-2.4-2.4-1.1 2.4-1.1z" fill="#C9A961"/>
    <path d="M23.5 59.5h13" stroke="#C9A961" stroke-width=".9"/>
  </svg>`;
}

function perfumeVisual(p, w = 60) {
  if (p.imagen) {
    return `<img class="pimg" src="${esc(p.imagen)}" alt="${esc(p.nombre)}" loading="lazy" referrerpolicy="no-referrer" data-color="${esc(p.color || '')}" data-w="${w}">`;
  }
  return bottleSvg(p.color, w);
}
// Si una foto no carga (enlace caído o sin internet), se muestra el frasco ilustrado en su lugar.
// Se usa un solo escuchador global (fase de captura) en lugar de atributos onerror: la política CSP prohíbe
// JavaScript en línea, lo que bloquea inyecciones de código (XSS).
document.addEventListener('error', (e) => { if (e.target?.classList?.contains('pimg')) window.pimgError(e.target); }, true);
window.pimgError = (img) => {
  const span = document.createElement('span');
  span.innerHTML = bottleSvg(img.dataset.color || '#8B4A2B', Number(img.dataset.w) || 60);
  img.replaceWith(span.firstElementChild);
};

// Logotipo: arco de cúpula con un frasco de tapa en bulbo y una voluta de humo (basado en el logo de la marca).
function logoSvg() {
  return `<svg class="emblem" viewBox="0 0 40 48" aria-hidden="true" fill="none" stroke="currentColor">
    <path d="M5 46V23.5C5 16.5 10.5 13.6 14.2 11.6 17 10.1 19 7.6 20 3.5c1 4.1 3 6.6 5.8 8.1C29.5 13.6 35 16.5 35 23.5V46" stroke-width="1.5"/>
    <path d="M20 13.2c1.6 1.4 2.3 2.8 2.3 4 0 1.3-1 2.1-2.3 2.1s-2.3-.8-2.3-2.1c0-1.2.7-2.6 2.3-4z" fill="currentColor" stroke="none"/>
    <path d="M17.6 20h4.8M18.4 20v2.4h3.2V20" stroke-width="1.2"/>
    <path d="M15 25.2l1.7-2.8h6.6l1.7 2.8v13.6l-1.2 1.8h-7.6L15 38.8z" stroke-width="1.4"/>
    <path d="M17.6 25.6v12.2M22.4 25.6v12.2" stroke-width=".6" opacity=".6"/>
    <path d="M20.6 28.2c-1.6 1.2-1.6 2.6 0 3.6s1.4 2.6-.4 3.6" stroke-width="1.1"/>
    <path d="M13.6 27c-4.6 1.6-5 5.4-.8 7.6 3.4 1.8 3 4.4-1.4 6.4" stroke-width="1.2" opacity=".55"/>
    <path d="M9 42.6c7.5-1.2 14.5-1.2 22 0" stroke-width="1"/>
  </svg>`;
}
// Firma completa: emblema + "THE ARABIC CORNER" en Cinzel.
function lockup(href, oscuro = false) {
  return `<a class="lockup${oscuro ? ' on-dark' : ''}" href="${href}" aria-label="The Arabic Corner — inicio">${logoSvg()}
    <span class="wm"><span class="wm-the">The</span><span class="wm-main">Arabic</span><span class="wm-sub">Corner</span></span></a>`;
}
const BRAND = 'The Arabic Corner';

// ---------- toasts y modales ----------
function toast(msg, err = false) {
  const el = document.createElement('div');
  el.className = `toast${err ? ' err' : ''}`;
  el.textContent = msg;
  $('#toasts').appendChild(el);
  setTimeout(() => el.remove(), 3200);
}

function modal(html, { wide = false, onMount } = {}) {
  const root = $('#modal-root');
  root.innerHTML = `<div class="modal-bg"><div class="modal ${wide ? 'wide' : ''}" role="dialog" aria-modal="true">${html}</div></div>`;
  const bg = $('.modal-bg', root);
  const close = () => { root.innerHTML = ''; document.removeEventListener('keydown', onKey); };
  const onKey = (e) => { if (e.key === 'Escape') close(); };
  document.addEventListener('keydown', onKey);
  bg.addEventListener('mousedown', (e) => { if (e.target === bg) close(); });
  $$('[data-close]', root).forEach((b) => b.addEventListener('click', close));
  onMount?.($('.modal', root), close);
  return close;
}

function confirmar(titulo, texto, { ok = 'Confirmar', peligro = false } = {}) {
  return new Promise((resolve) => {
    modal(`<div class="modal-head"><h2>${esc(titulo)}</h2></div><p class="muted">${esc(texto)}</p>
      <div class="modal-foot"><button class="btn btn-outline" data-close>Cancelar</button>
      <button class="btn ${peligro ? 'btn-danger' : 'btn-primary'}" id="cf-ok">${esc(ok)}</button></div>`, {
      onMount: (m, close) => {
        $('#cf-ok', m).onclick = () => { close(); resolve(true); };
        $$('[data-close]', m).forEach((b) => b.addEventListener('click', () => resolve(false)));
      },
    });
  });
}

// Maneja envíos de formularios con estado de carga y errores.
async function withBusy(btn, fn) {
  const txt = btn.innerHTML;
  btn.disabled = true;
  btn.innerHTML = 'Guardando…';
  try { return await fn(); } catch (e) { toast(e.message, true); return undefined; } finally { btn.disabled = false; btn.innerHTML = txt; }
}

const formData = (form) => Object.fromEntries(new FormData(form).entries());

// ---------- comparador (compartido) ----------
const comparador = {
  ids() { return store.get('tac_cmp', []); },
  set(ids) { store.set('tac_cmp', ids.slice(0, 3)); updateCmpBadge(); },
  toggle(id) {
    const ids = this.ids();
    if (ids.includes(id)) { this.set(ids.filter((x) => x !== id)); toast('Quitado del comparador'); return false; }
    if (ids.length >= 3) { toast('El comparador admite hasta 3 perfumes. Quita uno primero.', true); return null; }
    this.set([...ids, id]); toast('Agregado al comparador'); return true;
  },
};
function updateCmpBadge() {
  const n = comparador.ids().length;
  $$('[data-cmp-badge]').forEach((b) => { b.textContent = n; b.classList.toggle('hidden', !n); });
}

// Cliente activo del asesor (para calcular coincidencias con su perfil).
const clienteActivo = {
  get() { return store.get('tac_cliente_activo'); },
  set(c) { if (c) store.set('tac_cliente_activo', { id: c.id, nombre: c.nombre }); else store.del('tac_cliente_activo'); },
};

// ---------- layouts ----------
const NAV = {
  cliente: [
    ['#/catalogo', 'Catálogo', 'grid'],
    ['#/buscador', 'Buscador inteligente', 'spark'],
    ['#/comparador', 'Comparador', 'scale'],
    ['#/perfil', 'Mi perfil', 'user'],
  ],
  asesor: [
    ['#/atencion', 'Atención a cliente', 'chat'],
    ['#/catalogo', 'Consultar catálogo', 'grid'],
    ['#/recomendar', 'Recomendar productos', 'spark'],
    ['#/comparador', 'Comparador', 'scale'],
    ['#/clientes', 'Historial de clientes', 'clock'],
    ['#/mfa', 'Seguridad de la cuenta', 'shield'],
  ],
  admin: [
    ['#/dashboard', 'Dashboard', 'chart'],
    ['#/perfumes', 'Gestión de perfumes', 'bottle'],
    ['#/categorias', 'Categorías', 'tag'],
    ['#/tendencias', 'Tendencias', 'trend'],
    ['#/pronostico', 'Pronóstico', 'forecast'],
    ['#/inventario', 'Inventario', 'box'],
    ['#/simulador', 'Simulador de precios', 'sliders'],
    ['#/seguridad', 'Seguridad', 'shield'],
    ['#/mfa', 'Mi cuenta', 'user'],
  ],
};

function navActive(href) {
  const cur = location.hash.split('/')[1] || '';
  const h = href.split('/')[1];
  if (cur === 'perfume') return h === 'catalogo';
  return cur === h;
}

function renderLayout(content) {
  const u = state.user;
  const app = $('#app');
  if (u.rol === 'cliente') {
    const link = ([h, t]) => `<a href="${h}" class="${navActive(h) ? 'active' : ''}">${t}${h === '#/comparador' ? '<span class="cmp-badge hidden" data-cmp-badge></span>' : ''}</a>`;
    app.innerHTML = `
      <header class="masthead">
        <div class="mh-inner">
          <nav class="mh-nav left">${NAV.cliente.slice(0, 2).map(link).join('')}</nav>
          ${lockup('#/catalogo')}
          <div class="mh-nav right">${NAV.cliente.slice(2).map(link).join('')}
            <div class="mh-tools user-mini">
              <button class="icon-btn plain bell" data-alertas aria-label="Alertas">${icon('bell')}<span class="bell-badge hidden" data-alertas-badge></span></button>
              <a href="#/perfil" class="avatar" title="${esc(u.nombre)}" style="text-decoration:none">${esc(iniciales(u.nombre))}</a>
              <button class="logout" data-logout>Salir</button>
              <button class="icon-btn plain menu-toggle" id="menu-toggle" aria-label="Menú">${icon('menu')}</button>
            </div>
          </div>
        </div>
        <nav class="mobile-nav" id="mobile-nav">${NAV.cliente.map(link).join('')}<a href="#" data-logout>Cerrar sesión</a></nav>
      </header>
      <main class="main" id="view">${content}</main>`;
    $('#menu-toggle').onclick = () => $('#mobile-nav').classList.toggle('open');
  } else {
    const rol = u.rol === 'admin' ? 'Administrador' : 'Asesor de ventas';
    app.innerHTML = `
      <div class="shell">
        <aside class="sidebar">
          ${lockup('#/', true)}
          <div class="role row between">${rol}${u.rol === 'admin' ? `<button class="bell-side" data-alertas aria-label="Alertas">${icon('bell')}<span class="bell-badge hidden" data-alertas-badge></span></button>` : ''}</div>
          <nav>${NAV[u.rol].map(([h, t, ic]) => `<a href="${h}" class="${navActive(h) ? 'active' : ''}">${icon(ic)}${t}${h === '#/comparador' ? ' <span class="cmp-badge hidden" data-cmp-badge></span>' : ''}</a>`).join('')}</nav>
          <div class="me">
            <div class="row"><div class="avatar gold">${esc(iniciales(u.nombre))}</div>
              <div><div class="n">${esc(u.nombre)}</div><div class="s">${esc(u.sucursal || '')}</div></div></div>
            <button class="logout" data-logout>Cerrar sesión</button>
          </div>
        </aside>
        <main class="shell-main" id="view">${content}</main>
      </div>`;
  }
  $$('[data-logout]').forEach((b) => (b.onclick = logout));
  $$('[data-alertas]').forEach((b) => (b.onclick = () => modalAlertas()));
  updateCmpBadge();
  cargarAlertas();
  return $('#view');
}

// ---------- alertas por excepción ----------
const NIVEL_ALERTA = { alta: ['red', 'Urgente'], media: ['amber', 'Atención'], info: ['blue', 'Aviso'] };

async function cargarAlertas() {
  if (!['cliente', 'admin'].includes(state.user?.rol)) return [];
  try { state.alertas = await api('/alertas'); } catch { state.alertas = []; }
  const n = state.alertas.filter((a) => a.nivel !== 'info').length || state.alertas.length;
  $$('[data-alertas-badge]').forEach((b) => { b.textContent = n; b.classList.toggle('hidden', !state.alertas.length); });
  return state.alertas;
}

function alertaHtml(a) {
  const [color, etiqueta] = NIVEL_ALERTA[a.nivel] || NIVEL_ALERTA.info;
  return `<div class="alerta ${a.nivel}">
    <div class="row between" style="align-items:flex-start"><div><span class="chip ${color}">${etiqueta}</span> <span class="muted small">${esc(a.categoria)}</span></div>
      ${a.descartable ? `<button class="icon-btn plain" data-descartar="${a.perfume_id}" title="Descartar">${icon('x')}</button>` : ''}</div>
    <b>${esc(a.titulo)}</b><p>${esc(a.detalle)}</p>
    ${a.href ? `<a href="${a.href}" class="small" data-close>Ver →</a>` : ''}</div>`;
}

function bindAlertas(root, alRecargar) {
  $$('[data-descartar]', root).forEach((b) => (b.onclick = async () => {
    await api(`/alertas/precio/${b.dataset.descartar}/visto`, { method: 'POST' }).catch(() => {});
    await cargarAlertas();
    alRecargar?.();
  }));
}

async function modalAlertas() {
  const pintar = (m) => {
    const al = state.alertas || [];
    $('#al-list', m).innerHTML = al.length ? al.map(alertaHtml).join('') : '<p class="muted">No hay alertas por ahora. 🎉</p>';
    bindAlertas(m, () => pintar(m));
    $$('[data-close]', m).forEach((x) => x.addEventListener('click', () => { $('#modal-root').innerHTML = ''; }));
  };
  modal(`<div class="modal-head"><h2>Alertas</h2><button class="icon-btn plain" data-close>${icon('x')}</button></div>
    <p class="muted small" style="margin:-8px 0 14px">El sistema te avisa de situaciones que requieren una decisión.</p>
    <div id="al-list">${loading()}</div>`, { wide: true, onMount: async (m) => { await cargarAlertas(); pintar(m); } });
}

async function logout() {
  try { await api('/auth/logout', { method: 'POST' }); } catch { /* ya expirada */ }
  setSession(null, null);
  clienteActivo.set(null);
  state.categorias = null;
  location.hash = '#/login';
}

const loading = () => '<div class="spinner" role="status" aria-label="Cargando"></div>';

// ---------- componentes compartidos ----------
function perfumeCard(p, { onFav = true, match = true } = {}) {
  const inCmp = comparador.ids().includes(p.id);
  return `<article class="pcard" data-id="${p.id}">
    <a class="ph" href="#/perfume/${p.id}" aria-label="${esc(p.nombre)}">
      ${perfumeVisual(p, 46)}
      <span class="chip">${esc(p.familia)}</span>
    </a>
    ${onFav && state.user.rol === 'cliente' ? `<button class="fav ${p.favorito ? 'on' : ''}" data-fav="${p.id}" aria-label="Favorito">${icon('heart')}</button>` : ''}
    ${p.existencias === 0 ? '<span class="chip red agotado">Agotado</span>' : match && p.match != null ? `<span class="match-tag">${p.match}%</span>` : ''}
    <div class="body">
      <div class="brandname">${esc(p.marca)}</div>
      <h3><a href="#/perfume/${p.id}">${esc(p.nombre)}</a></h3>
      <div class="conc">${esc(p.concentracion)} · ${p.ml} ml</div>
      <div class="price">${money(p.precio)} MXN</div>
      <div class="actions">
        <a class="btn btn-outline btn-sm" href="#/perfume/${p.id}">Ver detalle</a>
        <button class="icon-btn" data-cmp="${p.id}" title="${inCmp ? 'Quitar del comparador' : 'Agregar al comparador'}" style="${inCmp ? 'border-color:var(--gold);color:var(--gold-ink)' : ''}">${icon('scale')}</button>
      </div>
    </div>
  </article>`;
}

function bindCardActions(root, refresh) {
  $$('[data-fav]', root).forEach((b) => (b.onclick = async (e) => {
    e.preventDefault();
    const id = b.dataset.fav;
    const on = b.classList.contains('on');
    try {
      await api(`/favoritos/${id}`, { method: on ? 'DELETE' : 'POST' });
      b.classList.toggle('on', !on);
      toast(on ? 'Quitado de favoritos' : 'Guardado en favoritos');
    } catch (err) { toast(err.message, true); }
  }));
  $$('[data-cmp]', root).forEach((b) => (b.onclick = () => {
    const r = comparador.toggle(Number(b.dataset.cmp));
    if (r !== null) { b.style.borderColor = r ? 'var(--gold)' : ''; b.style.color = r ? 'var(--gold-ink)' : ''; }
    refresh?.();
  }));
}

// Texto de términos resumido para el modal de registro.
function terminosResumen() {
  return `<div class="terms-text">
    <p>Al crear tu cuenta aceptas los Términos y Condiciones de uso de The Arabic Corner. Puntos principales:</p>
    <h4>1. Naturaleza del servicio</h4><p>The Arabic Corner es un sistema de soporte a la decisión. Las recomendaciones y porcentajes de coincidencia son orientativos y se calculan con base en tus respuestas; no garantizan que un perfume sea de tu agrado.</p>
    <h4>2. Tu cuenta</h4><p>Eres responsable de la confidencialidad de tu contraseña y de la veracidad de tus datos.</p>
    <h4>3. Datos personales</h4><p>Tratamos tu nombre, correo, teléfono, preferencias olfativas e historial de uso para personalizar recomendaciones y generar estadísticas agregadas y anónimas. Puedes ejercer tus derechos ARCO y eliminar tu cuenta desde Mi perfil.</p>
    <h4>4. Precios y disponibilidad</h4><p>Los precios se muestran en MXN, incluyen IVA y pueden cambiar sin previo aviso. La compra se realiza en tienda.</p>
    <h4>5. Salud</h4><p>Los perfumes árabes suelen ser concentrados y de larga duración. Consulta la lista de notas de cada fragancia y realiza una prueba en piel si tienes alergias o sensibilidad.</p>
    <p style="margin-top:14px"><a href="/terminos.pdf" target="_blank" rel="noopener">${icon('download')} Descargar documento completo (PDF)</a></p>
  </div>`;
}
