#!/usr/bin/env bash
# Publica la versión más reciente del repositorio en el servidor (se ejecuta en la VM, conectado por la VPN).
# Uso:  bash deploy/desplegar.sh            → actualiza el código y reinicia los contenedores
#       bash deploy/desplegar.sh --primera  → además prepara la base de datos (colecciones, índices, datos si está vacía)
set -euo pipefail
cd "$(dirname "$0")/.."

[[ -f .env ]] || { echo "Falta el archivo .env (cópialo de .env.example y llénalo)."; exit 1; }
chmod 600 .env   # solo el dueño puede leer los secretos
grep -q '^DOMINIO=.\+' .env || { echo "Define DOMINIO en el .env."; exit 1; }
grep -q '^DATA_KEY=.\+' .env || { echo "Define DATA_KEY e INDEX_KEY en el .env (las MISMAS que usaste en tu computadora)."; exit 1; }

echo "▶ Descargando la versión más reciente…"
git pull --ff-only

echo "▶ Construyendo la imagen…"
docker compose build app

if [[ "${1:-}" == "--primera" ]]; then
  echo "▶ Preparando la base de datos…"
  docker compose run --rm --no-deps app node scripts/preparar_bd.js
fi

echo "▶ Iniciando contenedores…"
docker compose up -d
docker image prune -f >/dev/null
sleep 5
docker compose ps
echo
echo "✓ Sitio público:  https://$(grep '^DOMINIO=' .env | cut -d= -f2)"
echo "✓ Panel admin:    http://10.8.0.1:8080   (solo conectado a la VPN)"
echo "  Registros:      docker compose logs -f"
