#!/usr/bin/env bash
# =====================================================================================
#  The Arabic Corner — endurecimiento (hardening) de la máquina virtual de Azure
#  Ubuntu Server 24.04 LTS.  Ejecutar UNA vez:   sudo bash deploy/preparar_servidor.sh
#
#  Qué hace:
#   1. Actualiza el sistema y activa las actualizaciones de seguridad automáticas.
#   2. Instala Docker, WireGuard, ufw y fail2ban.
#   3. Crea la VPN WireGuard (servidor 10.8.0.1) y el primer cliente "admin" (10.8.0.2).
#   4. Configura el firewall ufw: público solo 80/443 (web) y 51820/udp (VPN);
#      SSH y el panel de administración (8080) solo desde la VPN.
#      SSH público queda abierto TEMPORALMENTE hasta que compruebes la VPN (luego: cerrar_ssh_publico.sh).
#   5. Endurece SSH (sin contraseñas, sin root, máx. 3 intentos) y activa fail2ban.
# =====================================================================================
set -euo pipefail

if [[ $EUID -ne 0 ]]; then echo "Ejecuta con sudo: sudo bash deploy/preparar_servidor.sh"; exit 1; fi
USUARIO="${SUDO_USER:-azureuser}"
VPN_RED="10.8.0"
VPN_PUERTO=51820
CLIENTES_DIR="/home/${USUARIO}/vpn-clientes"

paso() { echo -e "\n\033[1;33m▶ $*\033[0m"; }

# --------------------------------------------------------------------------- 1. sistema
paso "1/6 Actualizando el sistema"
export DEBIAN_FRONTEND=noninteractive
apt-get update -y
apt-get upgrade -y
apt-get install -y ufw wireguard qrencode fail2ban unattended-upgrades ca-certificates curl git
dpkg-reconfigure -f noninteractive unattended-upgrades

# Memoria de intercambio (la VM B1s tiene 1 GB de RAM).
if ! swapon --show | grep -q swapfile; then
  fallocate -l 2G /swapfile && chmod 600 /swapfile && mkswap /swapfile && swapon /swapfile
  echo '/swapfile none swap sw 0 0' >> /etc/fstab
fi

# --------------------------------------------------------------------------- 2. docker
paso "2/6 Instalando Docker"
if ! command -v docker >/dev/null; then
  curl -fsSL https://get.docker.com | sh
fi
usermod -aG docker "$USUARIO"
systemctl enable --now docker

# --------------------------------------------------------------------------- 3. wireguard
paso "3/6 Configurando la VPN WireGuard"
IP_PUBLICA="${1:-$(curl -fsS https://api.ipify.org || true)}"
if [[ -z "$IP_PUBLICA" ]]; then read -rp "IP pública de la VM: " IP_PUBLICA; fi

umask 077
mkdir -p /etc/wireguard "$CLIENTES_DIR"
if [[ ! -f /etc/wireguard/servidor.key ]]; then
  wg genkey | tee /etc/wireguard/servidor.key | wg pubkey > /etc/wireguard/servidor.pub
fi
SERVIDOR_PRIV=$(cat /etc/wireguard/servidor.key)
if [[ ! -f /etc/wireguard/wg0.conf ]]; then
  cat > /etc/wireguard/wg0.conf <<EOF
# VPN de administración de The Arabic Corner
[Interface]
Address = ${VPN_RED}.1/24
ListenPort = ${VPN_PUERTO}
PrivateKey = ${SERVIDOR_PRIV}
EOF
fi
echo "$IP_PUBLICA" > /etc/wireguard/endpoint
systemctl enable --now wg-quick@wg0

# Primer cliente de la VPN (tu computadora).
bash "$(dirname "$0")/vpn_nuevo_cliente.sh" admin

# --------------------------------------------------------------------------- 4. firewall
paso "4/6 Configurando el firewall (ufw)"
ufw --force reset
ufw default deny incoming
ufw default allow outgoing
ufw allow 80/tcp  comment 'HTTP (redirige a HTTPS / Lets Encrypt)'
ufw allow 443/tcp comment 'HTTPS'
ufw allow ${VPN_PUERTO}/udp comment 'WireGuard VPN'
ufw allow in on wg0 to any port 22 proto tcp comment 'SSH solo por VPN'
ufw allow in on wg0 to any port 8080 proto tcp comment 'Panel admin solo por VPN'
ufw allow 22/tcp comment 'TEMPORAL: SSH publico (cerrar con cerrar_ssh_publico.sh)'
ufw logging on
ufw --force enable

# --------------------------------------------------------------------------- 5. ssh + fail2ban
paso "5/6 Endureciendo SSH y activando fail2ban"
if [[ -s "/home/${USUARIO}/.ssh/authorized_keys" ]]; then
  cat > /etc/ssh/sshd_config.d/99-the-arabic-corner.conf <<'EOF'
# Endurecimiento de SSH (The Arabic Corner)
PasswordAuthentication no
KbdInteractiveAuthentication no
PermitRootLogin no
MaxAuthTries 3
LoginGraceTime 30
X11Forwarding no
AllowAgentForwarding no
EOF
  systemctl reload ssh || systemctl reload sshd
else
  echo "⚠  No hay llave SSH en /home/${USUARIO}/.ssh/authorized_keys: NO se desactivan las contraseñas para no dejarte fuera."
fi
cat > /etc/fail2ban/jail.d/sshd.local <<'EOF'
[sshd]
enabled = true
maxretry = 4
bantime = 1h
EOF
systemctl enable --now fail2ban
systemctl restart fail2ban

# --------------------------------------------------------------------------- 6. resumen
chown -R "$USUARIO":"$USUARIO" "$CLIENTES_DIR"
paso "6/6 Listo"
cat <<EOF

  IP pública de la VM .......... ${IP_PUBLICA}
  VPN del servidor ............. ${VPN_RED}.1  (puerto ${VPN_PUERTO}/udp)
  Configuración de tu VPN ...... ${CLIENTES_DIR}/admin.conf  (QR arriba)

  Siguientes pasos:
   1. Copia admin.conf a tu computadora e impórtalo en la app WireGuard. Actívala.
   2. Prueba:   ssh ${USUARIO}@${VPN_RED}.1      (debe entrar por la VPN)
   3. Si funciona:   sudo bash deploy/cerrar_ssh_publico.sh
      y en Azure elimina la regla de entrada del puerto 22.
   4. Cierra sesión y vuelve a entrar para usar docker sin sudo.

EOF
ufw status verbose
