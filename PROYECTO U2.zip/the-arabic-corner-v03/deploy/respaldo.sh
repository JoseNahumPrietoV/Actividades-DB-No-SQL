#!/usr/bin/env bash
# Respaldo manual de la base de datos (el plan gratuito M0 de Atlas no incluye respaldos automáticos).
# Usa la imagen oficial de MongoDB solo para ejecutar mongodump; el respaldo queda en ./respaldos/AAAA-MM-DD.
# Los campos sensibles siguen cifrados dentro del respaldo (sin DATA_KEY no se pueden leer).
# Uso:  bash deploy/respaldo.sh
set -euo pipefail
cd "$(dirname "$0")/.."
# Se lee el .env sin "source": las cadenas de conexión contienen & y ? que el shell interpretaría.
leer() { grep -E "^$1=" .env | head -1 | cut -d= -f2- || true; }
URI="$(leer MONGODB_URI_ADMIN)"; URI="${URI:-$(leer MONGODB_URI)}"
BD="$(leer MONGODB_DB)"; BD="${BD:-the_arabic_corner}"
DESTINO="respaldos/$(date +%F)"
mkdir -p "$DESTINO"
docker run --rm --network host -v "$PWD/$DESTINO":/respaldo mongo:7 \
  mongodump --uri "$URI" --db "$BD" --gzip --out /respaldo
chmod -R go-rwx respaldos
echo "✓ Respaldo en $DESTINO"
