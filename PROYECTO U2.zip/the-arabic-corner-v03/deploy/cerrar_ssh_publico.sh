#!/usr/bin/env bash
# Cierra el acceso SSH desde internet: a partir de aquí el servidor solo se administra conectado a la VPN.
# Ejecútalo CONECTADO POR LA VPN (ssh azureuser@10.8.0.1) para no perder la sesión.
# Uso:  sudo bash deploy/cerrar_ssh_publico.sh
set -euo pipefail
if [[ "${SSH_CONNECTION:-}" != 10.8.0.* ]]; then
  echo "⚠  No parece que estés conectado por la VPN (SSH_CONNECTION=${SSH_CONNECTION:-?})."
  read -rp "¿Continuar de todos modos? (escribe SI): " r; [[ "$r" == "SI" ]] || exit 1
fi
while ufw status numbered | grep -q 'TEMPORAL'; do
  num=$(ufw status numbered | grep 'TEMPORAL' | head -1 | sed -E 's/^\[ *([0-9]+)\].*/\1/')
  ufw --force delete "$num"
done
echo "✓ SSH público cerrado. Reglas actuales:"
ufw status verbose
echo
echo "Último paso en Azure: VM → Redes → elimina la regla de entrada del puerto 22 (SSH)."
