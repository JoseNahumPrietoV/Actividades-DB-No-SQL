#!/usr/bin/env bash
# Agrega un dispositivo a la VPN WireGuard (por ejemplo, la laptop de otro integrante del equipo).
# Uso:  sudo bash deploy/vpn_nuevo_cliente.sh <nombre>
# Genera <nombre>.conf en ~/vpn-clientes y muestra un QR (para la app WireGuard del celular).
set -euo pipefail
NOMBRE="${1:?Uso: sudo bash deploy/vpn_nuevo_cliente.sh <nombre>}"
[[ "$NOMBRE" =~ ^[a-zA-Z0-9_-]+$ ]] || { echo "Nombre inválido (solo letras, números, - y _)."; exit 1; }
USUARIO="${SUDO_USER:-azureuser}"
DIR="/home/${USUARIO}/vpn-clientes"
CONF=/etc/wireguard/wg0.conf
umask 077
mkdir -p "$DIR"
if grep -q "# cliente: ${NOMBRE}$" "$CONF"; then echo "El cliente ${NOMBRE} ya existe ($DIR/${NOMBRE}.conf)."; exit 0; fi

# Siguiente IP libre de 10.8.0.2 a 10.8.0.254
for n in $(seq 2 254); do grep -q "10.8.0.${n}/32" "$CONF" || { IP="10.8.0.${n}"; break; }; done
PRIV=$(wg genkey); PUB=$(echo "$PRIV" | wg pubkey); PSK=$(wg genpsk)
ENDPOINT=$(cat /etc/wireguard/endpoint)

cat >> "$CONF" <<EOF

[Peer]
# cliente: ${NOMBRE}
PublicKey = ${PUB}
PresharedKey = ${PSK}
AllowedIPs = ${IP}/32
EOF

cat > "${DIR}/${NOMBRE}.conf" <<EOF
# VPN The Arabic Corner — ${NOMBRE}
[Interface]
PrivateKey = ${PRIV}
Address = ${IP}/32

[Peer]
PublicKey = $(cat /etc/wireguard/servidor.pub)
PresharedKey = ${PSK}
Endpoint = ${ENDPOINT}:51820
# Solo el tráfico hacia la red de administración pasa por el túnel (split tunnel).
AllowedIPs = 10.8.0.0/24
PersistentKeepalive = 25
EOF
chown "$USUARIO":"$USUARIO" "${DIR}/${NOMBRE}.conf"

# Aplica el cambio sin cortar las conexiones activas.
wg syncconf wg0 <(wg-quick strip wg0)
echo "✓ Cliente ${NOMBRE} creado con IP ${IP}: ${DIR}/${NOMBRE}.conf"
qrencode -t ansiutf8 < "${DIR}/${NOMBRE}.conf" || true
