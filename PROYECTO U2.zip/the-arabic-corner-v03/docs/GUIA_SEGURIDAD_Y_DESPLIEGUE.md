# The Arabic Corner — Guía de seguridad y despliegue (Proyecto U2)

Esta guía cubre los requisitos del proyecto U2:

| Requisito | Cómo se cumple | Parte |
|---|---|---|
| Modernización de BD y stack | SQLite → **MongoDB Atlas**; GitHub + GitHub Actions (CI), despliegue continuo en Render, secretos fuera del código | 1, 2, 5 |
| 2 servicios del GitHub Student Pack | **MongoDB Atlas** (base de datos) + **Namecheap** (dominio `.me` gratis 1 año). Además: **GitHub Pro** (Actions) y, opcional, **1Password** para guardar llaves y contraseñas | 3, 5 |
| Control de acceso y autenticación (roles–usuarios) | Roles de la app (cliente/asesor/admin) + **3 usuarios de BD con mínimo privilegio** + **verificación en dos pasos (TOTP) obligatoria para administradores** + bloqueo por intentos + bitácora | 3, 4, 5 |
| Cifrado en tránsito | **HTTPS** (certificado Let's Encrypt automático de Render, TLS 1.2/1.3) + **TLS** obligatorio hacia Atlas | 3, 5 |
| Cifrado del lado de la BD | **Encryption at rest** de Atlas (AES-256) + **cifrado de campos** AES-256-GCM en la app (también el secreto 2FA) | 2, 4 |
| Hardening de red: firewall | **Lista de IP de Atlas** con solo las IP de salida de Render (y la tuya); límite de peticiones por IP; cabeceras de seguridad (CSP, HSTS, X-Frame-Options) | 3, 5 |
| Hardening de red: VPN | Render no permite instalar una VPN propia. Se sustituye por **2FA obligatoria** en el panel de administrador y, opcional, **restricción por IP** (`ADMIN_REDES`). El diseño con VPN WireGuard para un servidor propio queda documentado en el **Anexo A** | 5, A |
| Deploy del front en un servicio | **Render** (Web Service, plan gratuito) conectado al repositorio de GitHub, con dominio propio | 5 |

---

## Arquitectura

```
                               INTERNET
                                  │
   Clientes, asesores y admin     │ HTTPS 443 (TLS 1.2/1.3, Let's Encrypt)
   ─────────────────────────────► │ https://www.tu-dominio.me  (Namecheap → Render)
                                  ▼
 ┌──────────────────────────── Render (Web Service) ─────────────────────────────┐
 │  Proxy/balanceador de Render (HTTPS, protección DDoS)                          │
 │        │                                                                       │
 │        ▼                                                                       │
 │  Node.js (server.js)                                                           │
 │   · cabeceras de seguridad (CSP, HSTS…) · límite de peticiones por IP          │
 │   · roles cliente / asesor / admin · bloqueo por intentos · bitácora           │
 │   · admin: contraseña + código TOTP (2FA obligatoria)                          │
 │   · cifra teléfono, notas, historial y secreto 2FA (AES-256-GCM)               │
 │  Secretos en variables de entorno de Render (MONGODB_URI, DATA_KEY, INDEX_KEY) │
 └───────────────────────────────────────┬────────────────────────────────────────┘
                                         │ TLS (mongodb+srv) · usuario tac_app (mínimo privilegio)
                                         │ sale desde las IP de salida de Render
                                         ▼
             MongoDB Atlas (M0, AWS us-east-1) · Network Access: solo IP de Render + tu IP
             Disco cifrado (AES-256) · validación $jsonSchema · índices TTL

   GitHub (repositorio privado) ── push ──► GitHub Actions (CI) ── pruebas OK ──► Render despliega
```

---

## Parte 1 · Repositorio en GitHub

1. Crea un repositorio **privado** en GitHub, por ejemplo `the-arabic-corner`.
2. En la carpeta del proyecto:
   ```bash
   git init
   git add .
   git commit -m "The Arabic Corner v3: seguridad y despliegue"
   git branch -M main
   git remote add origin https://github.com/TU_USUARIO/the-arabic-corner.git
   git push -u origin main
   ```
3. Verifica en GitHub que **no** se subió el `.env` (el `.gitignore` lo impide).
4. Pestaña **Actions**: el flujo **CI** debe terminar en verde. Revisa que no haya secretos, compila, corre las pruebas, audita dependencias y construye la imagen Docker. 📸 *Captura: CI en verde.*

> Antes de subir, ejecuta `npm run imagenes` y sube también `public/img/perfumes/` y `seed/imagenes_locales.json`. Así el servidor tendrá las fotos sin depender de enlaces externos.

---

## Parte 2 · Llaves de cifrado

El teléfono, las notas que evita el cliente y el detalle del historial se guardan cifrados con **AES-256-GCM**.

```bash
npm run llaves
```

Copia las dos líneas (`DATA_KEY=…` e `INDEX_KEY=…`) a tu `.env`.

> ⚠ **Usa las mismas llaves en tu computadora y en el servidor.** Si las pierdes, los datos cifrados no se pueden recuperar. Guárdalas también en un gestor de contraseñas.

Si tu base ya tiene datos de la versión anterior (v02), cífralos con `npm run cifrar-datos` o reinicia la base (Parte 4).

---

## Parte 3 · MongoDB Atlas (servicio 1 del Student Pack)

### 3.1 Autenticación de dos factores en tu cuenta
Atlas → tu nombre (arriba a la derecha) → **Account** → **Login and Security** → **Multi-Factor Authentication**. Si entras a Atlas con Google, esas opciones aparecen deshabilitadas: el segundo factor lo da Google, así que activa la **verificación en dos pasos de tu cuenta de Google**. 📸

### 3.2 Rol personalizado de la aplicación (mínimo privilegio)
**Security → Database Access → pestaña Custom Roles → Add New Custom Role**
- **Nombre:** `tac_app_rol`
- **Collection Actions:** `find`, `insert`, `update`, `remove` → base `the_arabic_corner`, ☑ **Apply to any collection**.
- **Database Actions and Roles:** `listCollections` → base `the_arabic_corner`.

La aplicación podrá leer y escribir documentos, pero **no** podrá borrar colecciones, crear índices ni tocar otras bases. 📸

### 3.3 Tres usuarios de base de datos
**Database Access → Database Users → Add New Database User** (método *Password* → **Autogenerate Secure Password**, cópiala).

| Usuario | Privilegios | Para qué |
|---|---|---|
| `tac_app` | Custom Role → `tac_app_rol` | La aplicación en producción (`MONGODB_URI`) |
| `tac_mantenimiento` | Specific Privileges → `readWrite@the_arabic_corner` + `dbAdmin@the_arabic_corner` | Crear colecciones e índices, reiniciar la base y respaldos (`MONGODB_URI_ADMIN`) |
| `tac_lectura` | Specific Privileges → `read@the_arabic_corner` (puedes marcarlo como *temporary user*) | Reportes y Compass (`MONGODB_URI_LECTURA`) |

En cada usuario activa **Restrict Access to Specific Clusters** → tu clúster.
**Elimina o deshabilita** el usuario que usabas en la v02 si tenía permisos amplios (por ejemplo *Atlas admin*). 📸 *Captura de la lista de usuarios con sus roles.*

### 3.4 Cadenas de conexión
**Database → Connect → Drivers**: copia la cadena y cambia usuario y contraseña para cada uno. En tu `.env`:
```
MONGODB_URI=mongodb+srv://tac_app:...@cluster0.xxxxx.mongodb.net/?retryWrites=true&w=majority&appName=TheArabicCorner
MONGODB_URI_ADMIN=mongodb+srv://tac_mantenimiento:...@cluster0.xxxxx.mongodb.net/?retryWrites=true&w=majority
MONGODB_URI_LECTURA=mongodb+srv://tac_lectura:...@cluster0.xxxxx.mongodb.net/?retryWrites=true&w=majority
```
El formato `mongodb+srv://` **obliga a usar TLS**: Atlas rechaza conexiones sin cifrar.

### 3.5 Lista de acceso por IP (firewall de Atlas)
**Security → Network Access**
1. **Elimina** la entrada `0.0.0.0/0` si existe (permitía conectarse desde cualquier lugar).
2. Agrega **tu IP actual** como entrada temporal (*This entry is temporary* → 1 semana) para trabajar desde tu computadora.
3. En la Parte 5 agregarás las IP de salida de Render. 📸

### 3.6 Cifrado en reposo
Atlas cifra el almacenamiento de todos los clústeres (incluido el gratuito M0) con **AES-256**. Las llaves administradas por el cliente (*customer-managed keys*) solo existen en clústeres dedicados. Por eso, como capa adicional, la app cifra los campos sensibles antes de enviarlos (Parte 2).

---

## Parte 4 · Probar en tu computadora

```bash
npm install
npm run preparar-bd -- --reset   # crea la base con el usuario de mantenimiento (borra los datos actuales)
npm start                        # la app usa el usuario tac_app
npm run verificar                # reporte de seguridad de la base
```

`npm run verificar` debe mostrar:
- `tac_app`: leer ✓, escribir ✓, **crear/borrar colecciones ✓ denegado**.
- `tac_lectura`: leer ✓, **escribir ✓ denegado**.
- Teléfono e historial cifrados, TTL activos y validación `$jsonSchema`.

📸 *Captura de la tabla.*

Prueba también:
- 5 contraseñas incorrectas seguidas → la cuenta se bloquea 15 minutos.
- Admin → **Seguridad**: bitácora y estado de los controles.
- En **Compass** con `tac_lectura`, abre `usuarios`: el teléfono aparece como `enc:v1:…`. 📸

---

## Parte 5 · Despliegue en Render + dominio de Namecheap

Render publica la aplicación directamente desde tu repositorio de GitHub. El plan gratuito no pide tarjeta. Una limitación: el servicio **se duerme tras 15 minutos sin visitas**, y la primera visita después tarda cerca de un minuto en responder.

### 5.1 Crear la cuenta de Render
1. Entra a <https://render.com> → **Get Started** → **GitHub**. Así Render puede leer tu repositorio.
2. Cuando te pregunte a qué repositorios dar acceso, elige **Only select repositories** → `the-arabic-corner`. Es el mínimo privilegio también aquí. 📸

### 5.2 Crear el servicio web
**+ New → Web Service →** elige `the-arabic-corner`:

| Campo | Valor |
|---|---|
| Name | `the-arabic-corner` (será `the-arabic-corner.onrender.com`; si está ocupado Render agrega letras) |
| Region | **Virginia (US East)**, la misma zona de AWS que tu clúster de Atlas |
| Branch | `main` |
| Runtime | **Node** |
| Build Command | `npm install --omit=dev --no-audit --no-fund` |
| Start Command | `node server.js` |
| Instance Type | **Free** |

En **Environment Variables** (o *Advanced → Add Environment Variable*) agrega:

| Variable | Valor |
|---|---|
| `MONGODB_URI` | La cadena de **`tac_app`** (la misma de tu `.env`). **Nunca** pongas aquí `tac_mantenimiento` |
| `MONGODB_DB` | `the_arabic_corner` |
| `DATA_KEY` | La **misma** de tu `.env` |
| `INDEX_KEY` | La **misma** de tu `.env` |
| `MFA_ADMIN` | `1` |
| `OCULTAR_DEMO` | `1` |
| `TRUST_PROXY_SALTOS` | `2` |
| `IP_CABECERA` | `cf-connecting-ip` |
| `NODE_VERSION` | `22` |

En **Advanced → Health Check Path** escribe `/api/config`. Luego presiona **Deploy Web Service**.

El archivo `render.yaml` del repositorio describe esta misma configuración como código (*Blueprint*).

### 5.3 Permitir a Render en el firewall de Atlas
Si en este momento falla el primer despliegue con un error de conexión a MongoDB, es normal: Atlas todavía no acepta a Render.
1. En Render, abre tu servicio → botón **Connect** (arriba a la derecha) → pestaña **Outbound**. Copia los rangos de **IP de salida**.
2. En Atlas → **Network Access → + Add IP Address**: agrega **cada rango**, con el comentario `render`.
3. Comprueba que **no exista** `0.0.0.0/0`. Deja solo los rangos de Render y tu IP. 📸
4. En Render → **Manual Deploy → Deploy latest commit**. En **Logs** debe aparecer `The Arabic Corner listo…` con `Cifrado de campos: activo` y `2FA de administradores: obligatoria`. 📸

### 5.4 Primer ingreso del administrador (2FA)
1. Abre `https://the-arabic-corner.onrender.com` y verifica el **candado** del navegador. 📸
2. Entra como administrador. Te llevará a **Seguridad de la cuenta**:
   - Instala **Google Authenticator** o **Microsoft Authenticator** en tu celular.
   - **Generar clave** → en la app: *Agregar → Ingresar clave de configuración* → escribe la clave → escribe el código de 6 dígitos → **Activar**. 📸
3. En la misma pantalla, **cambia la contraseña** del administrador: la de demostración es pública.
4. Cierra sesión y vuelve a entrar. Ahora se pide el **código de verificación**. 📸
5. Haz lo mismo (cambiar contraseña y, opcional, activar 2FA) con las cuentas de asesor que vayas a usar.

### 5.5 Comprobar la IP del visitante
La IP se usa en la bitácora y en el límite de peticiones. Render tiene a **Cloudflare** delante, así que sin configuración la app vería IPs de Cloudflare (`172.64.x`, `162.159.x`…) que cambian en cada visita. Con `IP_CABECERA=cf-connecting-ip` lee la cabecera donde Cloudflare entrega la IP real del visitante.

En **Admin → Seguridad**, el recuadro *Panel admin restringido por red* muestra *"tu IP"*: debe coincidir con tu IP real (búscala en Google: *cuál es mi IP*). Si no coincide, revisa el **Diagnóstico de IP** de esa misma página.

### 5.6 Dominio gratuito con Namecheap (servicio 2 del Student Pack)
1. Entra a <https://nc.me> → inicia sesión con **GitHub** → busca un dominio `.me` (por ejemplo `thearabiccorner.me`) → regístralo **gratis por 1 año**. 📸
2. En Render → servicio → **Settings → Custom Domains → + Add Custom Domain** → `www.thearabiccorner.me` (y también `thearabiccorner.me`). Render te muestra los registros DNS que hay que crear.
3. En Namecheap → **Domain List → Manage → Advanced DNS**: borra los registros de estacionamiento y crea **exactamente** los que Render indica. Normalmente son:
   - `CNAME` · host `www` · valor `the-arabic-corner.onrender.com`
   - `A` · host `@` · la IP que indique Render
4. Vuelve a Render → **Verify**. En minutos Render emite el **certificado HTTPS** para tu dominio. 📸

No necesitas el certificado SSL que ofrece Namecheap: Render ya incluye uno gratuito que se renueva solo.

### 5.7 Despliegue continuo
Render → **Settings → Build & Deploy → Auto-Deploy**: elige **After CI Checks Pass**. Así, cada `git push` a `main` primero pasa por GitHub Actions (secretos, pruebas, auditoría) y solo si todo está en verde Render publica la nueva versión. 📸

### 5.8 (Opcional) 1Password del Student Pack
Activa 1Password gratis (2 años) y guarda ahí `DATA_KEY`, `INDEX_KEY`, las contraseñas de `tac_app`, `tac_mantenimiento` y `tac_lectura`, y los códigos de respaldo. Es una buena evidencia de **gestión de secretos**.

---

## Parte 6 · Evidencias (capturas sugeridas)

| # | Captura | Demuestra |
|---|---|---|
| 1 | Login, dashboard del cliente, del asesor (vendedor) y del administrador | Sistema funcionando (Kanban: *Evidencias*) |
| 2 | Atlas: clúster, colecciones y un documento de `usuarios` con `telefono: enc:v1:…` | BD NoSQL y cifrado de campos |
| 3 | Atlas → Database Access (3 usuarios + `tac_app_rol`) | Control de acceso por roles |
| 4 | `npm run verificar` (20 de 20) | Mínimo privilegio, TLS, cifrado y TTL |
| 5 | Atlas → Network Access (solo rangos de Render + tu IP, sin `0.0.0.0/0`) | Firewall de la base |
| 6 | Render → Environment (nombres de las variables; **oculta los valores**) | Secretos fuera del código |
| 7 | Candado HTTPS y certificado del dominio | Cifrado en tránsito |
| 8 | Activación de la verificación en dos pasos y login pidiendo el código | Autenticación multifactor |
| 9 | Admin → Seguridad (bitácora con intentos fallidos, bloqueo, 2FA) | Auditoría |
| 10 | Mensaje *"Demasiados intentos fallidos…"* | Protección contra fuerza bruta |
| 11 | GitHub Actions en verde + Render *After CI Checks Pass* | Modernización del stack (CI/CD) |
| 12 | Student Pack: MongoDB y Namecheap (dominio `.me`) | Uso de 2 servicios |
| 13 | Google/Atlas: verificación en dos pasos de tu cuenta | Seguridad de las cuentas de administración |

---

## Parte 7 · Mantenimiento

| Tarea | Cómo |
|---|---|
| Ver registros | Render → servicio → **Logs** |
| Publicar cambios | `git push` → CI en verde → Render despliega solo |
| Respaldo de la base (M0 no tiene respaldos automáticos) | Desde tu PC: `mongodump --uri "<cadena de tac_mantenimiento>" --db the_arabic_corner --gzip --out respaldos/AAAA-MM-DD` (MongoDB Database Tools) |
| Rotar la contraseña de `tac_app` | Atlas → Database Access → Edit → Edit Password → Render → Environment → `MONGODB_URI` → **Save** (se redespliega) |
| Tu IP cambió | Atlas → Network Access → agrega la nueva (puede ser temporal) |

---

## Solución de problemas

| Síntoma | Causa probable |
|---|---|
| `querySrv ENOTFOUND` | La cadena todavía tiene el texto de ejemplo (`cluster0.xxxxx`) o la dirección del clúster está mal escrita |
| Tiempo agotado (*Server selection timed out*) hacia Atlas | Tu IP o las IP de salida de Render no están en Network Access |
| `bad auth : authentication failed` | Usuario o contraseña de la cadena incorrectos |
| `not authorized` / `not allowed to do action [createIndex]` al iniciar | Normal con `tac_app`: la app lo informa y continúa (los índices los crea `tac_mantenimiento`) |
| Render no verifica el dominio | Los registros DNS de Namecheap no coinciden con los que muestra Render, o aún no se propagan (espera unos minutos) |
| La página tarda ~1 minuto en abrir | Plan gratuito de Render: el servicio se durmió por inactividad |
| "Activa la verificación en dos pasos…" | `MFA_ADMIN=1`: el administrador debe configurar el 2FA antes de usar el panel |
| El código 2FA siempre es incorrecto | La hora del celular no está en automático, o se escribió mal la clave de configuración |
| El teléfono aparece como `[cifrado]` | El servidor no tiene `DATA_KEY` o es distinta a la que cifró los datos |
| Los `.sh` fallan con `$'\r'` | Se guardaron con finales de línea de Windows. Ejecuta `sed -i 's/\r$//' deploy/*.sh` (el `.gitattributes` lo evita) |

---

## Anexo A · Alternativa: servidor propio con VPN (Azure u otra VM)

Si en el futuro se usa una máquina virtual propia (Azure for Students u otra nube), el repositorio incluye todo lo necesario en `deploy/`, `Dockerfile` y `docker-compose.yml`: Caddy con HTTPS, firewall `ufw`, VPN WireGuard (SSH y panel admin solo por la VPN con `ADMIN_REDES=10.8.0.0/24`), fail2ban y respaldos. Los pasos originales se conservan a continuación como referencia.

### Pasos con Azure for Students

#### A.1 Activar el crédito
Entra a <https://azure.microsoft.com/free/students> con tu correo institucional (o desde el Student Pack). Son **$100 USD sin tarjeta**.

#### A.2 Crear la máquina virtual
Portal de Azure → **Máquinas virtuales → Crear → Máquina virtual de Azure**:

| Campo | Valor |
|---|---|
| Grupo de recursos | `rg-the-arabic-corner` (nuevo) |
| Nombre | `vm-the-arabic-corner` |
| Región | Una cercana que tu suscripción permita (si marca *RequestDisallowedByPolicy*, prueba otra) |
| Imagen | **Ubuntu Server 24.04 LTS** (x64) |
| Tamaño | **B1s** o **B2ats_v2** (aparecen como "apto para el nivel gratuito") |
| Autenticación | **Clave pública SSH** · usuario `azureuser` · genera un par de llaves y **descarga el .pem** |
| Puertos de entrada públicos | Permitir solo **SSH (22)** por ahora |
| Disco | SSD estándar |
| Redes → IP pública | Nueva, SKU **Estándar** (estática) |

**Revisar y crear → Crear**. Descarga la llave `.pem` cuando la pida. 📸

#### A.3 Nombre DNS gratuito (HTTPS sin comprar dominio)
Recurso **IP pública** de la VM → **Configuración** → *Etiqueta de nombre DNS*: `thearabiccorner` → Guardar.
Tu dominio será `thearabiccorner.<región>.cloudapp.azure.com`.

(Si consigues un dominio del Student Pack, como Namecheap `.me` o `.TECH`, crea un registro **A** hacia la IP de la VM y usa ese dominio en `DOMINIO`.)

#### A.4 Reglas del firewall de Azure (NSG)
VM → **Redes → Configuración de red → Agregar regla de puerto de entrada**:

| Puerto | Protocolo | Origen | Nombre |
|---|---|---|---|
| 80, 443 | TCP | Any | `web` |
| 51820 | UDP | Any | `wireguard` |
| 22 | TCP | **Mi dirección IP** (edita la regla existente) | `ssh-temporal` |

📸

#### A.5 Primera conexión SSH (PowerShell en Windows)
```powershell
# Solo la primera vez: deja la llave legible solo para tu usuario
icacls "$HOME\Downloads\vm-the-arabic-corner_key.pem" /inheritance:r
icacls "$HOME\Downloads\vm-the-arabic-corner_key.pem" /grant:r "$($env:USERNAME):(R)"

ssh -i "$HOME\Downloads\vm-the-arabic-corner_key.pem" azureuser@IP_PUBLICA
```

#### A.6 Descargar el proyecto en la VM
Si el repositorio es privado, crea una *deploy key* de solo lectura:
```bash
ssh-keygen -t ed25519 -f ~/.ssh/github -N ""
cat ~/.ssh/github.pub          # cópiala en GitHub → repo → Settings → Deploy keys → Add (sin escritura)
printf 'Host github.com\n  IdentityFile ~/.ssh/github\n' >> ~/.ssh/config
git clone git@github.com:TU_USUARIO/the-arabic-corner.git
cd the-arabic-corner
```

#### A.7 Endurecer el servidor (firewall, VPN, SSH)
```bash
sudo bash deploy/preparar_servidor.sh
```
El script:
- actualiza el sistema e instala Docker, WireGuard, ufw y fail2ban;
- crea la VPN (servidor `10.8.0.1`, tu equipo `10.8.0.2`);
- configura **ufw** (públicos solo 80, 443 y 51820/udp; **SSH y 8080 solo por la VPN**);
- desactiva el acceso SSH con contraseña y el de root.

Al final muestra un **código QR** y deja tu configuración en `~/vpn-clientes/admin.conf`. 📸 *Captura de `ufw status verbose`.*

#### A.8 Conectar la VPN desde tu computadora
1. Instala **WireGuard para Windows**: <https://www.wireguard.com/install/>.
2. Copia la configuración a tu equipo (desde PowerShell, mientras el SSH público sigue abierto):
   ```powershell
   scp -i "$HOME\Downloads\vm-the-arabic-corner_key.pem" azureuser@IP_PUBLICA:vpn-clientes/admin.conf "$HOME\Downloads\"
   ```
3. WireGuard → **Importar túnel(es) desde archivo** → `admin.conf` → **Activar**. 📸
4. Prueba:
   ```powershell
   ping 10.8.0.1
   ssh -i "$HOME\Downloads\vm-the-arabic-corner_key.pem" azureuser@10.8.0.1
   ```

#### A.9 Cerrar el SSH público
Ya **conectado por la VPN** (`ssh … azureuser@10.8.0.1`):
```bash
cd the-arabic-corner
sudo bash deploy/cerrar_ssh_publico.sh
```
En Azure → VM → Redes: **elimina la regla `ssh-temporal`**.
Comprueba que `ssh azureuser@IP_PUBLICA` (sin VPN) **ya no responde**. 📸

Otros integrantes del equipo: `sudo bash deploy/vpn_nuevo_cliente.sh nombre`.

#### A.10 Permitir la VM en Atlas
Atlas → **Network Access → Add IP Address** → la **IP pública de la VM** `/32`, comentario `vm-azure`. 📸

#### A.11 Secretos en el servidor
```bash
cp .env.example .env
nano .env        # pega tus 3 cadenas, las MISMAS DATA_KEY/INDEX_KEY y quita el # de DOMINIO, CORREO_TLS y ADMIN_REDES
chmod 600 .env   # solo tu usuario puede leerlo
```
Valores de producción:
```
DOMINIO=thearabiccorner.<región>.cloudapp.azure.com
CORREO_TLS=tu-correo@ejemplo.com
ADMIN_REDES=10.8.0.0/24
OCULTAR_DEMO=1
```

#### A.12 Desplegar
```bash
newgrp docker                         # o cierra sesión y vuelve a entrar
bash deploy/desplegar.sh --primera    # la primera vez (verifica la base); después solo: bash deploy/desplegar.sh
```
Caddy obtiene el certificado de Let's Encrypt automáticamente (tarda unos segundos).
- **Sitio público:** `https://thearabiccorner.<región>.cloudapp.azure.com` → candado del navegador → *La conexión es segura*. 📸
- **Panel de administrador:** `http://10.8.0.1:8080` **con la VPN activa**. Sin VPN, el administrador recibe *"El panel de administración solo está disponible conectado a la VPN"*. 📸 *Captura de ambos casos.*

Para actualizar después: `git push` desde tu computadora → CI en verde → por VPN `bash deploy/desplegar.sh`.
