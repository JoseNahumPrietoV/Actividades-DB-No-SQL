// Consultas de ejemplo para The Arabic Corner.
// Ejecútalas en mongosh:   mongosh the_arabic_corner docs/consultas_mongodb.js
// o cópialas una por una en la pestaña "Mongosh" de MongoDB Compass.

// 1) Perfumes publicados de Lattafa ordenados por precio
printjson(db.perfumes.find({ marca: 'Lattafa', estado: 'Publicado' }, { nombre: 1, familia: 1, precio: 1 }).sort({ precio: 1 }).toArray());

// 2) Consulta sobre arreglos: perfumes para "Cita" en "Otoño" por debajo de $1,600
printjson(db.perfumes.find({ ocasiones: 'Cita', temporadas: 'Otoño', precio: { $lte: 1600 } }, { nombre: 1, marca: 1, precio: 1 }).toArray());

// 3) Subdocumento embebido: clientes cuya familia favorita es Oud
printjson(db.usuarios.find({ rol: 'cliente', 'preferencias.familia': 'Oud' }, { nombre: 1, 'preferencias.presupuesto': 1 }).toArray());

// 4) Agregación: consultas por familia olfativa en los últimos 30 días
printjson(db.eventos.aggregate([
  { $match: { tipo: 'consulta', fecha: { $gte: new Date(Date.now() - 30 * 864e5) } } },
  { $group: { _id: '$familia', consultas: { $sum: 1 } } },
  { $sort: { consultas: -1 } },
]).toArray());

// 5) Agregación por mes: interés en Oud durante los últimos 12 meses (estacionalidad)
printjson(db.eventos.aggregate([
  { $match: { familia: 'Oud', tipo: { $in: ['consulta', 'busqueda'] }, fecha: { $gte: new Date(Date.now() - 365 * 864e5) } } },
  { $group: { _id: { $dateToString: { format: '%Y-%m', date: '$fecha' } }, n: { $sum: 1 } } },
  { $sort: { _id: 1 } },
]).toArray());

// 6) Ingresos por marca en los últimos 12 meses ($lookup entre ventas y perfumes)
printjson(db.ventas.aggregate([
  { $match: { fecha: { $gte: new Date(Date.now() - 365 * 864e5) } } },
  { $lookup: { from: 'perfumes', localField: 'perfume_id', foreignField: '_id', as: 'p' } },
  { $unwind: '$p' },
  { $group: { _id: '$p.marca', unidades: { $sum: '$cantidad' }, ingresos: { $sum: { $multiply: ['$cantidad', '$precio_unitario'] } } } },
  { $sort: { ingresos: -1 } },
]).toArray());

// 7) Perfumes más guardados en favoritos ($unwind del arreglo embebido)
printjson(db.usuarios.aggregate([
  { $unwind: '$favoritos' },
  { $group: { _id: '$favoritos.perfume_id', veces: { $sum: 1 } } },
  { $lookup: { from: 'perfumes', localField: '_id', foreignField: '_id', as: 'p' } },
  { $project: { _id: 0, perfume: { $first: '$p.nombre' }, veces: 1 } },
  { $sort: { veces: -1 } },
]).toArray());

// 8) Tasa de aceptación de recomendaciones por mes
printjson(db.eventos.aggregate([
  { $match: { tipo: 'recomendacion' } },
  { $group: { _id: { $dateToString: { format: '%Y-%m', date: '$fecha' } }, total: { $sum: 1 }, aceptadas: { $sum: { $cond: ['$aceptada', 1, 0] } } } },
  { $project: { aceptacion: { $round: [{ $multiply: [{ $divide: ['$aceptadas', '$total'] }, 100] }, 1] }, total: 1 } },
  { $sort: { _id: -1 } },
  { $limit: 6 },
]).toArray());

// 9) Perfumes bajo existencias mínimas
printjson(db.perfumes.find({ estado: 'Publicado', existencias: { $lte: 4 } }, { nombre: 1, existencias: 1, tiempo_entrega: 1 }).toArray());

// 10) Ver la validación de esquema y los índices de una colección
printjson(db.getCollectionInfos({ name: 'perfumes' })[0].options.validator);
printjson(db.perfumes.getIndexes());

// ---------------- Seguridad (v3) ----------------

// 11) Bitácora: intentos de acceso fallidos de las últimas 24 horas, agrupados por correo
printjson(db.auditoria.aggregate([
  { $match: { exito: false, fecha: { $gte: new Date(Date.now() - 864e5) } } },
  { $group: { _id: '$correo', intentos: { $sum: 1 }, ultima: { $max: '$fecha' }, ips: { $addToSet: '$ip' } } },
  { $sort: { intentos: -1 } },
]).toArray());

// 12) Campos cifrados: así ve un usuario de la base el teléfono y las notas (no se pueden leer sin DATA_KEY)
printjson(db.usuarios.find({ rol: 'cliente' }, { nombre: 1, telefono: 1, 'preferencias.notas_evita': 1 }).limit(3).toArray());

// 13) Índices TTL (expiración automática): sesiones, bitácora e intentos de inicio de sesión
['sesiones', 'auditoria', 'intentos_login'].forEach((c) =>
  printjson(db.getCollection(c).getIndexes().filter((i) => i.expireAfterSeconds !== undefined)));
